# Exact and generic stereo-rule extraction contract

**Sprint:** RX6  
**Schema:** `synkit.stereo-rule-extraction/1`  
**Status:** implemented and self-verifying

## Acceptance path

1. A mapped reaction or supplied ITS is copied.
2. Reactant and product stereo registries are strictly validated against their
   reconstructed endpoint graphs.
3. An exact `SynRule` is built.
4. Generic extraction may replace only unchanged, graph-backed peripheral
   material references selected by policy.
5. Every wildcard receives a typed domain, owner, orbit slot, resource
   contract, and evidence source.
6. The generic rule strictly replays its source.
7. A reversible rule strictly replays backward; an information-losing rule is
   certified `non_invertible`.
8. A self-verifying certificate binds source/generic identities, ports, source
   replay, and reverse replay.

## Fail-closed cases

Extraction refuses:

- unmapped or duplicate-mapped input;
- absent stereo;
- stale/dangling endpoint descriptor support;
- missing, ineligible, or ambiguous selected references;
- class/corpus domains without explicit bounds;
- corpus domains without aligned evidence;
- source or reverse replay failure;
- invalid, duplicate, or tampered certificate content.

Generic extraction never converts path/plane/framework loci or virtual H/LP
resources into material wildcard ports.

## Identity and compatibility

The certificate digest omits source atom-map identities from port contracts
and uses canonical rule signatures. Consistent atom relabeling and component
reordering therefore retain source, generic, and certificate digests.

`RuleExtractionCertificate.to_dict()` now includes its digest.
`RuleExtractionCertificate.from_dict()` reconstructs typed constraints,
validates schema and unique port bindings, and rejects a digest mismatch.
Schema `/1` remains unchanged.

## Gate evidence

- All six executable local geometry families retain exact/generic forward and
  reverse population parity.
- Strict invalid-support rejection occurs before `SynRule` construction.
- Certificate round-trip, field tamper, and duplicate-port attacks pass.
- Focused extraction suites: 27 passed.
- Adjacent rule, ITS, transport, reactor, promoted rewrite, and fusion suites:
  207 passed.
- Strict new-test lint, compatibility-module lint with repository exclusions,
  Python compilation, and `git diff --check`: passed.

