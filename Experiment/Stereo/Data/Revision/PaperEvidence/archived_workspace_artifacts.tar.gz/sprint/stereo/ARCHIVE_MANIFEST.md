# Sprint archive manifest

The previous mixed stereo-graph, stereo-reaction, mechanism, benchmark, and
paper sprint sequence was closed on 28 July 2026 before restarting the
stereo-graph programme at Sprint 1.

## Archive

- File: `older/stereo_sprints_0-44_2026-07-28.tar.gz`
- Contents: 84 archived entries under
  `synkit-sprint-legacy-20260728/`
- SHA-256:
  `cdb38e9ab79bad265e32154f372359c6fa142dab6334af6865b54588e127f5ff`

The archive contains the previous Sprint 0--44 pages, `SS_LOG.md`,
`CURRENT_PROGRESS.md`, roadmaps, benchmark scripts and results, and the prior
`archive/` directory.

Verify and inspect without extracting:

```bash
gzip -t sprint/older/stereo_sprints_0-44_2026-07-28.tar.gz
tar -tzf sprint/older/stereo_sprints_0-44_2026-07-28.tar.gz
```

Restore into a temporary directory:

```bash
mkdir -p /tmp/synkit-sprint-restore
tar -xzf sprint/older/stereo_sprints_0-44_2026-07-28.tar.gz \
  -C /tmp/synkit-sprint-restore
```

Do not extract the archive over the active `sprint/` directory.
