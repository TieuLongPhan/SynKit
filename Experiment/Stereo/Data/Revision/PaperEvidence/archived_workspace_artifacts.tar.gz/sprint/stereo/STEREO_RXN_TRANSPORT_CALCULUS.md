# Stereo reaction reference-transport calculus

**Sprint:** RX4  
**Status:** normative and implemented

## Domain

Reference transport is implemented for every configured descriptor family:

- tetrahedral, square-planar, trigonal-bipyramidal, octahedral;
- planar-bond and atrop-bond;
- cumulene-axis and extended cis/trans;
- helical and planar chirality;
- coupled framework stereo.

Only peripheral references may be replaced. Path, plane, pilot, axis, central
bond, and framework-support atoms remain descriptor loci. A changed locus is a
different descriptor identity, not a reference replacement.

## Laws

1. Endpoint relation is computed after validated reference transport.
2. Zero replacement is identity; one replacement may be inferred; multiple
   replacements require an explicit bijection.
3. Transport is covariant under consistent material and virtual-reference
   relabeling.
4. `alignment.reverse().reverse() == alignment`, including inferred
   alignments.
5. `first.then(second)` composes replacement maps and removes identity pairs.
6. Direct and composed change application agree when a continuous
   configuration witness exists.
7. Formed-then-broken yields a fleeting transition descriptor.
8. Broken-then-formed has no continuous configuration witness and becomes a
   non-invertible `STEREO_COMPOSITION_INFORMATION_LOSS` refusal.
9. Rich nonbinary orbit relations remain authoritative over the binary
   compatibility label.

## Application

The six fixed-frame local families replay through their permutation witness.
Extended path/plane/framework families replay covariantly from the
substrate-to-guard relation:

- equivalent substrate → declared product;
- opposite substrate → opposite declared product;
- unspecified substrate → unspecified declared product;
- unrelated substrate → typed replay refusal.

This path never uses CIP, `@`/`@@`, atom maps as orientation labels, or a
reference record.

## Validation

- RX4 focused change/transport/value tests: 56 passed.
- Adjacent Graph/Stereo, generic rule, reactor, promoted rewrite, and
  mechanism suites: 1,757 passed, 1 skipped.
- All eleven configured families pass inverse application, double reversal,
  and deterministic relabeling.
- Compatibility-file flake8 with the repository's existing E501/W503
  exclusions, strict new-file flake8, Python compilation, and
  `git diff --check`: passed.

