# Stereo reaction RX14 closeout manifest

**State:** local release-ready review; no release or publication authorized  
**Date:** 29 July 2026  
**Branch:** `stereo`  
**Starting HEAD:** `2555754863fd45935a7e68c8c067c56936ffdde2`  
**Package:** `1.6.1b1`  
**Mechanism schema:** `2.0.0-draft1`

## RX1--RX14 evidence

| Sprint | Closed evidence | Principal executable gate |
|---|---|---|
| RX1 | `STEREO_RXN_BASELINE_MANIFEST.md` | frozen 80+8, 62 migration, complete baseline |
| RX2 | `STEREO_RXN_INFORMATION_MODEL.md` | `test_reaction_semantics.py` |
| RX3 | `STEREO_RXN_SCHEMA.md` | `test_reaction_wire.py` |
| RX4 | `STEREO_RXN_TRANSPORT_CALCULUS.md` | `test_reaction_transport_calculus.py` |
| RX5 | `STEREO_RXN_ITS_DPO_CONTRACT.md` | `test_stereo_layers.py` |
| RX6 | `STEREO_RXN_RULE_EXTRACTION_CONTRACT.md` | `test_generic_stereo_contract.py` |
| RX7 | `STEREO_RXN_REACTOR_CONTRACT.md` | `test_stereo_branch_algebra.py` |
| RX8 | `STEREO_RXN_COUPLED_OUTCOME_CONTRACT.md` | `test_stereo_coupling_corpus.py` |
| RX9 | `STEREO_RXN_COMPOSITION_FUSION_CONTRACT.md` | `test_reaction_composition.py`, `test_proof_document_digest.py` |
| RX10 | `STEREO_RXN_MECHANISM_CONTRACT.md` | `test_electrocyclic_machinery.py` |
| RX11 | `STEREO_RXN_INTERCHANGE_CONTRACT.md` | `test_reaction_interchange.py` |
| RX12 | `STEREO_RXN_COVERAGE_CONTRACT.md` | `test_stereo_branch_coverage.py` |
| RX13 | `STEREO_RXN_VALIDATION_CONTRACT.md` | `test_stereo_rxn_validation.py` |
| RX14 | this manifest, unified API/migration guide, ACS manuscript/SI | final suite/docs/paper gates |

All files in this table are relative to `sprint/` except executable tests,
which are under `Test/`.

## SR1--SR14 traceability

| Requirement | Implementation | Test | Artifact |
|---|---|---|---|
| SR1 baseline | frozen corpus/readers | benchmark and migration suites | RX1 manifest |
| SR2 independent axes | `semantics.py` | reaction semantics | RX2 contract |
| SR3 immutable schema | `wire.py` | reaction wire | RX3 contract |
| SR4 reference transport | `changes.py` | transport calculus | RX4 contract |
| SR5 stereo ITS/DPO | `Graph/ITS/stereo.py` | stereo layers | RX5 contract |
| SR6 exact/generic rules | `Rule/generic_stereo.py` | generic contract | RX6 contract |
| SR7 reactor algebra | Reactor stereo modules | branch algebra | RX7 contract |
| SR8 coupled outcomes | `couplings.py`, reactor | coupling corpus | RX8 contract |
| SR9 composition/fusion | `composition.py`, Fusion proof | composition/digest | RX9 contract |
| SR10 stepwise mechanism | Mechanism model/replay/timeline | electrocyclic machinery | RX10 contract |
| SR11 interchange loss | `reaction_interchange.py` | interchange matrix | RX11 contract |
| SR12 reviewed coverage | branch coverage manifest | coverage review | RX12 contract |
| SR13 validation/budgets | validation tool | RX13 matrix | validation JSON |
| SR14 mutual traceability | docs, examples, ACS source | docs/paper/final suite | this manifest |

## Frozen machine evidence

| Artifact | SHA-256 |
|---|---|
| `stereo.json` | `99c7794d16eb6e07504fa6987915e6d384f253a8b6878e51345129a40c851426` |
| `stereo_couplings.json` | `65da38b2d6c299c5bfc91acd7a1b7157eb3777de8e67c965abd87e5356ff4bb1` |
| `electrocyclic_machinery.json` | `91ed84a5819d606979531d541e4f746993ff6ca85217ed6098cf4af30e11b6c3` |
| `stereo_branch_coverage.json` | `48fc08ace7ddbe86a9a080bb67720ac00e7c7ea3a4741d70dad8cad9e7bd27cb` |
| `stereo_rxn_validation.json` | `4e886e8ffd8957a15475fe22656766679d179d9588d5b091fe189dcae4b8de4f` |

The machine-readable companion is
`evidence/stereo_rxn_closeout.json`.

## Final commands and results

```text
python -m pytest -q
4055 passed, 31 skipped, 179 subtests passed

python examples/stereo_reaction_workflows.py
passed

python tools/stereo_rxn_validation.py
PASS

SYNKIT_DOCS_OFFLINE=1 sphinx-build -E -W -b html doc <output>
passed

latexmk -pdf main.tex
latexmk -pdf si.tex
latexmk -pdf cover_letter.tex
```

Strict new-file lint, compatibility lint, Python compilation, JSON parse,
changed-module 1,000-line gate, 108 local programme links, and
`git diff --check` passed on the final state.

## ACS build evidence

| Artifact | Pages | Page size | SHA-256 |
|---|---:|---|---|
| `paper/stereo_rxn/main.pdf` | 25 | US letter | `6923b08ec047ba9914bd687d753a2d1d5bc52c0e075d48aa0b6e4874801e5a85` |
| `paper/stereo_rxn/si.pdf` | 11 | US letter | `30a40d1c2efda569dee8e4c1a518e935b1d90b1c48d2266378f1bd0b6b867b43` |
| `paper/stereo_rxn/cover_letter.pdf` | 2 | US letter | `77974959fa08fd8eb3a0840ba208d8b7a4dc33daff23e1bcb15d646a994b61fb` |

The main article and SI use the ACS `achemso` class with the `jcisd8`
configuration. All fonts are embedded. The main article contains no raster
images; its figures remain vector artwork. Logs contain no overfull boxes,
undefined citations, undefined references, or rerun requests. The installed
2022 `achemso` class emits its known unused-global-option notice after loading
`achemso-jcisd8.cfg`; the requested configuration is nevertheless active.

## Deliberately unsupported

- complete isotope/pseudoasymmetry CIP Rules 4b--5 reaction ranking;
- enhanced ABS/AND/OR group-to-population semantics;
- ring-relative locked-elimination coupling;
- facial pericyclic selectivity and condition/torquoselectivity prediction;
- advanced allene/spiro/coordination reaction execution.

Electrocyclic machinery verifies a supplied 4π/6π,
thermal/photochemical, conrotatory/disrotatory annotation. It does not choose
that annotation.

## Worktree provenance

The programme was implemented in a pre-existing dirty worktree. Unrelated
Lewis-rule-replay and electron-aware ITS changes were preserved and were not
claimed as RX1--RX14 output. No reset, cleanup, push, tag, upload, release,
DOI creation, or manuscript submission was performed.

## Actions still requiring user authorization

- decide authorship and enable any currently disabled co-author block;
- freeze/commit the intended source state;
- create a package tag/release and immutable archive;
- replace development-branch provenance with the released commit/DOI;
- approve and perform manuscript submission or any external upload.
