# Stereo reaction information model

**Sprint:** RX2  
**Status:** normative  
**Public values:** `synkit.Graph.Stereo.semantics`

## One assertion, six independent fields

`StereoReactionSemantics` describes one reaction-local assertion:

1. `descriptor_class` — local geometry/support family;
2. `lifecycle` — retained, inverted, formed, broken, fleeting, or
   unspecified;
3. `relation` — orbit relation after validated reference transport;
4. `population` — single, racemic, enantiomeric mixture, diastereomer set,
   meso, achiral, or unknown;
5. `determinacy` — stereospecific, stereoselective, non-stereospecific, or
   underdetermined;
6. `evidence` and `context` — what authorizes the assertion and which
   conditions matter.

An assertion is accepted only with declared evidence. Otherwise
`StereoReactionDecision` carries one `StereoRefusal`. A decision cannot contain
both or neither.

## Historical field warning

MechanismBench v1 uses `local_geometry` for a change across the reaction arrow,
not for a descriptor geometry family. It also records `descriptor_change`,
which describes the serialized descriptor. These fields are retained as
reviewed evidence but do not define the new value names.

For example, a reaction may be chemically retained after mapped-reference
transport while its serialized `@`/`@@` token flips because neighbor order
changed. The RX2 audit contains such cases and requires the normalized
assertion to remain `RETAINED` / `equivalent`.

## Transition table

| Lifecycle | Before | After | Required relation | Reversible |
|---|---|---|---|---|
| `RETAINED` | present | present | transported equivalent/reconfigured evidence | yes when witness exists |
| `INVERTED` | present | present | transported opposite/reconfigured evidence | yes when witness exists |
| `FORMED` | absent | present | none | reverse is broken |
| `BROKEN` | present | absent | none | reverse is formed only if the descriptor is retained as evidence |
| `FLEETING` | absent | absent | none; transition descriptor present | sequence-dependent |
| `UNSPECIFIED` | present/unknown | present/unknown | none, unrelated, or unspecified | no when specified information was lost |

The rich orbit relation remains authoritative for nonbinary geometries. The
binary `RETAINED`/`INVERTED` strings remain compatibility projections where
the current API already exposes them.

## Population table

| Population | Meaning |
|---|---|
| `SINGLE` | one declared product stereoisomer/state |
| `RACEMIC` | equal enantiomer population |
| `ENANTIOMERIC_MIXTURE` | unequal, explicitly weighted enantiomers |
| `DIASTEREOMER_SET` | declared set containing non-enantiomeric stereoisomers |
| `MESO` | one internally compensated product state |
| `ACHIRAL` | product has no configured chiral state under the declared profile |
| `UNKNOWN` | population was not determined |

`UNKNOWN` requires `UNDERDETERMINED`. It never expands into branches and never
compares equal to `RACEMIC`.

## Evidence table

| Evidence | Authorization |
|---|---|
| `SOURCE_DECLARED` | reviewed source or user annotation |
| `RULE_DECLARED` | explicit executable rule assertion |
| `MECHANISM_CONSTRAINED` | supplied mechanism trajectory justifies the assertion |
| `CONTEXT_REQUIRED` | the assertion cannot be completed without named context |
| `UNSUPPORTED` | the representation or oracle is outside the supported contract |

Topology alone can establish that an outcome is possible. It cannot choose a
face, syn/anti relation, thermal/photo mode, or population without one of the
positive evidence classes.

## Typed refusals

| Code | Used for |
|---|---|
| `INVALID_REFERENCE` | absent owner, non-neighbor, stale explicit/virtual reference |
| `UNSUPPORTED_GEOMETRY` | no executable model for the descriptor family |
| `AMBIGUOUS_ALIGNMENT` | more than one admissible endpoint reference transport |
| `LOSSY_PROJECTION` | target format cannot carry the assertion |
| `MISSING_CONTEXT` | conditions/mechanism needed to choose an assertion are absent |
| `ASSIGNMENT_LIMIT` | wildcard assignment budget exceeded |
| `BRANCH_LIMIT` | product branch budget exceeded |
| `IRREVERSIBLE_INFORMATION_LOSS` | reverse construction would invent configuration |
| `CONTRADICTORY_ASSERTION` | mutually incompatible fields or impossible state |
| `INVALID_COUPLING` | malformed or chemically unsupported joint relation |

Each refusal includes detail, affected targets, and any required context. A
refusal is a successful fail-closed result, not an unknown exception.

## Baseline audit

The RX2 test audit maps all 88 frozen cases:

- all 80 transformations produce one normalized accepted decision;
- all 8 negative assertions produce one typed refusal;
- the 11 non-tetrahedral/mechanism cases without the historical oracle axes
  are mapped from their representation-specific reviewed effects;
- unknown-versus-racemic and retained-versus-token-flip sentinels are
  permanent.

The mapping is an evidence adapter. Production code remains blind to case IDs,
names, catalog references, expected labels, and source order.
