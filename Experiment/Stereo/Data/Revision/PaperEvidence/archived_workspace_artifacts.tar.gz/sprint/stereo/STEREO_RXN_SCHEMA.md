# Reaction-stereo value and schema contract

**Sprint:** RX3  
**Current schema:** `synkit.reaction-stereo/2`  
**Readable legacy schema:** `synkit.reaction-stereo/1`

## Normalized value

`StereoReactionValue` is an immutable, hashable aggregate over:

- descriptor guards;
- configuration-aware effects (`StereoChange`);
- product outcomes;
- coupled local outcomes;
- normalized RX2 assertions;
- typed refusals.

Inputs may be mappings or target/value pairs. Construction sorts targets,
rejects duplicate targets, validates descriptor ownership, requires every
outcome to have a corresponding effect, and requires every coupling key to
match its central bond. Public mapping views are read-only.

`normalized_json()` is deterministic under input reordering and uses sorted
keys with compact separators.

## Schema compatibility

Schema v1 contains guards, effects, outcomes, and full coupling values. Schema
v2 adds normalized assertions and typed refusals. Both versioned v1 and the
equivalent unversioned legacy value remain readable.

A v2 value may downgrade to v1 only when it carries no v2-only assertions or
refusals. Otherwise `to_legacy_dict()` raises `ReactionStereoSchemaError`
containing a `LOSSY_PROJECTION` refusal. No downgrade silently removes data.

The version-independent payload for `StereoChange` contains:

- compatibility change label;
- before, after, and optional transition descriptors;
- explicit/reference alignment state;
- rederived orbit relation evidence.

Reading a change reconstructs its descriptors and rederives the relation
instead of trusting a serialized parity verdict.

## Invariants

1. Descriptor target ownership is exact.
2. Target order never changes equality, hash, or normalized bytes.
3. Duplicate targets and contradictory values fail during construction.
4. Unknown/refused semantics do not become accepted assertions during
   serialization.
5. Schema v1 stays readable.
6. Lossy downgrade is a typed refusal.
7. Rich relation evidence remains authoritative over the compatibility string.

## Validation

- RX3 focused value/semantics/reaction tests: 24 passed.
- Adjacent Graph/Stereo, rule, reactor, fusion, and mechanism suites:
  1,670 passed, 1 skipped.
- New-file flake8, Python compilation, and `git diff --check`: passed.

