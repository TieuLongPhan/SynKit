# Stereo reaction-graph programme

**Prepared:** 29 July 2026  
**Status:** planned; no implementation sprint has started  
**Sequence:** 14 gated sprints in 6 phases  
**Foundation:** the closed molecular stereograph programme and the existing
reaction-stereo implementation

## 1. Programme goal

Deliver a graph-native, mapping-invariant, replayable stereo reaction layer
that can:

1. describe what stereo information a reaction requires, preserves, changes,
   destroys, creates, or leaves unknown;
2. distinguish a single configured result, an information-losing result, and
   a product population;
3. extract exact and generic stereo rules without leaking source labels;
4. apply those rules with explicit guards, bounded branching, and correct
   probability/correlation semantics;
5. carry stereo through ITS, DPO, fusion, reversal, and mechanism replay;
6. serialize every supported assertion losslessly and reject lossy projections
   explicitly;
7. support every public claim with reviewed chemistry, negative fixtures,
   metamorphic tests, replay proofs, and a frozen evidence manifest.

The programme is not greenfield work. `StereoChange`,
`StereoReferenceAlignment`, outcome and coupling values, generic stereo-rule
extraction, reactor propagation, stereo-bearing ITS, fusion proof v2, and
mechanism replay already exist. The plan closes and unifies these surfaces
without replacing working APIs merely for architectural neatness.

## 2. Immutable baseline

Before production code changes, Sprint RX1 freezes:

- `MechanismBench-stereo-v1`: 80 reviewed positive records and 8 reviewed
  negative assertions;
- the 62-case orbit-versus-legacy migration comparison: 58 agreements,
  4 registered nonbinary differences, and 0 unexpected differences;
- current public imports, serialized fields, proof-v1/v2 readers, and rule
  payloads;
- current focused and complete test results, Python/RDKit/SynKit versions,
  corpus checksums, and worktree provenance;
- the current ACS manuscript claims and every number that must be replaced at
  release freeze.

The existing benchmark is evidence, not a target to optimize against. Records,
expected labels, atom maps, or source ordering may never be used as
implementation branches.

## 3. Scientific information model

Every reaction-stereo assertion is the product of five independent axes.

| Axis | Question | Required examples |
|---|---|---|
| Local geometry | What kind of stereogenic support is involved? | tetrahedral, double-bond, axial, planar, helical, framework |
| Lifecycle | What happened to the descriptor? | retained, inverted, formed, broken, fleeting, unspecified |
| Configuration relation | How do endpoint configurations relate after reference transport? | same orbit, opposite orbit, incomparable, unknown |
| Population | What product set is asserted? | single, racemic, enantiomeric mixture, weighted branches |
| Determinacy/context | Why is that assertion justified? | source-declared, rule-declared, mechanism-constrained, context-required, unsupported |

The following are never synonyms:

- `UNSPECIFIED` and `RACEMIC`;
- a descriptor parity flip and chemical inversion;
- a single outcome with unknown orientation and two enumerated enantiomers;
- correlated `syn`/`anti` branches and the Cartesian product of local choices;
- graph reversibility and recovery of information destroyed by a forward rule;
- topology-permitted selectivity and experimentally or mechanistically
  justified selectivity.

## 4. Scope boundaries

### Required for programme completion

- endpoint descriptor transport for all currently public stereo families;
- exact and generic rule extraction, forward/reverse replay, and typed refusal;
- rule guards, effects, outcomes, and couplings as stable public values;
- stereo-only reaction centres and endpoint/transition ITS registries;
- reactor modes `ignore`, `require`, `propagate`, and `strict`;
- bounded wildcard assignment and product branching;
- weighted and correlated outcomes with deterministic deduplication;
- proof-carrying fusion and endpoint/stepwise mechanism replay;
- stable JSON/dict schemas and an explicit interchange loss report;
- reviewed positive, negative, migration, metamorphic, tamper, and performance
  evidence;
- ACS manuscript, documentation, examples, and claim-to-evidence manifest.

### Supported only when evidence is present

- reaction-specific facial selectivity;
- thermal versus photochemical pericyclic outcomes;
- ring-relative outcomes;
- isotope-dependent stereochemistry;
- enhanced stereo groups and ensemble populations;
- coordination-specific and pseudoasymmetric cases.

These families may enter the implementation only with a formal representation,
a reviewed oracle, and fail-closed tests. Otherwise the release must preserve
or reject the assertion explicitly; it must not guess.

### Not authorized by this plan

- automatic mechanism selection from reactants alone;
- energetic, kinetic, yield, or selectivity prediction;
- reading reference answers during execution;
- a package release, git push, paper submission, or external publication;
- reopening the closed molecular stereograph accuracy claims.

## 5. Architecture boundary

| Layer | Owns | Must not own |
|---|---|---|
| `synkit/Graph/Stereo` | immutable stereo values, reference transport, relations, outcomes, couplings, interchange reports | reaction matching or mechanism choice |
| `synkit/Graph/ITS` | endpoint and transition stereo layers, stereo-only reaction-centre identity, relabel/reversion | rule generalization |
| `synkit/Rule` | exact/generic guards and effects, wildcard domains, source/reverse replay evidence, rule identity | product enumeration |
| `synkit/Synthesis/Reactor` | matching policy, propagation, assignments, branching, weights, deduplication, limits | inventing undeclared selectivity |
| `synkit/Graph/Fusion` | composability and replay proof across fused rules | silently repairing incompatible rules |
| `synkit/Mechanism` | endpoint/stepwise verification and state timeline | treating endpoint agreement as stepwise proof |
| benchmark/paper | reviewed oracles and claims | production behavior keyed to fixture identity |

Existing public locations remain authoritative unless a sprint proves a
specific compatibility or ownership defect. New abstractions must reduce
semantic ambiguity, not duplicate existing values under new names.

## 6. Delivery sequence

### Phase A — contract freeze

#### RX1. Baseline, scope, and evidence freeze

**Depends on:** closed molecular programme.  
**Purpose:** make every later change measurable.

Deliver:

- checksummed corpus, test, API, wire-schema, manuscript, and environment
  manifests;
- a public-surface inventory and compatibility policy;
- a coverage matrix by geometry, lifecycle, outcome, coupling, context, and
  serialization status;
- a backlog disposition: implement, preserve losslessly, reject explicitly,
  or defer with named evidence needed;
- permanent tests for racemic-versus-unknown, mapping invariance,
  non-invertible reversal, and proof tampering.

**Hard gate:** the 80+8 and 62-case baselines reproduce from documented
commands; every current public claim has an evidence owner; no production code
has changed.

#### RX2. Reaction information model and refusal taxonomy

**Depends on:** RX1.  
**Purpose:** close semantics before changing representations.

Deliver:

- normative definitions for the five axes in Section 3;
- transition tables for retained, inverted, formed, broken, fleeting, and
  unspecified descriptors;
- outcome algebra for single, racemic, enantiomeric-mixture, and weighted
  branches;
- coupling semantics separating correlation from Cartesian branching;
- typed refusal codes for invalid references, unsupported geometry, ambiguous
  alignment, lossy projection, missing context, assignment limits, and
  irreversible information loss.

**Hard gate:** every baseline record and negative fixture maps to exactly one
valid semantic state or one typed refusal; no state uses `@`/`@@`, CIP labels,
atom maps, or source order as chemical truth.

### Phase B — core representation

#### RX3. Stable value model and schema v2

**Depends on:** RX2.  
**Purpose:** make guards, effects, outcomes, and couplings immutable,
validatable, and versioned.

Deliver:

- invariants and constructors for the existing reaction-stereo values;
- canonical equality/hash/order behavior;
- versioned dict/JSON schema with explicit upgrade/downgrade behavior;
- duplicate-target and contradictory-assertion rejection;
- public exports and compatibility tests for existing payloads.

**Hard gate:** every supported value round-trips byte-stably after
normalization; old readable payloads remain readable; lossy downgrade is
refused with a typed report.

#### RX4. Reference transport and change calculus

**Depends on:** RX3.  
**Purpose:** prove chemical configuration relations under changed
neighborhoods.

Deliver:

- total validation of retained, replaced, removed, inserted, explicit-H, and
  virtual-reference alignments;
- support for single and multiple reference replacements;
- orbit-based retained/inverted classification across all public families;
- composition, relabeling, mirror, and reversal laws;
- explicit non-invertibility for unknown or destroyed information;
- legacy comparison retained only as migration evidence.

**Hard gate:** exhaustive small-permutation and deterministic relabeling tests
prove that descriptor syntax alone cannot change the chemical classification;
every ambiguous alignment fails closed.

#### RX5. Stereo-bearing ITS and DPO closure

**Depends on:** RX4.  
**Purpose:** make stereo part of the reaction graph rather than side metadata.

Deliver:

- normalized reactant, product, and transition stereo registries;
- stereo-only reaction-centre detection;
- extraction, reversion, relabeling, composition, and serialization laws;
- DPO gluing/dangling validation for descriptor supports and virtual
  references;
- explicit reporting where a legacy graph format cannot carry stereo.

**Hard gate:** topology-preserving stereo changes survive ITS
construction/reversion and atom relabeling; unsupported graph export reports
loss rather than silently dropping the layer.

### Phase C — rule and execution semantics

#### RX6. Exact and generic rule extraction

**Depends on:** RX5.  
**Purpose:** extract reusable rules without leaking the source molecule.

Deliver:

- exact guard/effect extraction from endpoint and transition layers;
- typed wildcard domains and evidence-preserving genericization;
- deterministic rule identity and serialization;
- source replay and reverse replay proofs;
- negative tests for stale references, over-broad wildcards, unsupported
  generalization, and template leakage.

**Hard gate:** every accepted generic rule replays its source in strict mode;
every reversible rule replays backward; rejected genericizations carry a typed
reason; source atom IDs outside the declared rule interface do not affect rule
identity.

#### RX7. Reactor matching, propagation, and branch algebra

**Depends on:** RX6.  
**Purpose:** apply stereo rules predictably and with bounded cost.

Deliver:

- normative behavior for all four reactor stereo modes;
- exact and wildcard matching with assignment budgets;
- propagation of retained/inverted/formed/broken/unspecified effects;
- branch enumeration, probability multiplication, normalization policy, and
  deterministic ordering;
- deduplication that preserves accumulated weight, multiplicity, and
  provenance;
- explicit behavior for partially specified substrates and products.

**Hard gate:** the same chemistry is invariant to atom/component/rule order;
unknown never expands into a racemate without an outcome assertion; branch and
assignment limits fail with typed, reproducible errors.

#### RX8. Coupled local outcomes

**Depends on:** RX7.  
**Purpose:** close correlations that independent local effects cannot express.

Deliver:

- stable serialization and reversal for `syn`/`anti` vicinal addition and
  elimination couplings;
- reviewed positive and negative coupling cases in the frozen corpus;
- planar-input and paired-tetrahedral-output validation;
- correlation-preserving enumeration and deduplication;
- an extension contract for later ring/pericyclic couplings without claiming
  their selectivity now.

**Hard gate:** at least one reviewed forward/reverse case for each supported
coupling mode passes extraction, serialization, strict replay, and relabeling;
no coupled branch is replaced by an independent Cartesian product.

### Phase D — composition and proof

#### RX9. Composition, reversal, and fusion proof

**Depends on:** RX6–RX8.  
**Purpose:** make multi-rule transformations auditable.

Deliver:

- effect composition including fleeting descriptor formation/removal;
- outcome-weight and coupling composition rules;
- compatibility checks when fusing guards/effects/outcomes/couplings;
- completion and freeze of fusion proof v2 unless an evidenced incompatibility
  requires a versioned successor;
- tamper detection, proof replay, and continued proof-v1 readability.

**Hard gate:** accepted fused rules reproduce the sequential transformation
and branch measure; incompatible or lossy fusions are rejected; every proof
field is covered by a mutation/tamper test.

#### RX10. Mechanism and multi-step replay

**Depends on:** RX9.  
**Purpose:** distinguish endpoint agreement from a valid stereo trajectory.

Deliver:

- stable endpoint and stepwise verification modes;
- a typed stereo-state timeline across mechanism steps;
- composition of preserved, inverted, broken, formed, fleeting, and
  unspecified effects;
- branch provenance across alternative mechanism paths;
- explicit handling of irreversible information loss and missing context.

**Hard gate:** stepwise mode rejects a path whose endpoints agree but an
intermediate stereo assertion is invalid; endpoint mode remains a documented
weaker contract; replay is invariant to consistent relabeling.

### Phase E — interchange and scientific evidence

#### RX11. Interchange and serialization matrix

**Depends on:** RX3–RX10.  
**Purpose:** make transport loss visible at every boundary.

Deliver:

- canonical JSON/dict and stable schema fixtures;
- a matrix for reaction SMILES, CXSMILES, MOL V3000, GML, and internal graph
  formats;
- explicit-H, virtual-H, isotope, component-order, equivalent-mapping, and
  mapless-input fixtures;
- generated serialization variants rather than hand-maintained duplicates;
- preserve/refuse behavior for enhanced groups and unsupported descriptor
  families.

**Hard gate:** every supported route round-trips the semantic reaction value;
every unsupported route emits a machine-readable loss/refusal report; no
writer silently erases guards, effects, outcomes, or couplings.

#### RX12. Corpus expansion and chemistry-stratum review

**Depends on:** RX8, RX10, RX11.  
**Purpose:** replace implementation-shaped coverage with chemistry-shaped
evidence.

Deliver:

- a reviewed matrix spanning lifecycle effects, outcome types, coupling modes,
  tetrahedral, double-bond, axial/atrop, planar/helical/framework where
  currently supported;
- promoted coupling, localized epimerization, ring, isotope, enhanced-group,
  pericyclic, heteroatom, and negative cases only where an oracle is defensible;
- for every deferred family, a named representation or oracle blocker;
- independent review fields: provenance, mathematical rationale, chemical
  rationale, executable status, reverse expectation, and limitations.

**Hard gate:** every public semantic branch has at least one positive and one
negative or refusal witness; no count target is met by cosmetic serialization
duplicates; all cases pass schema and reviewer checks.

#### RX13. Metamorphic, adversarial, and performance validation

**Depends on:** RX12.  
**Purpose:** prove invariance, fail-closed behavior, and bounded execution.

Deliver:

- atom relabeling, component order, descriptor order, mirror, reversal, and
  serialization metamorphs;
- malformed-reference, contradictory-effect, proof-tamper, stale-virtual-H,
  branch-explosion, and assignment-explosion attacks;
- deterministic result and evidence ordering across supported environments;
- runtime, memory, branch-count, and proof-size budgets with documented
  hardware/environment;
- complete-suite, lint, file-size, docs, and clean-diff gates.

**Hard gate:** all supported metamorphs preserve the declared semantics; all
invalid cases fail with the expected typed refusal; budgets pass without
benchmark-ID shortcuts or hidden truncation.

### Phase F — review and closeout

#### RX14. Documentation, ACS paper, and release-ready closeout

**Depends on:** RX13.  
**Purpose:** make the implementation and scientific claims independently
reviewable.

Deliver:

- one public API guide with migration instructions, executable examples, and
  limitations;
- ACS JCIM manuscript and supporting information synchronized with the frozen
  evidence;
- a claim-to-test-to-artifact matrix;
- final checksums, test counts, environment manifest, generated figures, and
  repository diff audit;
- a release-readiness report that explicitly lists any action still requiring
  user authorization.

**Hard gate:** RX1–RX14 each have linked evidence; all maintained gates pass;
every number in the paper is generated from the final frozen artifacts; no
known unsupported case is described as solved.

## 7. Requirement traceability

| ID | Requirement | Owner | Rechecked |
|---|---|---|---|
| SR1 | Freeze current behavior and evidence before implementation | RX1 | RX13–RX14 |
| SR2 | Keep lifecycle, relation, population, determinacy, and context independent | RX2 | all |
| SR3 | Provide immutable, versioned reaction-stereo values | RX3 | RX11, RX14 |
| SR4 | Classify configuration only after validated reference transport | RX4 | RX12–RX13 |
| SR5 | Carry stereo in ITS/DPO, including stereo-only centres | RX5 | RX9–RX13 |
| SR6 | Extract exact/generic rules with replay evidence and no leakage | RX6 | RX9, RX12–RX13 |
| SR7 | Apply rules with explicit modes, limits, weights, and dedup semantics | RX7 | RX12–RX13 |
| SR8 | Preserve correlated local outcomes as couplings | RX8 | RX12–RX13 |
| SR9 | Compose and fuse only when the resulting assertion is provable | RX9 | RX13 |
| SR10 | Separate endpoint agreement from valid stepwise mechanism replay | RX10 | RX12–RX13 |
| SR11 | Round-trip or report loss at every interchange boundary | RX11 | RX13 |
| SR12 | Support claims with reviewed chemistry-shaped evidence | RX12 | RX14 |
| SR13 | Prove invariance, tamper resistance, fail-closed behavior, and bounded cost | RX13 | RX14 |
| SR14 | Make code, evidence, and paper mutually traceable | RX14 | final |

## 8. Gate protocol

Every sprint must:

1. enter with all predecessor gates green and a recorded worktree boundary;
2. add or freeze its fixtures and expected refusals before broad production
   edits;
3. record focused test commands and exact results in `SS_LOG.md`;
4. run affected adjacent suites, lint, the Python file-size gate, schema
   validation, local-link validation, and `git diff --check`;
5. update the requirement matrix and document any deliberately unsupported
   behavior;
6. stop at the hard gate. Later-sprint work must not be pulled forward merely
   to make a test pass.

A sprint is not complete because code exists. It is complete only when its
semantic contract, implementation, positive/negative evidence, compatibility
behavior, documentation, and hard gate all agree.

## 9. Programme-level stop conditions

Pause the affected sprint and escalate if:

- a proposed change would alter the closed molecular stereograph semantics;
- two public surfaces encode contradictory meanings for the same field;
- a backward-compatible schema upgrade is impossible;
- a claimed chemical outcome lacks a defensible oracle;
- an apparently reversible rule destroyed configuration information;
- product deduplication changes total probability or loses correlation;
- a benchmark improvement depends on record identity, expected output, map
  numbering, or serialization order;
- completing the work would require release, push, submission, or another
  external action not separately authorized.

## 10. Final definition of done

The stereo reaction-graph programme is complete only when:

- all fourteen sprint gates are closed in order;
- SR1–SR14 each link to machine-readable and human-reviewable evidence;
- the frozen 80+8 and 62-case baselines remain reproducible, with every change
  explained rather than overwritten;
- rule extraction, reaction application, ITS/DPO, fusion, and mechanism replay
  share one information model;
- unknown configuration is never reported as a population;
- correlations and weights survive branching, composition, and deduplication;
- every supported serialization round-trips and every unsupported one reports
  loss explicitly;
- the expanded corpus covers every public semantic branch with reviewed
  positive and negative evidence;
- invariance, tamper, performance, lint, docs, and complete-suite gates pass;
- the ACS manuscript states exactly what the frozen evidence proves;
- release, push, and submission remain separate user-authorized actions.
