# Stereo composition and fusion contract

RX9 closes semantic composition and freezes fusion proof v2. No new fusion
proof schema was required.

## Semantic composition

- Sequential effects compose only when the first product descriptor equals
  the second reactant descriptor after reference transport.
- Retain/invert relations compose through orbit witnesses, not raw parity.
- Form-then-break becomes a fleeting descriptor.
- Break-then-form refuses as `STEREO_COMPOSITION_INFORMATION_LOSS`.
- A second-step guard must match the transported first-step product.
- Independent declared outcome weights multiply. Branches with the same final
  choices aggregate their measure and retain every raw path contribution.
- Two outcomes or two couplings at the same target refuse until an explicit
  richer correlation model exists.
- Reversal refuses population declarations, unspecified information loss, and
  prior refusals.

The composition proof schema is
`synkit.reaction-stereo-composition/1`; its digest binds the fused semantic
value, every branch contribution, correlation policy, and total measure.

## Fusion proof v2

`synkit.fusion-proof/2` remains sufficient for the current information model.
Newly serialized v2 documents now include `document_digest`, which binds every
top-level and nested proof field. Local stereo witness replay is validated
before the document checksum so precise witness errors remain available.
Proof v1 remains readable as a compatibility projection; older v2 documents
without the additive document checksum remain readable but are not reported
as document-digest verified.

## Gate evidence

- Focused composition and verified-fusion tests: 103 passed.
- Adjacent Fusion, MTG, Stereo, Rule/Compose, and Reactor gate: 2,147 passed,
  1 skipped, and 115 subtests passed.
- Strict new-file lint, compatibility lint, Python compilation, and
  `git diff --check`: passed.
