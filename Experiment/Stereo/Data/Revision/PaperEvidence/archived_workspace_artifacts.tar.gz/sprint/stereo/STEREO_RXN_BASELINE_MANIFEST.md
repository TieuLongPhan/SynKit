# Stereo reaction baseline manifest

**Sprint:** RX1  
**Frozen:** 29 July 2026  
**Repository commit:** `2555754863fd45935a7e68c8c067c56936ffdde2`  
**Branch:** `stereo`  
**Status:** immutable pre-implementation baseline

## 1. Environment boundary

Two environments exist and are deliberately recorded separately.

| Role | Python | RDKit | SynKit | pytest |
|---|---|---|---|---|
| Corpus snapshot recorded in `stereo.json` | 3.12.12 | 2026.03.1 | 1.5.0 | not recorded |
| Active repository interpreter on 29 July | 3.12.12 | 2026.03.1 | 1.6.1b1 | unavailable |
| Available `synkit` test runner | 3.11.0 | 2025.09.3 | working-tree import, package reports 1.6.1b1 | 9.0.1 |

The test runner was invoked as
`/home/lolo/.conda/envs/synkit/bin/python -m pytest`. Calling its `pytest`
console script directly did not put the repository root on `sys.path`; that is
an environment-launcher issue, not a product failure.

RX13 must either recreate the corpus environment with a test runner or record
both environment lanes again. It must not silently describe the Python
3.11/RDKit 2025.09 result as a Python 3.12/RDKit 2026.03 result.

## 2. Frozen source artifacts

| Artifact | SHA-256 |
|---|---|
| `Experiment/Lewis/mech_path/Data/MechanismBench/stereo.json` | `99c7794d16eb6e07504fa6987915e6d384f253a8b6878e51345129a40c851426` |
| `Test/Graph/Stereo/test_migration_closeout.py` | `31002e42b77957b855c6736cfdbd7042ef9d988e3f81c9f1bd27586be79cfab4` |
| `paper/stereo_rxn/main.tex` | `75cd1b2901e84d34e677620712651f5efe450b354e831f5abe02256022ada611` |
| `paper/stereo_rxn/references.bib` | `383fa6fbc3e09885fba6d07d7b255cb450522d1a192ff4f19e7a764f28e1de8e` |

The corpus identifies itself as `MechanismBench-stereo-v1`, status
`reviewed_80_positive_baseline`, generated 17 July 2026.

## 3. Frozen corpus boundary

| Partition | Count |
|---|---:|
| Positive transformations | 80 |
| Negative assertions | 8 |
| Executable | 73 |
| Graph-only | 4 |
| Deferred isotope support | 3 |
| Specification-only negatives | 8 |

Positive representations:

| Representation | Count |
|---|---:|
| Reaction SMILES | 40 |
| Native stereo rewrite | 29 |
| Mechanism replay | 7 |
| Non-tetrahedral rewrite | 4 |

The 69 reaction-SMILES/native cases with the original reaction oracle cover:

- local geometry: created 29, destroyed 8, erased-then-created 2, inverted 12,
  retained 14, not applicable 2, unknown 2;
- descriptor change: created 31, destroyed 7, fleeting 2, flipped 13,
  racemized 2, retained 12, unspecified 2;
- product population: single stereoisomer 42, racemic 11, enantiomeric mixture
  4, meso 5, achiral 5, unknown 2.

Eleven records use representation-specific conformance/replay oracles instead
of the older `oracle.local_geometry` axes: four non-tetrahedral rewrites and
seven Phase-2R mechanism replay cases. RX2 must map these to the unified
information model without rewriting their reviewed evidence.

Traversed executable declarations in the manifest include:

- effects: `BREAK` 6, `FORM` 15, `INVERT` 7, `PRESERVE` 11,
  `UNSPECIFIED` 3;
- outcomes: `RACEMIC` 8 and `ENANTIOMERIC_MIXTURE` 4;
- reviewed coupling declarations: 0.

The lack of reviewed `SYN`/`ANTI` coupling records is a frozen coverage gap,
not an implementation failure. RX8 owns its closure.

## 4. Frozen migration boundary

The orbit-versus-legacy closeout contains 62 comparisons:

- 58 agreements;
- 4 registered nonbinary differences;
- 0 unexpected differences.

The legacy projection remains migration evidence only. It is not an execution
fallback or scientific oracle.

## 5. Test baseline

Focused reaction-stereo stack:

```text
416 passed in 85.64s
```

The focused command covered reaction relations, migration, ITS
construction/destruction/relabeling, generic extraction, six-geometry
genericization, stereo reactor behavior/outcomes/conformance, fusion proof v2,
and mechanism models/replay/evidence.

Complete maintained repository suite:

```text
3919 passed, 31 skipped, 179 subtests passed in 175.43s
```

Both results were obtained with the Python 3.11/RDKit 2025.09 test lane
described in Section 1 and the pre-existing dirty worktree described below.

## 6. Public surface inventory

| Layer | Frozen public/serialized surface | Compatibility policy |
|---|---|---|
| `Graph/Stereo` | `StereoReferenceAlignment`, `StereoChange`, alignment/classification, `StereoOutcome`, `StereoCoupling`, descriptor dict values and public errors | Existing payloads remain readable; raw descriptor syntax is never a change oracle. |
| ITS | graph keys `stereo_descriptors`, `stereo_changes`, `stereo_outcomes`, `stereo_couplings`; construction and reversion | Preserve endpoint/transition layers and stereo-only centres. Lossy graph projections must report loss. |
| Rule | `stereo_guards`, `stereo_effects`, `stereo_outcomes`, `stereo_couplings`, reverse outcomes, query policies, `reversed()` | New validation may reject malformed values; accepted old values retain meaning. |
| Generic extraction | schema `synkit.stereo-rule-extraction/1`, source/reverse replay evidence | Keep schema readable; version any new required field. |
| Reactor | modes `ignore`, `require`, `propagate`, `strict`; wildcard assignment limit; branch weights and metadata | Preserve mode names and documented default. Resource limits fail explicitly. |
| Fusion | proof schemas `synkit.fusion-proof/1` and `/2` | v1 stays readable; v2 stays replayable. A v3 needs a demonstrated v2 representation failure. |
| Mechanism | schema version `2.0.0-draft1`; endpoint stereo, step stereo effects, verification modes, MTG stereo state | Draft payloads remain readable; endpoint and stepwise claims remain distinct. |

## 7. Dirty-worktree boundary

The following changes existed before RX1 and belong to the earlier LWG replay
work. They must be preserved and must not be attributed to stereo-reaction
implementation:

- `Experiment/Lewis/rule_replay/Data/README.md`
- `Experiment/Lewis/rule_replay/Data/bidirectional-replay/results.json`
- `Experiment/Lewis/rule_replay/Data/bidirectional-replay/tuple-cases.jsonl.gz`
- `Experiment/Lewis/rule_replay/Data/graph-rewriting-comparison.png`
- `Experiment/Lewis/rule_replay/benchmark.py`
- `Experiment/Lewis/rule_replay/plot.py`
- `Test/Graph/ITS/test_electron_aware_its.py`
- `synkit/Graph/ITS/rc_extractor.py`
- `synkit/IO/chem_converter.py`
- untracked `Test/Benchmark/Lewis/test_minimal_lwg_replay.py`

The RX programme may edit an overlapping ITS file only after reviewing and
preserving the existing diff.

## 8. Permanent scientific sentinels

All later sprints must retain tests proving:

1. unknown configuration is not a racemic or mixed population;
2. `@` versus `@@` is not a reaction-change classifier;
3. atom-map relabeling does not change reaction-stereo meaning;
4. destroyed or unspecified information cannot be reversed into a specified
   configuration;
5. correlated alternatives are not independent Cartesian branches;
6. a mutated fusion/mechanism proof fails validation;
7. unsupported interchange loss is reported rather than hidden.

## 9. RX1 exit decision

RX1 passes:

- corpus and migration boundaries are frozen and checksummed;
- focused and complete suites pass;
- environment lanes and the dirty worktree are explicit;
- public APIs/schemas have a compatibility policy;
- coverage gaps and later owners are named;
- no production code, benchmark payload, or manuscript content changed in
  RX1.

