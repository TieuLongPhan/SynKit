# Reaction-stereo follow-up evidence

Store only bounded, machine-readable SF1--SF4 evidence here. Each artifact
must identify its input digest, protocol, platform, package revision, and
generation command. Bulk benchmark output stays outside the commit tree.
