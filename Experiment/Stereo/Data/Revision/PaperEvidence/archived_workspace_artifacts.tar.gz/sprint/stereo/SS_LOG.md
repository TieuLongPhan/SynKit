# Stereo-graph session log

## 28 July 2026 — cycle reset

- Closed the previous mixed Sprint 0--44 workspace.
- Preserved all 84 entries in:
  `older/stereo_sprints_0-44_2026-07-28.tar.gz`.
- Verified the gzip/tar archive and recorded SHA-256
  `cdb38e9ab79bad265e32154f372359c6fa142dab6334af6865b54588e127f5ff`.
- Restarted numbering at Sprint 1.
- Restricted the new workspace to molecular stereo graph; stereo reaction is
  now a separate programme.
- Selected global/topological stereo closure, with `VS300` as the primary
  public regression, for Sprint 1.
- Expanded `sprint_1.html` into an implementation-ready contract with eight
  work packages, explicit module ownership, a formal test matrix,
  identity-profile regression gates, planned commands, and record-specific
  shortcut prohibitions.
- Corrected the paper/benchmark framing: preserve 256/258 as the audited
  baseline; classify VS170 as an identity-definition difference and VS300 as
  a current global-stereo capability boundary. Any later 257/258 result must
  be reported separately and must not erase the two-case mismatch analysis.
- No production code, tests, version, release, tag, or commit was changed as
  part of the cycle reset.

## Resume instructions

1. Read `README.md` and `CURRENT_PROGRESS.md`.
2. Read `sprint_plan.html`, then treat the numbered page named in
   `CURRENT_PROGRESS.md` as the active contract.
3. Do not extract the old archive into the active workspace.
4. Keep reaction transport and mechanism inference out of this cycle.
5. Record implementation evidence here when Sprint 1 work begins.

## 28 July 2026 — Sprint 1 evidence and architecture

- Froze the exact chemical-identity ACS audit at 256/258 in
  `evidence/sprint_1_exact_acs_256_baseline.json`.
  - 258/258 records are definitive.
  - The only disagreement IDs are `VS170` and `VS300`.
  - VS170 is chiral under chemical identity because `S-I` and `S#I` remain
    distinct; this is an identity/task-definition difference.
  - VS215 and VS216 are achiral under the exact resonance family.
  - VS300 is achiral under the restored independent-local-descriptor contract.
- Added the reproducible diagnostic
  `Experiment/Stereo/Chirality/vs300_diagnostic.py` and generated
  `evidence/vs300_global_stereo_diagnostic.json`.
- The VS300 audit established:
  - ordinary sanitized RDKit input contains no retained local chiral tags;
  - the exact audit restores source tags at atoms 2, 4, and 18;
  - sanitized topology completion probes atoms 2, 4, and 18 and returns
    chiral;
  - the source-restored exact registry admits a mirror isomorphism;
  - that representative mapping is blocked by the topology-probe bundle at
    source centers 18 and 4;
  - therefore this is a two-contract/coupled-framework issue, not evidence of
    one numerically incorrect local parity.
- Reduced the behavior to machine-readable fixtures in
  `fixtures/vs300_minimal_fixtures.json`:
  - 9-atom topology-completion positive `C1C2(OCC1)OCCC2`;
  - configured enantiomer pair using `C1[C@@]2(OCC1)OCCC2` and
    `C1[C@]2(OCC1)OCCC2`;
  - 9-atom achiral near-miss `C1C2(CCC1)CCCC2`.
- Accepted `GLOBAL_STEREO_ARCHITECTURE.md`: model the missing information as a
  coupled frame system over `GlobalStereoSupport`, with potential,
  orientation-unspecified, configured, and unsupported states kept distinct.
- Added permanent regression gates in
  `Test/Benchmark/Stereo/Chirality/test_vs300_diagnostic.py`.
- Validation:
  - new-file flake8: 0 findings;
  - repository Python file-size gate: passed;
  - focused stereo/chirality suite: 43 passed, 1 skipped.
  - regenerated diagnostic and fixture JSON are byte-identical to the frozen
    artifacts;
  - Sprint HTML validation and `git diff --check`: passed;
  - production-code record/SMILES special-case search: no matches.
- No production classifier, configured descriptor, public API, benchmark
  score, or paper baseline was changed in Sprint 1.

## Next implementation decision

Sprint 2 must decide which evidence sources may assert rigidity and whether
necessarily chiral but orientation-unspecified topology is a new molecular
outcome while its configured stereograph remains incomplete. Do not begin the
Sprint 3 formal descriptor or promote the current arbitrary topology-probe
parity into supplied configured identity until this contract is frozen.

## 28 July 2026 — split global closure into Sprints 1--10

- Replaced the monolithic Sprint 1 implementation plan with ten sequential,
  hard-gated sprints.
- Added `sprint_plan.html` with requirement traceability R1--R10, sprint
  dependencies, universal prohibitions, and the final completion gate.
- Added focused `sprint_1.html` through `sprint_10.html` pages. Every page now
  states its deliverables, required tests/evidence, dependency, and exit gate.
- Reclassified the completed evidence/design work as completed Sprint 1.
- Set Sprint 2, information states and molecular outcomes, as the next active
  sprint. Production implementation remains unchanged.
- Updated `stereo_graph_roadmap.md`, `README.md`, and
  `CURRENT_PROGRESS.md` to use the ten-sprint sequence.
- Validated all eleven HTML pages, every local page link, shared styling,
  frozen artifact checksums, and `git diff --check`; visually reviewed the
  master plan at desktop width.

## 28 July 2026 — Sprints 2--8 implementation

- Sprint 2 accepted `GLOBAL_STEREO_INFORMATION_MODEL.md`: potential support,
  necessary chirality with unspecified orientation, configured positive and
  negative, incomplete configured comparison, and unsupported evidence are
  distinct. Only explicit provenance may select configured orientation.
- Sprint 3 added the immutable, RDKit-independent `FrameworkFrame`,
  `FrameworkStereo`, and `GlobalStereoCertificate` model with validation,
  inversion, relabeling, equality, hashing, and typed state consistency.
- Sprint 4 integrated exact dict/JSON restoration, stable `global:<support>`
  identity, catalogue/public exports, overlap rejection, old-payload
  compatibility, and explicit RDKit projection refusal.
- Sprint 5 added coupled support, frame, representation, slot, relation, and
  virtual-ligand gadgets to the existing coloured auxiliary stereograph.
  Atom, support, frame, slot, descriptor, and registry ordering are
  quotiented; configured opposites remain distinct.
- Sprint 6 integrated reflection exactly once and verified double inversion,
  enantiomer, diastereomer, mirror-fixed near-miss, and mixed local/global
  composition without CIP.
- Sprint 7 added `analyze_global_stereo_support` and the explicit-provenance
  configured constructor. Positive, near-miss, VS300, atom renumbering,
  disconnected systems, malformed evidence, and fail-closed 256-atom/64-frame
  limits are tested.
- Sprint 8 retained the existing source-declared exact and ACS-specialized
  paths. Regressions verify VS170 as the chemical/ACS identity boundary,
  VS215/216 across the chemical resonance family, and VS300 under separately
  named source and global contracts.

## 28 July 2026 — Sprint 9 evidence

- Reproduced the frozen 256/258 baseline unchanged:
  258/258 definitive, disagreements `[VS170, VS300]`.
- Ran `synkit.exact-plus-global-certificate-acs/1` over all 258 records:
  258/258 definitive, 257/258 agreement, sole disagreement `VS170`.
- Wrote the new result only to
  `evidence/sprint_9_exact_plus_global_certificate_acs.json`; it does not
  replace the Sprint 1 artifact.
- Recorded exact auxiliary-graph size, source-declared comparison time,
  global comparison time, and traced Python peak memory in
  `evidence/sprint_9_global_stereo_performance.json`.
  - minimal positive: 9 atoms, 90 auxiliary nodes, 148 edges, chiral;
  - near-miss: 9 atoms, 90 auxiliary nodes, 148 edges, achiral;
  - VS300: 30 atoms, 291 auxiliary nodes, 472 edges, chiral.
- Audited production source: no VS300 ID, fixture-SMILES, expected-label,
  manual-label, CIP, atom-map, or arbitrary fixed-parity shortcut was added.

## 28 July 2026 — Sprint 10 closeout

- Updated public graph/chem guides and API inventories. Added an offline
  intersphinx mode so a fresh strict documentation build is reproducible
  without weakening warnings.
- Updated the paper and SI to show all three protocol boundaries together:
  frozen exact 256/258, separate exact-plus-global 257/258, and specialized
  ACS 258/258. VS170 and VS300 retain different explanations.
- Regenerated the mismatch figure and built `main.pdf` (45 pages) and
  `si.pdf` (19 pages). PDF text contains the required 256/257/258 wording;
  logs contain no undefined references or fatal errors.
- Final commands and gates:
  - focused global suite: 28 passed;
  - `PYTHONPATH=. conda run -n synkit pytest -q`:
    3,890 passed, 31 skipped, 179 subtests passed in 145.32 s;
  - `conda run -n synkit ./lint.sh`: passed, including the 1,000-line gate;
  - offline `sphinx-build -E -W`: passed;
  - 11 sprint HTML files parse and every local link resolves;
  - `git diff --check`: passed.
- Added `COMPLETION_MANIFEST.md` with R1--R10 evidence, exact artifact
  checksums, base commit/worktree state, commands, and explicit later scope.
- Marked Sprints 1--10 complete. No release, commit, tag, submission, or
  stereo-reaction change was performed.

## 28 July 2026 — post-close RotA/CIP follow-up

- Added `axis_terminal_symmetry_witnesses`, exposing the exact axis-fixed
  automorphism used to reject constitutionally symmetric terminal frames.
- Added and froze 24 synthetic RotA negative controls:
  - 13 axis-like, symmetry-rejected cases;
  - 11 no-supported-axis cases;
  - 0 confirmed-axis false positives;
  - 24/24 reverse-renumbering invariant.
- Kept the negative claim constitutional. No barrier, isolation-timescale,
  stability, or handedness label was fabricated.
- Added a pinned CIP input-contract audit. VS010 and VS011 have byte-identical
  supplied SMILES and opposite helical label sets, proving that 300/300 is
  impossible for a deterministic SMILES-only API and that the ceiling is 299.
- Audited the external pinned `compounds_3d.sdf` without vendoring it. Atom
  positions 1--4 have opposite signed normalized volumes for VS010 and VS011;
  the witness is translation/proper-rotation invariant and
  reflection-sensitive. The 3D contract therefore distinguishes all
  SMILES-conflicting records.
- Preserved the distinction between input identifiability and algorithm
  correctness. Coordinates remove the VS010/VS011 information obstruction but
  do not implement helical perception, multi-unit Rule 4b, the complete
  hierarchical ring digraph, or coordination projection.
- Validation:
  - focused RotA/CIP and registry tests passed;
  - complete suite: 3,897 passed, 31 skipped, 179 subtests passed;
  - full lint and Python file-size gates passed;
  - strict offline Sphinx build passed;
  - `main.pdf` (45 pages) and `si.pdf` (19 pages) rebuilt without undefined
    references or fatal errors;
  - manifest JSON, benchmark shell syntax, and `git diff --check` passed.

## 28 July 2026 — coordinate CIP closure and clean handoff

- Added a fail-closed coordinate-orientation layer in
  `synkit/Chem/Molecule/coordinate_stereo.py`.
  - Atrop, cumulene-axis, tetrahedral, extended cis/trans, planar-bond, and
    helical coordinate witnesses are translation/proper-motion invariant.
  - Reflection-sensitive classes invert under reflection; planar E/Z remains
    reflection invariant.
  - Coplanar, degenerate, absent-reference, and numerically indeterminate
    geometry raises instead of inventing a configuration.
- Extended the pinned CIP 3D protocol without reading expected labels:
  - 2/2 helical records are exact;
  - 5/5 CT4 records are exact;
  - 4/7 AT records are exact;
  - the fully material-framed VS144 TH3 cumulene is exact;
  - constitutional mappings that do not collapse to one configured registry
    remain unassigned.
- Corrected cumulene CIP reporting to project labels at the two axis endpoints
  rather than every atom in the cumulene path.
- Froze `synkit.cip-native-validation/3` in
  `Experiment/Stereo/Data/Perception/cip_native_report.json`:
  - pinned-coordinate exact records: 187/300 (62.33%);
  - SMILES-only baseline: 175/300;
  - true-positive labels: 926/1,252;
  - emitted labels: 937;
  - micro recall: 73.96%;
  - micro precision: 98.83%;
  - 113 non-exact records: 83 ranking, 21 missing-orientation, and 9
    unsupported-class primary limitations.
- The remaining CIP work is deliberately not represented as fixed:
  - full hierarchical occurrence-digraph ranking and duplicate-node Rule 1b;
  - multi-unit Rules 4a/4b/4c/5 and Rule 6;
  - three constitutionally ambiguous AT transports;
  - the remaining TH3/TH5 axes and coordination projections.
  Naive flattened or atom-index tie-breakers were rejected because they
  regressed correct records or violated relabeling invariance.
- Updated the benchmark registry, experiment documentation, public chemistry
  guide/API, paper, SI, and frozen-report tests to distinguish the
  pinned-coordinate result from the 175/300 SMILES-only baseline.
- Final validation:
  - focused CIP/coordinate suite: 40 passed;
  - frozen benchmark/registry suite: 49 passed, 8 skipped;
  - complete suite: 3,907 passed, 31 skipped, 179 subtests passed in 146.90 s;
  - full lint and 1,000-line file-size gate: passed;
  - strict offline Sphinx build: passed;
  - `main.pdf` rebuilt at 45 pages and `si.pdf` at 19 pages;
  - manifest JSON, benchmark shell syntax, and `git diff --check`: passed.

## Next clean cycle — SynReactor serialization policy

Do not continue stereo work in the next context. Start with the reported
SynKit 1.6.0 `SynReactor.smarts_list` defect:

- Reproduce `dedup_its=False` aborting the complete raw ITS batch when one
  application cannot be serialized.
- Add an explicit policy such as
  `serialization_errors="raise"|"skip"`; preserve `"raise"` as the
  compatibility default.
- Under `"skip"`, omit only serialization failures, preserve the order of all
  valid raw applications, and emit one warning or typed diagnostic containing
  every skipped raw-application index.
- Do not catch rule-application, matching, or unrelated programming errors.
- Cover mixed valid/invalid, all-invalid, no-invalid, deterministic ordering,
  invalid-policy validation, `dedup_its=True` non-regression, docs, and
  changelog behavior.

No SynReactor production code was changed in this stereo cycle.

**State: ready to clear.**

## 28 July 2026 — SynReactor serialization policy

- Archived the complete dirty standalone `paper/lwg` repository, including
  its Git history, uncommitted manuscript state, and generated outputs, as
  `paper/archive/lwg-retired-2026-07-28.tar.gz`.
  - gzip and tar traversal passed;
  - SHA-256:
    `f12022e53ecab270d7624cb4aa895c55160e659f48f7540e3e12472ec33f7339`;
  - removed the active `paper/lwg` directory only after verification.
- Reconstructed all 11 `typesGH` rules directly from the reaction-center
  graphs in `M00001_graphormer_abs_rc.json` and applied them to all 25 spool
  molecules with `dedup_its=False`.
- Reproduced mixed serialization failures for `class:4` with
  `explicit_h=False`:
  - spool index 11: 3,840 raw ITS applications, 2,880 serializable and 960
    failures;
  - spool index 15: 4,480 raw ITS applications, 3,360 serializable and 1,120
    failures.
- Added `serialization_errors="raise"|"skip"` to `SynReactor` and
  `SynReactor.from_smiles`; `"raise"` remains the default.
- Under `"skip"`, valid results retain raw application order, exactly one
  `RawITSApplicationSerializationWarning` exposes all failed indices, and
  `serialization_failure_indices` caches the same tuple. The complete
  `its_list` remains available.
- Serialization policy handling does not catch matching, rewriting, reverse
  projection, or unrelated programming errors. Consolidated
  `dedup_its=True` behavior is unchanged.
- Corrected the default failure path so an unsuccessful lazy serialization
  does not poison `_smarts` with a partial list containing `None`.
- Validation:
  - focused policy suite: 23 passed;
  - complete reactor suite: 431 passed, 112 subtests passed;
  - full lint and 1,000-line Python file-size gate: passed;
  - strict offline Sphinx build: passed;
  - real fixture replay returned 2,880 and 3,360 valid SMARTS with one
    structured warning per mixed batch;
  - `git diff --check`: passed.

## 28 July 2026 — upstream MechanismBench packaging fix

- Reproduced clean-checkout collection failures caused by the global
  `*.json` ignore rule excluding the three canonical reviewed MechanismBench
  manifests while their tracked README and tests declared them on-branch data.
- Narrowly allow-listed:
  - `Experiment/Lewis/mech_path/Data/MechanismBench/polar.json`;
  - `Experiment/Lewis/mech_path/Data/MechanismBench/radical.json`;
  - `Experiment/Lewis/mech_path/Data/MechanismBench/stereo.json`.
- Kept generated
  `Data/MechanismBench/evidence/mechanismbench_evidence.json` ignored.
- Updated the benchmark README from the superseded 72-positive stereo
  boundary to the manifest's reviewed 80-positive baseline.
- Validation:
  - all five originally failing collection modules plus adjacent benchmark
    review/evidence modules: 257 passed;
  - repository-wide collection: 3,944 tests collected with no errors;
  - all three manifests parse as JSON;
  - lint/file-size gate and `git diff --check`: passed.

## 28 July 2026 — 1.6.1b1 publication and minimal-RC LWG replay

- Prepared and published SynKit `1.6.1b1`.
  - Added an LF checkout contract for JSON so frozen byte-level dataset
    fingerprints are stable on Windows.
  - Removed stale Hatch references to the deleted `Data/Mech` package path.
  - Built and inspected the source distribution and wheel; both passed Twine,
    excluded experiment/test material, and installed as `1.6.1b1` in a clean
    environment.
  - Published both artifacts through the trusted `PyPI publish` workflow from
    `stereo`; the one-shot push trigger is restricted to changes of that
    workflow file.
- Audited the original LWG-versus-legacy replay difference.
  - The induced tuple reaction center produced 95 fewer forward unique
    reactions than legacy across 73 records.
  - Record 2110 showed the cause directly: RC metadata marked six changed
    edges, while the returned induced graph silently added the unchanged
    `N40-O42` edge as a seventh rule edge.
  - Removing only induced context edges restored record 2110 from 2 to 8
    unique products, exactly matching legacy.
- Added an explicit `include_context_edges` reaction-center policy.
  - The default remains `True` for compatibility and stereo-dependent rules.
  - The LWG benchmark uses `False`, retaining participating/resource-changing
    nodes and explicitly changed edges without implicit internal context.
  - Added unit coverage for induced versus minimal extraction and a permanent
    record-2110 LWG/legacy parity regression.
- Reran the complete uncapped 39,732-record LWG benchmark in both directions.
  - 39,732/39,732 forward reference reactions recovered.
  - 39,732/39,732 backward reference reactions recovered.
  - Forward mappings/rewrites/serializable/unique:
    `114,983 / 98,667 / 98,514 / 96,042`.
  - Legacy forward baseline:
    `116,318 / 98,699 / 98,484 / 96,012`.
  - Backward mappings/rewrites/serializable/unique:
    `133,563 / 122,058 / 121,656 / 119,101`.
  - Legacy backward baseline:
    `132,363 / 122,058 / 121,401 / 118,846`.
  - No record retains a lower LWG unique-reaction count than legacy.
  - The 30 forward LWG-only products comprise 28 legacy serialization
    failures and 2 mappings unavailable to legacy.
  - The 255 backward LWG-only products comprise 194 legacy serialization
    failures, 60 mappings unavailable to legacy, and 1 same-mapping state
    difference.
- Replaced the retained tuple case evidence and refreshed the comparison
  figure for signed gains and reductions.
- Final validation:
  - complete suite: 3,919 passed, 31 skipped, 179 subtests passed;
  - full lint and 1,000-line Python file-size gate: passed;
  - compressed evidence integrity and `git diff --check`: passed;
  - source/data/documentation provenance-marker scan: no findings.
- The minimal-RC implementation, regression, refreshed evidence, and figure
  are local working-tree changes. They have not been committed or pushed.

**State: benchmark rerun complete; ready to clear.**

## 29 July 2026 — molecular stereograph paper closeout

- Converted the molecular stereograph manuscript to the JCheminformatics
  Springer format and consolidated the article and technical appendices into
  one `main.tex`.
- Removed the standalone-SI contract. The references now precede the complete
  technical appendices; no `si.tex` build remains.
- Formalized configuration-neutral carrier perception, authorized
  configuration attachment, faithful orbit expansion, exact configured-graph
  canonicalization, and the whole-molecule mirror-certificate decision.
- Clarified the chirality criterion: canonicalization first quotients arbitrary
  atom numbering; the original and globally mirrored configured stereographs
  then yield one certificate for an achiral/meso object and two mirror-related
  certificates for a chiral object.
- Reworked all nine main-text and five appendix figures against the LWG visual
  system: Okabe--Ito semantics, circular panel badges, pale cards, concise
  internal text, consistent chemistry colors, and restrained carrier
  highlighting.
  - Figure 3 is a readable 2-by-4 support hierarchy.
  - Figure 4 remains a four-column descriptor atlas.
  - Figure 5 is a compact formal local-orbit-to-global-certificate workflow.
  - Figure 8 is a 2-by-3 gallery of six real molecular mirror cases.
  - Figure 9 retains only the genuine A/D task-boundary differences.
- Final paper validation:
  - `main.pdf`: 52 pages, SHA-256
    `fdf07a4bd9bc931e4cd8cbe99112b6ca82050739e0c3a849ad3f440665e92d18`;
  - no LaTeX errors, undefined references/citations, or overfull boxes;
  - rendered figure pages were inspected at publication scale;
  - standalone `si.pdf` and its stale build products were removed.
- Benchmark numbers remain the current development snapshot and must be
  refreshed only when the running benchmark completes.

**State: molecular stereograph closed; context may be cleared; next programme
is stereo reaction graphs.**

## 29 July 2026 — stereo reaction-graph programme plan

- Audited the existing reaction-stereo implementation instead of treating the
  programme as greenfield work:
  - reference alignment and orbit-based `StereoChange`;
  - outcome and vicinal coupling values;
  - stereo-bearing ITS construction/reversion;
  - exact and generic stereo-rule extraction;
  - reactor matching, propagation, branching, weights, and assignment limits;
  - fusion proof v2 and endpoint/stepwise mechanism replay.
- Audited the reviewed `MechanismBench-stereo-v1` boundary:
  - 80 positive records and 8 negative assertions;
  - 62 orbit/legacy migration comparisons: 58 agreements, 4 registered
    nonbinary differences, and 0 unexpected differences;
  - no reviewed `SYN`/`ANTI` coupling record in the current corpus, making
    coupled-outcome evidence an explicit programme gate;
  - unresolved families classified as implement, preserve, typed refusal, or
    defer pending context/representation/oracle.
- Defined one normative reaction information model that keeps local geometry,
  descriptor lifecycle, configuration relation, product population,
  determinacy, and mechanistic context independent.
- Wrote a fourteen-sprint, six-phase programme:
  - RX1--RX2: baseline and semantic contract;
  - RX3--RX5: values, reference transport, ITS/DPO;
  - RX6--RX8: rule extraction, reactor algebra, coupled outcomes;
  - RX9--RX10: fusion/composition and mechanism replay;
  - RX11--RX13: interchange, reviewed corpus, validation;
  - RX14: documentation, ACS paper, and release-ready closeout.
- Added:
  - `stereo_rxn_plan.html`;
  - `stereo_rxn_roadmap.md`;
  - `stereo_rxn_sprint_01.html` through `stereo_rxn_sprint_14.html`.
- Each sprint has explicit dependencies, deliverables, positive/negative
  evidence, scope boundaries, and a hard exit gate. The programme-level
  SR1--SR14 traceability matrix, stop conditions, and final definition of done
  are in the detailed roadmap.
- Planning only: no production code, benchmark payload, manuscript content,
  release state, or external system was changed.

**State: complete stereo reaction-graph plan written; RX1 not started.**

## 29 July 2026 — RX1 baseline, scope, and evidence freeze

- Froze repository commit
  `2555754863fd45935a7e68c8c067c56936ffdde2` and preserved the pre-existing
  LWG replay worktree changes as a separate ownership boundary.
- Checksummed the reviewed stereo manifest, migration test, ACS manuscript,
  and bibliography.
- Reproduced the reviewed corpus boundary:
  - 80 positive transformations and 8 negative assertions;
  - 73 executable, 4 graph-only, 3 deferred-isotope, and 8
    specification-only records;
  - 40 reaction-SMILES, 29 native-rewrite, 7 mechanism-replay, and 4
    non-tetrahedral records.
- Froze the 62-case migration result: 58 agreements, 4 registered nonbinary
  differences, 0 unexpected differences.
- Recorded a real environment split:
  - active/corpus-compatible interpreter: Python 3.12.12, RDKit 2026.03.1;
  - available test runner: Python 3.11.0, RDKit 2025.09.3, pytest 9.0.1.
- Validation in the existing test lane:
  - focused reaction-stereo/ITS/rule/reactor/fusion/mechanism stack:
    416 passed in 85.64 seconds;
  - complete maintained suite: 3,919 passed, 31 skipped, 179 subtests passed
    in 175.43 seconds.
- Added `STEREO_RXN_BASELINE_MANIFEST.md` and the machine-readable
  `evidence/stereo_rxn_baseline.json`.
- Frozen named gaps:
  - no reviewed syn/anti coupling record (RX8);
  - 11 representation-specific oracles need unified semantic mapping (RX2);
  - fragmented reaction-stereo wire schemas (RX3);
  - incomplete uniform interchange-loss reporting (RX11).
- No production code, benchmark payload, or manuscript content changed.

**RX1 gate: passed. RX2 active.**

## 29 July 2026 — RX2 reaction information model

- Added public immutable values for:
  - lifecycle (`RETAINED`, `INVERTED`, `FORMED`, `BROKEN`, `FLEETING`,
    `UNSPECIFIED`);
  - product population, determinacy, evidence/context;
  - accepted assertion versus typed refusal decisions.
- Added ten stable refusal categories covering invalid references,
  unsupported geometry, ambiguous alignment, lossy projection, missing
  context, assignment/branch limits, irreversible information loss,
  contradictory assertions, and invalid couplings.
- Kept historical serialized descriptor changes independent from chemical
  configuration relations. Added a permanent corpus sentinel for cases that
  are chemically retained although their raw descriptor token flips.
- Enforced that unknown population is underdetermined and distinct from a
  racemic population.
- Mapped all 80 positive transformations and all 8 negative assertions to
  exactly one normalized decision, including the 11 representation-specific
  non-tetrahedral/mechanism cases.
- Added `STEREO_RXN_INFORMATION_MODEL.md`,
  `synkit/Graph/Stereo/semantics.py`, public exports, and semantic tests.
- Validation:
  - focused RX2/reaction/migration: 18 passed;
  - adjacent Graph/Stereo + mechanism workflow + reactor outcomes:
    1,631 passed, 1 skipped;
  - new-file flake8, Python compilation, and `git diff --check`: passed.

**RX2 gate: passed. RX3 active.**

## 29 July 2026 — RX3 stable values and schema v2

- Added `StereoReactionValue`, an immutable/hashable aggregate for guards,
  effects, outcomes, couplings, normalized assertions, and typed refusals.
- Added deterministic construction and JSON normalization:
  - target ordering cannot affect equality, hash, or bytes;
  - duplicate targets and incorrect descriptor/coupling ownership refuse;
  - outcomes require an effect at the same target;
  - public mapping views are read-only.
- Added lossless `StereoChange` and `StereoReferenceAlignment` dict readers and
  writers. Orbit relation evidence is rederived from descriptors/alignment.
- Added `synkit.reaction-stereo/2` and a dependency-free JSON-Schema view.
- Kept `synkit.reaction-stereo/1` and equivalent unversioned values readable.
  Downgrade refuses with `LOSSY_PROJECTION` when v2 assertions/refusals would
  be lost.
- Added `STEREO_RXN_SCHEMA.md` and RX3 wire tests.
- Validation:
  - focused RX2/RX3/reaction tests: 24 passed;
  - adjacent Graph/Stereo + rule + reactor + fusion + mechanism:
    1,670 passed, 1 skipped;
  - flake8, Python compilation, and `git diff --check`: passed.

**RX3 gate: passed. RX4 active.**

## 29 July 2026 — RX4 reference transport and change calculus

- Extended endpoint transport/application from the six fixed-frame local
  families to all eleven configured descriptor families, including cumulene,
  extended cis/trans, helical, planar chirality, and framework stereo.
- Distinguished replaceable peripheral references from path, plane, pilot,
  axis, bond, and global-support loci.
- Added alignment composition and relabeling, including owner-qualified
  virtual H/LP resources.
- Preserved inferred alignment status under reversal, closing the double
  reversal law.
- Added `StereoChange.then()`:
  - continuous sequential changes compose their reference maps;
  - formed-then-broken becomes a first-class fleeting descriptor;
  - broken-then-formed becomes a refused, non-invertible information-loss
    change instead of inventing configuration;
  - mismatched intermediate states refuse as noncomposable.
- Added covariance, inverse, double-reversal, multi-replacement, virtual
  resource, fleeting, information-loss, and noncomposable tests.
- Added `STEREO_RXN_TRANSPORT_CALCULUS.md`.
- Validation:
  - focused transport/value tests: 56 passed;
  - adjacent Graph/Stereo + generic rule + reactor + promoted rewrite +
    mechanism: 1,757 passed, 1 skipped;
  - compatibility-file lint with existing exclusions, strict new-file lint,
    Python compilation, and `git diff --check`: passed.

**RX4 gate: passed. RX5 active.**

## 29 July 2026 — RX5 stereo-bearing ITS and DPO

- Added optional transition graphs to both modern and legacy ITS constructors;
  transition-only descriptors now enter `stereo_descriptors.transition` and
  derive first-class `FLEETING` changes.
- Added explicit ITS stereo validation modes:
  - `preserve` retains the graph-only compatibility boundary;
  - `strict` validates endpoint/transition supports before construction.
- Added aggregate `StereoITSValidationError` with typed `INVALID_REFERENCE`
  refusals.
- Extended support validation to cumulene, extended cis/trans, helical,
  planar-chirality, and framework descriptors.
- Added strict rejection for missing ligands, broken paths, wrong registry
  ownership, and unavailable owner-qualified virtual H/LP resources.
- Preserved endpoint stereo registries through `ITSDestruction`; existing
  `ITSReverter` endpoint/transition projections remain lossless.
- Proved node-only minimal reaction centres for topology-preserving
  stereomutation while preserving the earlier independent
  `include_context_edges` LWG behavior.
- Added `STEREO_RXN_ITS_DPO_CONTRACT.md` and RX5 tests.
- Validation:
  - focused RX5/electron-aware tests: 19 passed;
  - adjacent ITS + transport + generic rule + promoted rewrite + fusion:
    170 passed;
  - strict new-file lint, compatibility lint with existing exclusions,
    Python compilation, and `git diff --check`: passed.

**RX5 gate: passed. RX6 active.**

## 29 July 2026 — RX6 exact and generic rule extraction

- Added strict reactant/product descriptor-support validation before
  `SynRule` construction. Dangling or stale references now refuse as
  `GENERIC_STEREO_INVALID_SUPPORT`.
- Preserved the conservative genericization contract:
  - only unchanged graph-backed peripheral material references become ports;
  - path/plane/framework loci and virtual H/LP resources do not;
  - class/corpus domains require explicit bounds;
  - corpus domains require aligned evidence.
- Made extraction certificates readable and self-verifying:
  - typed port constraints round-trip;
  - serialized payload includes its digest;
  - schema, duplicate port binding, and digest tampering are validated.
- Kept `synkit.stereo-rule-extraction/1`, atom-map-invariant identity, strict
  source replay, exact reverse replay, and certified non-invertible behavior.
- Added `STEREO_RXN_RULE_EXTRACTION_CONTRACT.md` and certificate/support tests.
- Validation:
  - focused extraction suites: 27 passed;
  - adjacent rule + ITS + transport + reactor + promoted rewrite + fusion:
    207 passed;
  - strict new-test lint, compatibility-module lint with existing exclusions,
    Python compilation, and `git diff --check`: passed.

**RX6 gate: passed. RX7 active.**

## 29 July 2026 — RX7 reactor semantics and branch algebra

- Froze and tested the `ignore`, `require`, `propagate`, and `strict` mode
  matrix for exact, inverse, and absent substrate stereo.
- Proved that propagation of absent orientation produces one unknown product,
  never an implicit population.
- Made branch traversal deterministic by sorted effect/coupling target and
  explicit `stereo_branch_path`.
- Omitted zero-measure alternatives and preserved multiplicative raw branch
  weights.
- Extended exact-product deduplication with aggregate weight, branch
  multiplicity, and lossless contributing branch/coupling/application
  provenance.
- Added `StereoBranchLimitError` and `stereo_branch_limit`; both assignment and
  branch limit errors expose permitted and requested-at-least budgets.
- Added `STEREO_RXN_REACTOR_CONTRACT.md` and RX7 conformance tests.
- Validation:
  - focused mode/branch/dedup and adjacent rule tests: 62 passed;
  - complete Reactor plus generic extraction suites: 457 passed and 112
    subtests passed;
  - strict new-file lint, compatibility-module lint with existing exclusions,
    Python compilation, and `git diff --check`: passed.

**RX7 gate: passed. RX8 active.**

## 29 July 2026 — RX8 correlated local outcomes

- Normalized coupling center order while preserving center/ligand pairing and
  rejected overlapping coupling support.
- Froze the closed supported mode set: SYN/ANTI vicinal addition and exact
  reverse elimination.
- Added strict input-context validation:
  - stereogenic alkene addition requires a specified planar descriptor;
  - elimination requires a specified correlated tetrahedral pair.
- Added paired reverse execution that reconstructs the unique compatible
  planar product and records paired-input provenance.
- Added explicit `joint_targets` to face branches, proving that two local
  centers are one correlated branch rather than a four-way Cartesian product.
- Added the reviewed `MechanismBench-stereo-coupling-v1` corpus with four
  E/Z × SYN/ANTI forward/reverse positives and four malformed or
  context-insufficient negatives.
- Added `STEREO_RXN_COUPLED_OUTCOME_CONTRACT.md`.
- Validation:
  - reviewed coupling corpus: 10 passed;
  - adjacent Graph/Stereo, Rule, and Reactor: 2,134 passed, 1 skipped, and 112
    subtests passed;
  - JSON validation, compatibility lint, strict new-test lint, Python
    compilation, and `git diff --check`: passed.

**RX8 gate: passed. RX9 active.**

## 29 July 2026 — added RX10 Figure 11 machinery requirement

- Recorded the user-supplied electrocyclic example as a distinct mechanism
  contract, not a vicinal SYN/ANTI coupling.
- RX10 must represent correlated conrotatory/disrotatory terminal motion,
  thermal/photochemical context, substituted forward/ring-opening reversal,
  and wrong-mode/missing-context/tamper negatives.

## 29 July 2026 — RX9 composition, reversal, and fusion proof

- Added proof-bearing composition of normalized reaction-stereo values.
- Composed reference-transported effects, including invert+invert retention
  and form+break fleeting behavior.
- Refused intermediate guard mismatch, broken-then-formed information loss,
  overlapping outcomes, overlapping couplings, assertion conflict, and
  population/information-loss reversal with typed issue codes.
- Added deterministic independent-outcome multiplication, convergence by
  final branch identity, accumulated measure, multiplicity, and raw path
  contributions.
- Proved a concrete two-SN2 sequential/direct-fused endpoint equivalence.
- Kept fusion proof v2 and added an additive complete-document digest; every
  newly serialized field is tamper-evident while proof v1 remains readable.
- Added `STEREO_RXN_COMPOSITION_FUSION_CONTRACT.md`.
- Validation:
  - focused composition and verified-fusion gate: 103 passed;
  - adjacent Fusion, MTG, Stereo, Rule/Compose, and Reactor: 2,147 passed, 1
    skipped, and 115 subtests passed;
  - strict new-file lint, compatibility lint, Python compilation, and
    `git diff --check`: passed.

**RX9 gate: passed. RX10 active.**

## 29 July 2026 — RX10 mechanism replay and Figure 11 machinery

- Made every replay mode explicit in `final_match`, including whether stereo
  verification was performed.
- Added checksum-bound typed stereo timelines with complete descriptor-state
  histories.
- Added first-class `ElectrocyclicStereoMotion`:
  - conrotatory/disrotatory;
  - ring opening/closure;
  - correlated terminal-motion witness;
  - 4π/6π electron count;
  - thermal/photochemical context;
  - mapped termini/substituents and provenance.
- Implemented the Figure 11 rule matrix: thermal 4π conrotatory, thermal 6π
  disrotatory, with photochemical inversions.
- Added correlated topology validation, exact reversal, record/schema
  roundtrip, atom-map invariant event/trajectory identity, and substituted
  ring evidence.
- Demonstrated the contract distinction: an endpoint-valid wrong rotation
  mode is invalid in stepwise verification.
- Added four reviewed machinery positives and three wrong-mode,
  missing-context, or motion-tamper negatives.
- Added `STEREO_RXN_MECHANISM_CONTRACT.md`.
- Validation:
  - focused machinery plus model/replay workflows: 93 passed;
  - complete Mechanism plus adjacent composition, MTG, and coupling suites:
    147 passed and 3 subtests passed;
  - JSON/schema validation, strict new-test lint, compatibility lint, Python
    compilation, and `git diff --check`: passed.

**RX10 gate: passed. RX11 active.**

## 29 July 2026 — RX11 interchange and serialization matrix

- Added one versioned, machine-readable interchange ledger covering format,
  semantic axis, affected targets, severity, status, and sidecar availability.
- Made canonical dict/JSON lossless primary routes for the complete
  `StereoReactionValue`.
- Added SHA-256-authenticated internal-graph and GML sidecars; sidecar
  tampering refuses before parsing semantic content.
- Classified Reaction SMILES, CXSMILES, and MOL V3000 as endpoint carriers:
  strict projection refuses each populated guard, effect, outcome, coupling,
  assertion, and refusal axis instead of flattening it.
- Added generated SER-01--SER-14 explicit-H, virtual-H, isotope, mapless,
  remapping, ordering, aromatic/Kekulé, enhanced-group, and V3000 carrier
  variants without counting them as chemistry evidence.
- Extended mechanism loss reports to include metadata, endpoint stereo, and
  Figure 11 electrocyclic motion; legacy descriptor GML now reports omitted
  graph metadata.
- Added `STEREO_RXN_INTERCHANGE_CONTRACT.md`.
- Validation:
  - complete adjacent Graph/Stereo, Mechanism, Fusion, MTG, Rule, and Reactor:
    2,347 passed, 1 skipped, and 115 subtests passed;
  - strict new-file lint, compatibility lint, Python compilation, and
    `git diff --check`: passed.

**RX11 gate: passed. RX12 active.**

## 29 July 2026 — RX12 reviewed chemistry branch coverage

- Added `MechanismBench-stereo-branch-coverage-v1`, a claim index over the
  frozen stereo, coupling, electrocyclic, and executable graph evidence.
- Covered every lifecycle, population, determinacy, evidence kind, configured
  descriptor family, coupling direction/relation, replay mode, execution
  route, and typed refusal code with one accepted and one boundary witness.
- Added a reviewed specification-only diastereomer-set assertion without
  claiming an executable population generator.
- Explicitly excluded SER-01--SER-14 serialization variants from chemistry
  evidence counts.
- Named representation/context/oracle blockers and promotion requirements for
  isotope/pseudoasymmetry, enhanced populations, ring-relative elimination,
  facial pericyclic selectivity, and advanced allene/spiro/coordination.
- Added `STEREO_RXN_COVERAGE_CONTRACT.md`.
- Validation:
  - focused schema/reviewer/chemistry gate: 41 passed;
  - adjacent Graph/Stereo, ITS, Mechanism, Fusion, MTG, Rule, and Reactor:
    2,399 passed, 1 skipped, and 115 subtests passed;
  - JSON parse, strict new-test lint, and `git diff --check`: passed.

**RX12 gate: passed. RX13 active.**

## 29 July 2026 — RX13 validation and repository gates

- Added a dedicated metamorphic/adversarial matrix for relabeling, ordering,
  serialization, reversal, malformed values, proof tamper, lossy carriers,
  and typed branch exhaustion.
- Audited production source for frozen ST/SC/EC case-ID shortcuts; none occur.
- Added a reproducible microbenchmark and frozen
  `synkit.stereo-rxn-validation/1` report with environment, wall/CPU, RSS,
  proof-size, branch, and assignment budgets.
- Enforced the 1,000-line ceiling over every changed reaction-stereo module.
- Added `STEREO_RXN_VALIDATION_CONTRACT.md`.
- Validation:
  - dedicated RX13 gate: 13 passed;
  - complete maintained suite: 4,055 passed, 31 skipped, and 179 subtests;
  - strict/compatibility lint, compilation, JSON parse, module size,
    `git diff --check`: passed;
  - offline strict Sphinx HTML: passed;
  - 15 programme HTML files and 108 local links: passed.

**RX13 gate: passed. RX14 active.**

## 29 July 2026 — RX14 documentation, ACS paper, and closeout

- Added one public reaction-stereo guide with integrated migration
  instructions, plus executable exact/generic extraction,
  branching/coupling, composition/interchange, and mechanism-replay
  workflows. Removed the separate migration page and its toctree entry; no
  stale document references remain.
- Synchronized the ACS `achemso` JCIM article, SI, cover letter, and package
  version with the final information model, evidence counts, interchange
  boundary, and unsupported-chemistry boundary.
- Kept the user-supplied Figure 11 machinery rule explicit as correlated
  electrocyclic motion: thermal 4π conrotatory, thermal 6π disrotatory, and
  the corresponding photochemical inversions.
- Added the RX1--RX14 and SR1--SR14 closeout matrix, frozen checksums,
  worktree provenance, and machine-readable gate record.
- Final validation:
  - complete maintained suite: 4,055 passed, 31 skipped, and 179 subtests in
    157.99 seconds after the single-guide consolidation;
  - strict offline Sphinx HTML with the unified guide: passed;
  - executable examples, validation workload, strict/compatibility lint,
    Python compilation, JSON parse, 1,000-line ceiling, local links, and
    `git diff --check`: passed;
  - ACS main article: 25 US-letter pages; SI: 11; cover letter: 2;
  - embedded fonts, vector figures, resolved references/citations, and zero
    overfull boxes: passed.

**RX14 gate: passed. RX1--RX14 complete.**

## 29 July 2026 — reaction experiment split and stereo visual audit

- Created `Experiment/StereoReaction` as the dedicated executable experiment
  root for reaction stereochemistry, separate from the molecular
  `Experiment/Stereo` programme.
- Moved the public reaction-stereo workflow from `examples/` to
  `Experiment/StereoReaction/workflows.py` and updated the Sphinx and SI
  reproduction references. The frozen MechanismBench corpus retained its
  checksum-bound canonical path under the mechanism experiment.
- Added two vector main-text figures:
  - a six-panel scenario atlas covering continuous transport, descriptor
    lifecycle/population, coupled outcomes, stereo-only reactions, non-binary
    reconfiguration, and endpoint/stepwise verification;
  - a dedicated Figure 11 electrocyclic panel covering the substituted
    thermal 4π and thermal 6π ring-opening fixtures, the complete
    thermal/photochemical conrotatory/disrotatory matrix, exact reversal, and
    the typed negative boundary.
- Audited the user-supplied Figure 11 question against implementation and
  evidence. It is solved as a **supplied-path verifier**: mapped termini and
  substituents, correlated terminal motion, electron count, activation,
  direction, topology, reversal, relabeling, serialization, and tamper
  detection are executable. Mechanism selection, activation prediction,
  torquoselectivity, and facial preference remain intentionally outside the
  claim.
- Validation:
  - moved public workflow: passed;
  - focused electrocyclic/workflow/RX13 suite: 38 passed;
  - strict offline Sphinx build: passed;
  - ACS main article: 26 pages; SI: 11 pages;
  - no overfull boxes, unresolved references/citations, or fatal TeX errors.

**State: RX1--RX14 semantics unchanged; experiment organization and manuscript
visualization enhanced.**

## 29 July 2026 — relative-neighbour electrocyclic certificate

- Replaced the provisional strict-terminal-descriptor interpretation with a
  reaction-local construction:
  1. derive the shared inward neighbour and tracked substituent at each
     terminus from the before/after graphs;
  2. canonicalize that relative pair by map-independent local chemistry;
  3. store the canonical signed rotation, frame-permutation parity, and both
     neighbours' before-to-after bond states.
- The stored object is `synkit.relative-neighbor-change/1`; local neighbour
  iteration order is evidence only and is never the persisted state.
- Correlated motion is checked after transporting the canonical sign through
  the recorded frame parity. This prevents asymmetric substitution from
  changing a physical conrotatory motion into an apparent disrotatory one.
- Added executable coverage for mapped and virtual neighbours, asymmetric
  frame reordering, nonadjacent-neighbour refusal, reversal, and atom-map
  transport.
- Validation:
  - focused electrocyclic and public-workflow gate: 28 passed;
  - complete Mechanism suite: 125 passed;
  - strict new-file lint, Python compilation through the test runs, and
    `git diff --check`: passed;
  - strict offline Sphinx HTML: passed;
  - ACS main article: 27 pages; SI: 11 pages; no overfull boxes or unresolved
    references/citations;
  - the four-contract atlas (page 11) and relative-neighbour Figure 11
    verifier (page 19) were inspected at publication scale.

**State: RX10 electrocyclic evidence refined to derive relative local frames,
canonicalize them, and persist reaction changes; no strict terminal molecular
descriptor is used.**

## 29 July 2026 — stereo handoff

- Final decision: electrocyclic terminal evidence uses relative local
  neighbours, followed by canonical frame ordering and persisted
  before-to-after changes. Strict molecular stereo descriptors are not used
  for this terminal-motion certificate.
- Canonical changes are stored in
  `certificate.final_match["canonical_neighbor_changes"]` and on the
  corresponding mechanism-transition edge.
- Figure locations in `paper/stereo_rxn/main.pdf`:
  - page 11: four-contract reaction-stereo scenario atlas;
  - page 19: Figure 11 electrocyclic scenarios and
    derive/canonicalize/store/compare pipeline.
- Final gates: 125 Mechanism tests passed; strict offline Sphinx passed; ACS
  main and SI PDFs rebuilt at 27 and 11 pages; lint and `git diff --check`
  passed.
- Scope remains explicit: Figure 11 is solved as a supplied-path verifier,
  not as a predictor of activation conditions, torquoselectivity, facial
  preference, or pathway selection.

**Handoff: stereo task complete; workspace ready for the next task.**

## 30 July 2026 — FLOWER replay-correctness Sprint F1

- Kept the closed stereo RX1--RX14 programme unchanged and opened one
  independent FLOWER correctness sprint.
- Formalized and repaired three replay invariants:
  - unchanged atoms preserve endpoint state outside the rewrite support;
  - degree-zero hydrogen components cannot be implicitized and retain their
    multiplicity;
  - ITS deduplication occurs only after endpoint electron state is finalized,
    making the quotient congruent with finalized endpoint serialization.
- Resolved:
  - `FLOWER-RPL-001`, coordination/metal endpoint charge drift;
  - `FLOWER-RPL-002`, free explicit-hydrogen loss;
  - `FLOWER-RPL-004`, provisional-state ITS deduplication.
- Retained `FLOWER-RPL-003` as an open performance/diagnostic boundary.
  A ten-second timeout remains a censored result, not a chemical failure.
- Exact full-reaction witnesses for unchanged Ag, changed Pd, free hydrogen,
  and distinct endpoint-state assignments now recover the reference in both
  directions.
- Validation:
  - invariant regressions: 3 passed;
  - focused electron/deduplication suite: 76 passed, 6 subtests passed;
  - complete reactor suite: 453 passed, 112 subtests passed;
  - adjacent IO/hydrogen/fusion suite: 69 passed;
  - first 100 rows of FLOWER full batch 01: 100/100 bidirectional passes;
  - scoped lint, Python compilation, and `git diff --check`: passed.
- The interrupted 425,517-row replay was not restarted. Its nine incomplete
  gzip files remain historical partial evidence and must not be appended to.

**State: Sprint F1 correctness gate passed; a fresh bounded-concurrency replay
is the next independent validation sprint.**

## 30 July 2026 — FLOWER failure-first Sprint F2 (active)

- Opened F2 independently from the closed stereo programme and from F1.
- Defined the historical chemical-failure set
  \(F=\{r:\exists d,\;status(r,d)=FAIL\}\), yielding 10,857 unique source rows.
  Timeout-only `ERROR` observations remain censored performance data and are
  not elements of \(F\).
- Added provenance-preserving sparse-row replay and a deterministic
  failure-corpus manifest.
- Derived the exact historical durable prefix from parsed contiguous case
  records:
  \(294263/425517=69.154229\%\), leaving 131,254 rows in nine suffixes.
- The first F2 pass exposed and repaired hydrogen-only spectator loss,
  broadening the F1 degree-zero invariant to any connected component with no
  heavy atom.
- The failure gate also isolated an open coupled-symmetry miss at batch 02
  row 1,156; it is retained as a true `FAIL`, not normalized away.
- Strengthened endpoint comparison to equality of unordered molecular
  multisets after map/stereo removal.
- Added gzip checkpoint flushing and verified it by forced termination:
  seven completed rows remained readable from the partial stream.
- The ten-worker pass durably completed 2,875 rows. Its remaining 7,982 rows
  were split into 20 disjoint shards after verifying
  `selection = durable prefix disjoint-union shards`.
- Definitive corpus replay now runs as 20 persistent one-CPU, 1 GiB-capped
  workers, with measured aggregate utilization near 19 logical cores.
  Incomplete suffixes remain paused until residual classification.
- Gates passed before launch:
  - focused FLOWER/Lewis tests: 16 passed;
  - complete Reactor/IO gate: 482 passed, 112 subtests passed;
  - scoped lint, compilation, and `git diff --check`: passed.

**State: F2 failure corpus running under bounded resources; suffix replay is
intentionally gated.**

## 30 July 2026 — FLOWER coupled-quotient debugging

- Confirmed all 20 F2 shard workers had finished and reproduced the first
  residual, batch 02 row 1,156 (`FLOWER-RPL-006`), in isolation.
- Proved mapping completeness: all eight forward embeddings existed, and raw
  application mode retained both chemically distinct endpoint assignments.
- Located the loss in exact ITS clustering after a five-iteration
  Weisfeiler--Lehman hash collision. The fallback called `GraphCluster`
  without its configured chemical node/edge matchers and consequently
  compared topology and stereo while ignoring charge, hydrogen-count, and
  bond-state correlations.
- Passed the complete ITS attribute matchers into exact clustering and added a
  synthetic long-range component-correlation regression.
- Batch 02 row 1,156 now passes in both directions; forward replay retains two
  unique endpoint reactions rather than incorrectly quotienting them to one.
- Validation:
  - focused invariant gate: 6 passed;
  - deduplication/bug/invariant gate: 35 passed and 4 subtests passed;
  - complete Reactor plus FLOWER benchmark gate: 465 passed and 112 subtests
    passed;
  - `git diff --check`: passed.

**State: FLOWER-RPL-006 resolved; the remaining F2 residual corpus requires
fresh post-fix replay/classification before opening the next defect family.**

## 30 July 2026 — FLOWER disconnected host-orbit debugging

- Replayed all 84 pre-fix F2 chemical residuals after `FLOWER-RPL-006`;
  64 passed, 16 remained chemical failures, and 4 became timeout-censored.
- Isolated a nine-row family where disconnected multi-change rules were
  pruned using individual host-node orbits. A representative had:
  - 720 exhaustive mappings and recovered the reference;
  - 180 pattern-pruned mappings and recovered the reference;
  - 36 host-orbit-pruned mappings and missed the reference.
- Restricted the host-node-orbit shortcut to connected patterns because
  individual node orbits do not certify one joint automorphism for a
  correlated disconnected assignment.
- Added a compact 306-embedding disconnected-pattern regression.
- Replayed all 84 residuals again. The new classification is 74 passes,
  6 timeout-censored rows, and 4 chemical failures.
- The four true residuals now form two explicit families:
  - `FLOWER-RPL-008`: three Cu-hydride/iminium zero-mapping cases caused by
    hidden explicit-H context in minimal changed-edge cores;
  - `FLOWER-RPL-009`: one organolithium ring-opening connectivity miss.
- Validation with both quotient fixes:
  - focused FLOWER invariant gate: 7 passed;
  - complete Reactor plus FLOWER benchmark gate: 466 passed and 112 subtests
    passed;
  - scoped test lint, Python compilation, and `git diff --check`: passed.

**State: FLOWER-RPL-006 and FLOWER-RPL-007 resolved; debugging has narrowed
the historical F2 residuals to two open root-cause families.**

## 30 July 2026 — FLOWER final residual closure

- Resolved `FLOWER-RPL-008`, the three-row Cu-hydride/iminium family.
  Minimal tuple cores had stripped unchanged explicit H neighbours from Cu,
  making the stored zero-radical query incomparable with the implicit
  `[CuH2]` host radical.
- Marked only non-main-group tuple positions whose explicit-H context was
  hidden by core extraction as electronically underdetermined radical
  queries. All other configured matching constraints remain exact.
- Proved `FLOWER-RPL-009` was a second joint-orbit issue rather than an
  incorrect ring-opening rewrite:
  - exhaustive forward search retained 608 mappings, produced 47 exact
    endpoints, and recovered the acyclic reference;
  - the old independent pattern-orbit quotient retained 38 mappings and
    missed it.
- Disabled independent orbit pruning only when product bonds correlate two
  heavy-atom source components. Hydrogen-only reagent permutations retain
  their established safe pruning.
- Final replay of the 84 historical chemical residuals under the ten-second
  diagnostic ceiling:
  - 79 pass;
  - 5 timeout-censored;
  - **0 chemical failures**.
- Validation:
  - focused matcher and FLOWER gate: 113 passed;
  - focused quotient/compatibility gate: 37 passed and 4 subtests passed;
  - complete Reactor, Graph/Matcher, and FLOWER benchmark gate:
    572 passed and 112 subtests passed;
  - scoped test lint, Python compilation, the 1,000-line changed-module
    ceiling, and `git diff --check`: passed.

**State: FLOWER-RPL-001--FLOWER-RPL-009 correctness defects resolved.
Timeout-only rows remain censored performance evidence, not chemical
failures.**

## 30 July 2026 — FLOWER timeout closure

- Profiled the five remaining timeout-only residuals. Their matching phases
  completed; the bottleneck was repeated exact whole-graph clustering of
  disconnected non-stereo ITS candidates during rewrite deduplication.
- Replaced that path with exact connected-component inventory clustering.
  Literal identities and Weisfeiler--Lehman signatures accelerate candidate
  lookup, while exact chemical isomorphism remains the final classifier.
- Added safe mapping reduction for correlated heavy-component rules using
  automorphisms of the complete transition graph. The optimization declines
  partial mappings and automorphism groups beyond its bounded enumeration.
- Exact replays of the five formerly censored rows pass in both directions
  under the unchanged ten-second ceiling. Previously timing-out directions
  now finish in 2.12--8.01 seconds.
- Replayed the complete 84-row historical residual set with ten workers:
  **84 pass, 0 timeout, 0 error, 0 chemical failure**.
- Validation:
  - focused regression and compatibility gate: 36 passed;
  - complete Reactor, Graph/Matcher, and FLOWER benchmark gate:
    573 passed and 112 subtests passed;
  - Python compilation, the 1,000-line changed-module ceiling, and
    `git diff --check`: passed.

**State: FLOWER-RPL-001--FLOWER-RPL-010 resolved; no failures or timeouts
remain in the 84-row historical residual set.**

## 30 July 2026 — SynReactor/Lewis soundness review

- Audited matching, automorphism quotienting, tuple rewrite semantics,
  hydrogen completion, product electron-state finalization, exact structural
  deduplication, and FLOWER endpoint validation.
- Removed joint host-mapping pruning by individual vertex orbits. Vertex
  orbits are now used only for one-node mappings; multi-node mappings require
  a certified joint group action. A vertex-transitive `C7 □ C11`
  counterexample protects distinct edge orbits.
- Strengthened tuple hydrogen-completion equivalence to compare the complete
  Lewis node and edge state rather than element, charge, and order alone.
- Replaced element-specific radical-query exceptions with typed query
  uncertainty derived from stripped local hydrogen context. Radical-changing
  rules remain exact.
- Made lower-bound radical rewrites resource-relative: the rule delta is
  applied to the matched host inventory rather than replacing it.
- Replaced the main-group/metal charge allowlist with a representation
  invariant. Parsed endpoints record whether they satisfy the local
  `VE - NBE - B` identity; recomputation is authoritative only when both rule
  endpoints lie inside that model.
- Dirty aromatic re-perception now fails closed. An unperceivable embedding is
  rejected individually, without silently accepting stale electron data or
  discarding other valid applications.
- FLOWER canonical endpoint comparison now disables invalid-fragment removal,
  so malformed inputs cannot compare equal after standardization.
- Validation:
  - focused invariant gate: 61 passed and 10 subtests passed;
  - comprehensive Reactor/Matcher/ITS/Mech/Hydrogen/Lewis gate:
    674 passed and 127 subtests passed;
  - five formerly timing-out rows: 5/5 pass in both directions under the
    unchanged ten-second ceiling;
  - complete historical residual corpus: 84/84 pass, with zero failures,
    errors, or timeouts;
  - Python compilation and `git diff --check`: passed.

**State: the reviewed quotient and Lewis-state boundaries are expressed as
general invariants; the historical correctness and timeout corpus remains
fully closed.**

## 30 July 2026 — SynReactor/Lewis cleanup and release gate

- Split hydrogen transport enumeration and Lewis-state comparison into
  `hcompletion_algorithms.py`. `HComplete` retains its public API and now
  composes those internal algorithms through a focused mixin.
- Removed dead commented arguments and historical implementation commentary
  from the reviewed source. Charge documentation is now element-agnostic and
  states the local Lewis-model authority condition directly.
- Reduced the three complexity findings exposed by the repository lint gate
  through cohesive helper extraction. No complexity or file-size suppression
  was added.
- Validation:
  - focused hydrogen/stereo/interchange/deduplication gate:
    148 passed and 8 subtests passed;
  - comprehensive Hydrogen/ITS/Mech/Matcher/Stereo/Mechanism/Reactor/Lewis
    gate: 2,458 passed, 1 skipped, and 127 subtests passed;
  - full repository lint gate: Python file-size check passed and flake8
    reported 0 violations;
  - changed-source Python compilation, AI-attribution scan, Black formatting,
    and `git diff --check`: passed.

**State: reviewed source is structurally cleaned, lint-clean, and regression
clean without case-specific suppressions.**

## 30 July 2026 — Post-cleanup full FLOWER replay

- Replayed the 84 historical residual rows first. One forward direction
  reached the ten-second ceiling under ten-worker load, then passed serially
  in 7.9 seconds; no chemical failure was present.
- The first full-corpus launch exposed `FLOWER-RPL-011`: dirty aromatic
  product re-perception still preferred the retained Kekule phase. That
  contradicted the dirty-phase invariant and rejected valid charged-azole
  products after RDKit valence validation.
- Disabled retained Kekule preference only at the dirty re-perception
  boundary. This is a phase-consistency correction, not an element or
  reaction-family exception.
- Validation after the correction:
  - focused product-state/Reactor gate: 54 passed and 2 subtests passed;
  - seven newly exposed corpus witnesses: 7/7 pass bidirectionally under ten
    seconds;
  - historical residual canary: 84/84 pass concurrently under 30 seconds;
  - scoped lint, file-size gate, formatting, and `git diff --check`: passed.
- Restarted the complete 425,517-row, 851,034-direction replay from fresh
  outputs as 20 disjoint persistent shards. Each worker is capped at one CPU
  and 1 GiB RAM, flushes every 250 rows, and uses a 30-second diagnostic
  ceiling. Timeout rows will be retried serially before classification.

**State: corrected full replay active under
`Experiment/FLOWER/post-cleanup-full-replay-20260730-v2`; early records show
timeout-only diagnostics and no chemical failures.**

## 31 July 2026 — portable LWG experiments and hydrogen-extension audit

- Consolidated the portable Lewis-graph experiment tree on branch `lwg`.
  - `main` remains at `d8820c9` (`Prepare 1.6.0 LWG release`).
  - The independent stereo work is retained as commit `ac89c25` on branch
    `stereo`.
  - `origin/lwg` currently ends at `fc54984` (`Formalize HExtend invariant
    partitioning`).
- Added the portable FLOWER replay workflow in `8000679`:
  - ten gzip source batches and their manifest are tracked in the commit tree;
  - one launcher, `Experiment/Lewis/FLOWER/run_bidirectional_replay.sh`, is the
    supported replay entry point;
  - reusable developer commands were moved from `tools/` and repository-root
    wrappers into `scripts/`;
  - the missing MechanismBench CI fixtures were subsequently tracked in
    `330baa8`.
- Large laptop replay was intentionally stopped. At this handoff there are no
  active FLOWER, partial-expansion, or hydrogen-comparison processes.

### Partial atom-map expansion

- Added the five-repeat metadata-only runner in `2a17d28`; current SynKit and
  historical GM/RB1/RB2 execute in their required environments without
  producing publication figures.
- The completed report is under
  `Experiment/Lewis/Runs/20260731T120659Z-partial-expand-runtime`.
- All four methods generated and validated all 39,732 reactions in every
  repetition: accepted coverage, generation success, ITS accuracy, and RC
  accuracy are each 100%.
- Mean generation time per attempted reaction:
  - SynKit: 2.145 ms;
  - GM: 2.860 ms;
  - RB1: 2.370 ms;
  - RB2: 2.309 ms.
- The external historical implementations are not aliases and must remain
  reported separately.

### Hydrogen expansion

- Added the official 109-reaction payload and a single-process comparison over
  the 104 reference-eligible reactions. Method A and Method B are run
  separately with AN-gm, RB-gm, and RB-nx backends.
- Proved the historical `LegacyHExtend` implementation is not exhaustive over
  chemically distinct hydrogen transports. It applies one shared H-ID
  permutation to reactant-loss and product-gain slots; distinct list entries
  can therefore be the same exact class. R-50548 is the permanent regression:
  legacy returns two entries but one class, whereas the reference and new
  HExtend return two classes. Legacy achieved 0/520 reference class-count
  matches and is retained for reproducibility only.
- The new HExtend uses provenance-aware source/target transport plans and an
  exact quotient pipeline:
  1. unequal RC invariants rule out equivalence;
  2. RC collisions are refined by the exact hydrogen-rooted distance multiset
     \(I_H(G)=\multiset_{h\in H(G)}\multiset_{v\in C_G(h)}
     (c(v),d_G(h,v))\);
  3. remaining blocks enumerate every isomorphism of the changed-bond core and
     test exact stereo-aware extension to the complete ITS.
- This is cache-free and contains no dataset/record shortcut. Any full ITS
  isomorphism preserves paired bond order and therefore restricts to one of
  the enumerated changed-core mappings; unequal necessary invariants only
  reject impossible pairs, while all unresolved pairs receive the exact
  fallback.
- Validation of the current local algorithm:
  - targeted hydrogen/benchmark gate: 29 passed and 8 subtests passed;
  - lint, Python file-size gate, shell syntax, and `git diff --check`: passed;
  - complete cluster partitions, not merely counts, equal unconstrained exact
    clustering for all 104 reactions;
  - class counts match the reference in 520/520 comparisons with zero errors;
  - a deliberate invariant-collision regression proves the exact fallback;
  - node relabeling preserves the rooted-distance invariant.
- Latest five-repeat schema-6 report:
  `Experiment/Lewis/Runs/20260731T171906Z-hydrogen-expand/aggregate.json`.
  New HExtend mean ± population standard deviation [ms]:
  - `N_h=2`: 2.06 ± 0.77;
  - `N_h=3`: 2.46 ± 0.74;
  - `N_h=4`: 5.91 ± 4.24;
  - `N_h=5`: 21.96 ± 20.22.
  The `N_h=5` spread includes R-37905 at approximately 79 ms throughout that
  loaded run; isolated executions are approximately 19--20 ms. Preserve this
  as timing noise evidence rather than silently replacing the observation.
- `--reuse-reference-dir` reruns only the two SynKit implementations while
  validating and copying a completed reference set into a coherent aggregate.
  It does not recompute or cache HExtend outputs.

### Exact handoff state

- The last pushed commit is `fc54984`. The user subsequently requested no
  further pushes.
- The mathematically strengthened changed-core anchor implementation is local
  and uncommitted in exactly four source/test files:
  - `synkit/Graph/Hyrogen/hextend.py`;
  - `Experiment/Lewis/hydrogen_expand/benchmark.py`;
  - `Experiment/Lewis/hydrogen_expand/README.md`;
  - `Test/Benchmark/Lewis/test_hydrogen_expand.py`.
- This `SS_LOG.md` handoff entry is the only additional modified file.
- Do not push these changes unless the user explicitly authorizes it. A clean
  continuation should first review the four-file diff and the schema-6 report,
  then decide whether to create a local commit.

**State: portable LWG benchmark work recorded; no benchmark is active; ready
to clear.**

## 31 July 2026 — HExtend exact-path continuation

- Reviewed the four-file uncommitted changed-core anchor handoff and the
  schema-6 five-repeat report without pushing or committing.
- Profiled the 104 reference-eligible reactions by extension and clustering
  phase. Candidate materialization is the remaining dominant cost on the
  largest cases: R-58132 constructs 33 complete ITS candidates and R-37905
  constructs 18, while their exact clustering is negligible because the RC
  invariants already separate every candidate.
- Kept `extend_its` exhaustive and cache-free. Avoided plan-level pruning or
  cached output because either would change the public enumeration contract or
  require new proof beyond the current evidence.
- Tightened the exact fallback without changing its equivalence relation:
  - changed-core node/edge-count mismatches now reject before VF2;
  - an empty changed core goes directly to unconstrained exact stereo-aware
    full-ITS matching;
  - nonempty-core candidates allocate their two anchored working copies once
    per pair and reuse them across the exhaustive core-mapping search;
  - the caller-owned candidate graphs remain unmodified.
- Promoted the previous one-off 104-reaction partition audit into a permanent
  corpus regression against unconstrained exact clustering.
- Validation:
  - targeted hydrogen/benchmark gate: 33 passed and 8 subtests passed;
  - all 104 eligible complete cluster partitions equal the unconstrained exact
    baseline;
  - full lint and 1,000-line Python file-size gate: passed;
  - `git diff --check`: passed.
- The four tracked handoff files remain locally modified. `SS_LOG.md` is an
  ignored local session artifact. No commit or push was performed.

**State: HExtend exact clustering is strengthened; further material speedups
require optimizing candidate construction while preserving exhaustive
`extend_its` outputs.**

## 31 July 2026 — post-enhancement hydrogen benchmark rerun

- Reran both SynKit HExtend implementations for five repetitions over all 104
  eligible reactions and reused the validated schema-6 GM/RB reference
  artifacts from `20260731T171906Z-hydrogen-expand`.
- Wrote the coherent new report to
  `Experiment/Lewis/Runs/20260731T202002Z-hydrogen-expand`.
- Correctness remained exact:
  - new HExtend versus Method A: 520/520 class-count matches;
  - the reused reference methods agree in 520/520 comparisons;
  - all 4,160 serialized attempts are `OUTPUT`, with zero errors.
- Current HExtend mean time is 8.981 ms per reaction and median time is
  4.143 ms. Against Method A:
  - AN-gm: 115.124 ms mean and 8.376 ms median, so HExtend is 12.82x faster
    by mean and 2.02x faster by median;
  - RB-gm: 127.206 ms mean and 9.398 ms median, so HExtend is 14.16x faster
    by mean and 2.27x faster by median.
- The hydrogen-count boundary is explicit. Against AN-gm, HExtend is 2.32x
  slower at `N_h=2`, then 2.37x, 5.71x, and 27.31x faster at `N_h=3`, 4,
  and 5. Against RB-gm the corresponding speedups are 0.49x, 2.58x, 6.30x,
  and 30.19x.
- Method B remains substantially slower: current HExtend is 96.64x faster
  than AN-gm and 111.47x faster than RB-gm by overall mean.
- This HExtend rerun is 1.83x slower overall than the earlier 4.917 ms mean,
  with every hydrogen-count group moving in the same direction. Because the
  clustering edit affects only the small invariant-collision subset, preserve
  this as run-level machine/load variation rather than attributing it to the
  algorithm without controlled paired evidence.
- Artifact checks:
  - aggregate SHA-256:
    `8fb6f1c7c758961fe8183e23dfd4348c32a384cc15e14df2f1c941e6a52768b7`;
  - HExtend rows SHA-256:
    `066039a75423924e2f0db7f099d40cf878163669a71eec004248c664582f8f1e`.

**State: HExtend outperforms GM overall and from three unmatched hydrogens
upward; GM retains the two-hydrogen small-case lead.**

## 31 July 2026 — hydrogen timing environment correction

- Audited the apparent HExtend H2 increase from 2.06 ms to 3.56 ms.
- The `20260731T202002Z` rerun inherited the active base environment and is not
  comparable to the frozen reference timing:
  - old/reference lane: Python 3.11.0, NetworkX 3.5, RDKit 2025.9.3;
  - accidental lane: Python 3.12.12, NetworkX 3.6.1, RDKit 2026.3.1.
- Reran in the original `synkit` environment and wrote the corrected report to
  `Experiment/Lewis/Runs/20260731T202305Z-hydrogen-expand`.
- Corrected new-HExtend means [ms] are 2.82, 4.08, 9.02, and 25.73 for
  `N_h=2`, 3, 4, and 5. Overall mean is 6.75 ms and median is 3.40 ms.
- A residual broad slowdown remains relative to the older run, but it is not
  caused by the changed-core edit:
  - across the 190 H2 attempts, the mean old-to-new timing ratio is 1.459 for
    new HExtend and 1.459 for untouched LegacyHExtend;
  - median ratios are 1.464 and 1.426 respectively;
  - none of the 38 H2 reactions reaches the modified exact anchored fallback.
    R-16362 and R-30693 collide on the RC invariant but are separated by the
    unchanged hydrogen-distance invariant.
- The remaining shift is therefore run-level host frequency/load variation.
  It must not be reported as an HExtend regression.
- Under the corrected environment, HExtend remains 17.06x faster than Method
  A AN-gm overall by mean. AN-gm is 1.84x faster at `N_h=2`; HExtend is 2.53x,
  8.25x, and 38.58x faster at `N_h=3`, 4, and 5.
- Corrected aggregate SHA-256:
  `ce9e433ec444bfd6970a3d08bdb822698a5114b4953bce464a90da85fed36b77`.

**State: `20260731T202002Z` is retained as environment-mismatch evidence;
`20260731T202305Z` is the corrected post-enhancement comparison.**

## 31 July 2026 — stereo benchmark metadata fast-forward

- Fetched `origin` and fast-forwarded `lwg` from `fc54984` to `8a004bf`
  (`Add complete stereo benchmark metadata`).
- The incoming commit adds or updates 34 stereo benchmark artifact files and
  does not overlap the local four-file HExtend work.
- All incoming JSON artifacts parse successfully.
- `HEAD`, local `lwg`, and `origin/lwg` now agree at `8a004bf`.
- The local HExtend README, benchmark, test, and implementation edits remain
  modified and unstaged. No push was performed.

**State: remote stereo benchmark results merged by clean fast-forward; local
HExtend continuation preserved.**

## 31 July 2026 — merged stereo benchmark verification

- Reviewed the merged task-aware registry and retained reports without pooling
  incompatible ACS chirality, RotA locus, and CIP assignment tasks.
- Focused `Test/Benchmark/Stereo` validation passed: 67 passed, 23 skipped.
- Headline retained results:
  - ACS supplied-stereo binary: SynKit 258/258;
  - exact configured chemical mirror audit: 256/258, with VS170 and VS300 as
    the two declared protocol-boundary disagreements;
  - full local carrier detection with oriented frames: ACS 1,007/1,007, RotA
    698/698, and CIP 1,252/1,252 reference loci;
  - RotA typed locus detection: 698/698 annotations and 15/15 expanded paths,
    with all 650 records reverse-renumbering invariant;
  - pinned-coordinate native CIP: 187/300 exact records, 926/1,252 recovered
    labels, 98.83% precision, and 73.96% recall;
  - configuration-free local canonicalization: 66,468 representations of
    3,476 carriers over 1,218 rows, zero failures;
  - formal global A/B/C canonicalization: 2,160 assignments over 30 cases,
    zero timeout or failure;
  - supplemental raw A: 2,048/2,048 assignments over 10 cases;
  - supplemental raw B: 992,256/992,256 assignments over 11 cases;
  - supplemental raw C/VS146: 2,359,296/2,359,296 assignments;
  - all retained raw A/B/C stress assignments preserve their formal tuples
    and global classes with zero timeout or failure;
  - designed perception conformance: 40/40.
- Updated the manifest, benchmark documentation, and permanent raw-global
  regression so the newly tracked raw B and raw C/VS146 artifacts are no
  longer described or tested as absent. The remaining eight raw-C cases stay
  explicitly excluded because their products reach 782,757,789,696
  representations.

**State: merged stereo benchmark metadata is locally validated and ready for
task-separated reporting.**
