# Stereo-graph roadmap

This cycle starts again at Sprint 1, covers molecular stereo graph only, and
uses ten sequential gates for global stereograph closure. The detailed
requirement matrix is in `sprint_plan.html`.

| Sprint | Scope | Exit gate |
|---:|---|---|
| 1 | Baseline, diagnosis, fixtures, architecture | Checksummed 256/258 baseline, executable VS300 witness audit, minimal fixtures, and coupled-frame decision. **Complete.** |
| 2 | Information states and molecular outcomes | Potential, necessarily chiral/orientation-unspecified, configured ±, incomplete, and unsupported are unambiguous. **Complete.** |
| 3 | Formal global support/frame model | RDKit-independent immutable value passes validation, inversion, relabeling, equality, and hashing proof tests. **Complete.** |
| 4 | Registry and interchange | Stable wire identity, collision-free global keys, compatibility decision, exact round trips, and typed rejection. **Complete.** |
| 5 | Exact canonical stereograph integration | Global certificates are atom/support/frame/order invariant and distinguish configured opposites. **Complete.** |
| 6 | Mirror, relations, and composition | Double mirror, enantiomer/diastereomer, near-miss, and mixed local/global gates pass without CIP. **Complete.** |
| 7 | Molecular evidence boundary | VS300 obstruction is represented by a general map-independent certificate without fabricated orientation. **Complete.** |
| 8 | Identity profiles and resonance | Chemical, Lewis-state, and ACS-topology meanings and VS170/215/216 behavior are preserved. **Complete.** |
| 9 | Corpus, metamorphic, negative, performance | Frozen and new protocols coexist; full invariance, safety, and cost evidence is recorded. **Complete.** |
| 10 | Paper, documentation, quality closeout | Every claim links to evidence; complete tests/lint/docs pass; R1--R10 are closed. **Complete.** |

## Closed sequence

All ten sequential exit gates are recorded in `SS_LOG.md`. The completion
manifest preserves the requirement-to-evidence mapping.

## Later stereo-graph programme

After Sprint 10 closes global stereograph support, later cycles may own:

1. general helicene, planar, atrop/cyclophane, and coordinate/sidecar
   perception;
2. complete configuration populations across axial, path, plane,
   coordination, and coupled/global families;
3. complete hierarchical CIP digraph ranking, multi-unit Rule 4b,
   coordinate-based helical/axial orientation, pseudoasymmetry, and
   coordination indices;
4. enhanced ABS/AND/OR population semantics;
5. experimental negative/stability datasets and release audit. The maintained
   synthetic constitutional-negative gate is complete but is not kinetic
   stability truth.

## Programme definition of done

- Configured identity is exact and atom-map/atom-order invariant.
- Every supported descriptor has mirror, canonicalization, enumeration,
  serialization, and information-state semantics.
- Perception never promotes topology to orientation without evidence.
- Whole-molecule chirality handles local and genuinely global stereo.
- CIP remains a derived, independently tested output.
- Unsupported chemistry returns typed evidence rather than a plausible guess.
- Benchmark claims are scoped to their actual scientific task.

## Explicit exclusions

- reaction-rule matching and application;
- retention/inversion/formation/breaking effects;
- ITS and fusion stereo transport;
- electrocyclic conrotatory/disrotatory selection;
- mechanism, kinetics, stability, yield, or selectivity prediction.
