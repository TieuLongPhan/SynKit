# Global stereo information model

**Status:** Accepted  
**Date:** 28 July 2026  
**Owner:** Sprint 2  
**Compatibility:** Additive; existing source-declared and ACS-specialized
protocols retain their names and behavior

## Decision

Molecular chirality and configured stereograph identity answer different
questions. A topology may prove that every admissible member is chiral without
identifying which enantiomer was supplied. SynKit therefore keeps the
following states distinct:

| State | What is known | Molecular outcome | Configured stereograph |
|---|---|---|---|
| `potential` | Topology contains candidate frames but no global mirror obstruction is proven. | No global claim. | No configured value. |
| `necessarily_chiral_orientation_unspecified` | An authorized coupled-frame certificate proves no mirror isomorphism. | `necessarily_chiral` | Present but `UNSPECIFIED`; exact configured comparison returns incomplete. |
| `configured_positive` | Authorized evidence selects one member of the certified mirror pair. | Chiral | Fixed `FrameworkStereo(+1)`. |
| `configured_negative` | Authorized evidence selects the opposite member. | Chiral | Fixed `FrameworkStereo(-1)`. |
| `unsupported` | Evidence is malformed, spans unsupported components, or cannot be retained faithfully. | Unsupported/incomplete | No value; typed reason required. |

## Evidence authority

Two-dimensional topology and the ACS topology-completion construction may
authorize a **necessary-chirality certificate**. They may not select positive
or negative configured orientation.

A configured orientation requires explicit non-empty provenance and an
already validated necessarily-chiral certificate. Accepted sources are an
exact graph/sidecar declaration or a future coordinate/experimental adapter
that independently proves its orientation mapping. Coordinate perception
itself remains outside this cycle.

Source `@`/`@@` tags remain independent local configurations in the existing
exact source-declared protocol. They are not silently reinterpreted as a
global orientation.

## Allowed transitions

```text
topology
  → potential
  → necessarily_chiral_orientation_unspecified

necessarily_chiral_orientation_unspecified
  + authorized positive orientation → configured_positive
  + authorized negative orientation → configured_negative

any state + malformed/contradictory evidence → unsupported
```

There is no transition from topology, a common arbitrary probe parity, an ACS
expected label, CIP text, atom maps, or record identity directly to a
configured orientation.

## Public behavior

- `analyze_global_stereo_support(molecule)` returns a
  `GlobalStereoCertificate`.
- `configured_framework_from_certificate(...)` is the only molecular helper
  that selects a configured orientation; it requires `orientation` ±1,
  non-empty provenance, and a necessarily-chiral certificate.
- `FrameworkStereo(..., orientation=None)` records coupled support but does
  not itself claim necessary chirality. A validated certificate owns that
  promotion. Passing the unspecified value to configured mirror comparison
  returns `incomplete`, not achiral or an arbitrary enantiomer.
- The existing `MolecularChiralityOutcome.NECESSARILY_CHIRAL` is the molecular
  outcome for an orientation-unspecified certificate.

## Protocol names

1. **Exact source-declared chemical stereograph** — frozen 256/258 baseline.
2. **ACS-specialized topology-completion classifier** — frozen 258/258
   task-specific result.
3. **Exact-plus-global-certificate ACS protocol** — separately versioned
   protocol that combines source-declared exact chirality with a necessary
   global topology certificate; it never selects a global enantiomer.

No result from protocol 3 may overwrite the frozen artifact from protocol 1.
