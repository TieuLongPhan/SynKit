# Stereo reaction validation contract

RX13 closes metamorphic, adversarial, performance, and repository validation.

## Dedicated validation

The RX13 matrix verifies:

- relabeling, normalized ordering, serialization round trip, and double
  reversal invariance;
- unsupported schema, duplicate targets, wrong ownership, invalid weights,
  malformed coupling, sidecar tamper, and lossy-carrier refusal;
- typed branch-limit failure without a partial result;
- absence of frozen ST/SC/EC case-ID shortcuts in production code;
- deterministic normalized digest over 2,500 wire and 250 authenticated graph
  round trips;
- the 1,000-line ceiling for every changed reaction-stereo production module.

`evidence/stereo_rxn_validation.json` records Python/RDKit/platform/CPU
environment, wall and CPU time, peak RSS, proof bytes, branch count,
assignment count, budgets, and stable pass/fail checks. The measured workload
used 0.425024 wall seconds, 0.421893 CPU seconds, 105.961 MiB peak RSS, and a
784-byte normalized proof value.

## Repository gate

- Dedicated RX13 validation: 13 passed.
- Complete maintained suite: 4,055 passed, 31 skipped, and 179 subtests
  passed.
- Strict new-file and compatibility lint: passed.
- Python compilation and JSON parsing: passed.
- Changed reaction modules below 1,000 lines: passed.
- Offline strict Sphinx HTML (`-E -W`): passed.
- Fifteen stereo-reaction HTML files and 108 local links: passed.
- `git diff --check`: passed.

The online intersphinx attempt could not resolve external inventories in the
restricted environment. This is not the documentation gate; the documented
offline strict build completed without warnings.
