# Reaction-stereo follow-up fixtures

Store reduced, reviewed SF1--SF4 reproductions here. Keep positive, negative,
timeout, unsupported-capability, and malformed-input cases distinguishable.
