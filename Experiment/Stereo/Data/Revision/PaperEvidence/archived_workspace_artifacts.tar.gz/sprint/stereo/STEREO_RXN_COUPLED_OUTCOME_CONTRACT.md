# Correlated local outcome contract

RX8 closes the executable vicinal coupling modes without extending their
claims to ring or pericyclic selectivity.

## Supported modes

The closed execution set is:

- `VICINAL_ADDITION` with `SYN` or `ANTI`;
- `VICINAL_ELIMINATION` with `SYN` or `ANTI`.

Center order is normalized while preserving center/ligand pairing. Centers
and transferred ligands are disjoint positive atom-map references. New
coupling kinds must add an explicit executor, validation contract, forward
and reverse corpus evidence, and negative context cases before entering
`supported_kinds()`.

## Execution

- Addition consumes a specified planar input when an alkene geometry matters,
  or a constitutionally sufficient higher-pi input.
- Its two face alternatives are paired tetrahedral outcomes. Each branch
  records both `joint_targets`; independent local Cartesian expansion is not
  permitted.
- Elimination consumes two specified tetrahedral descriptors as one paired
  input and reconstructs the unique compatible planar product.
- Reversal preserves the SYN/ANTI relation and swaps addition/elimination.
- Missing alkene geometry or missing paired tetrahedral configuration refuses
  application.

## Reviewed evidence

`MechanismBench/stereo_couplings.json` contains four reviewed E/Z × SYN/ANTI
forward/reverse cases and four malformed/context-insufficient negatives. Its
claim boundary is software-semantic correlation only; it makes no selectivity,
rate, yield, reagent, or experimental-population claim.

## Gate evidence

- New reviewed corpus suite: 10 passed.
- Adjacent Graph/Stereo, Rule, and Reactor gate: 2,134 passed, 1 skipped, and
  112 subtests passed.
- JSON validation, lint, Python compilation, and `git diff --check`: passed.
