# Stereo-bearing ITS and DPO contract

**Sprint:** RX5  
**Status:** implemented

## Layers

An ITS may carry:

- `stereo_descriptors.reactant`;
- `stereo_descriptors.product`;
- optional `stereo_descriptors.transition`;
- derived `stereo_changes`;
- later rule-level `stereo_outcomes` and `stereo_couplings`.

`ITSConstruction.construct(..., transition_graph=...)` makes fleeting
transition descriptors first-class. `ITSReverter` can project reactant,
product, or transition layers. `ITSDestruction` now preserves the endpoint
registries as well as electronic node/edge fields.

## Validation modes

`stereo_validation="preserve"` is the backward-compatible default. It carries
graph-only declarations without claiming their structural executability.

`stereo_validation="strict"` validates before ITS construction:

- registry key ownership;
- every material support atom;
- atom/bond/path adjacency required by the descriptor;
- path continuity for cumulene, extended cis/trans, and helical values;
- framework frame references;
- owner-qualified virtual H/LP resource availability;
- reactant, product, and transition layers independently.

Strict failures raise `StereoITSValidationError` containing stable
`INVALID_REFERENCE` refusals. A product descriptor referencing a removed
ligand is rejected before rule extraction.

## Stereo-only reaction centres

A reaction centre need not contain a changed bond or node attribute.
`RCExtractor` includes every dependency of a non-retained stereo change. In
minimal-RC mode this may produce a node-only reaction centre with zero edges;
the complete stereo layers and changes remain graph metadata.

This behavior coexists with the earlier `include_context_edges` LWG work:
stereo dependencies add nodes, while that independent option controls whether
unchanged context edges between reaction-centre nodes are retained.

## Gate evidence

- Topology-preserving epimerization round-trips through strict ITS,
  minimal-RC extraction, `ITSReverter`, and `ITSDestruction`.
- Transition-only stereo round-trips and is classified `FLEETING`.
- Dangling product references and stale virtual H resources fail before ITS
  construction.
- Helical path breaks fail explicitly.
- Cumulene-axis, extended cis/trans, planar chirality, and framework supports
  pass strict validation.
- Focused RX5/electron-aware tests: 19 passed.
- Adjacent ITS, transport, generic-rule, promoted-rewrite, and fusion tests:
  170 passed.
- Strict new-file lint, compatibility-file lint with existing exclusions,
  Python compilation, and `git diff --check`: passed.

