# Stereo mechanism and electrocyclic machinery contract

RX10 closes the distinction between net endpoint agreement and a valid
stereochemical trajectory.

## Verification modes

- `off` performs no stereo verification and reports that fact.
- `endpoint` compares the initial/final stereo state but does not validate
  supplied intermediate effects or correlated orbital motion.
- `stepwise` validates every supplied stereo effect and machinery annotation,
  rolls back a failed strict step, and then checks the endpoint.

Each replay carries a checksum-bound
`synkit.mechanism-stereo-timeline/1` value with its verification mode and the
complete rectangular descriptor history.

## Figure 11 machinery rule

`ElectrocyclicStereoMotion` is one correlated terminal-orbital assertion with:

- conrotatory or disrotatory mode;
- ring closure or ring opening direction;
- two mapped termini and one tracked substituent at each terminus;
- a paired +1/-1 terminal-motion witness;
- 4π/6π electron count and thermal/photochemical activation context;
- provenance.

The verifier applies the supplied Woodward-Hoffmann context:

| Electron system | Thermal | Photochemical |
|---|---|---|
| 4π | conrotatory | disrotatory |
| 6π | disrotatory | conrotatory |

Same-sense terminal motion realizes conrotation; opposite-sense motion
realizes disrotation. The two termini never become independent local
branches. Reversal swaps closure/opening and reverses both physical motions
while preserving the correlated mode.

`MechanismBench-electrocyclic-machinery-v1` contains four reviewed positives,
including a substituted Figure 11-shaped case, and wrong-mode,
missing-context, and motion-tamper negatives.

## Gate evidence

- Focused machinery plus existing model/replay workflows: 93 passed.
- Complete Mechanism plus adjacent composition, MTG, and coupling suites:
  147 passed and 3 subtests passed.
- JSON/schema validation, strict new-test lint, compatibility lint, Python
  compilation, and `git diff --check`: passed.
