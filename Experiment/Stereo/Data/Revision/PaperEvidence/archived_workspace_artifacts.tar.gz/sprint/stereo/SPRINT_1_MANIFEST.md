# Sprint 1 evidence manifest

**Frozen:** 28 July 2026  
**Scope:** evidence and architecture only; no production behavior change

## Artifacts

| Artifact | SHA-256 | Purpose |
|---|---|---|
| `evidence/sprint_1_exact_acs_256_baseline.json` | `1ec6ce18ce54c4ab2ce2c01c65dff3da6746c40f98d400af23974773ff939ebf` | Complete 258-record exact chemical-identity baseline |
| `evidence/vs300_global_stereo_diagnostic.json` | `8aed2b5f054218f5ae369629cee78eb05dde5ec0b03af8fd9b52736ac83ac9b6` | Two-contract and mirror-witness audit |
| `fixtures/vs300_minimal_fixtures.json` | `430567b06ddb9972051ee2282b4cc0fec771ba5c125753f3293cf75a07c21216` | Nine-atom positive, enantiomer pair, and achiral near-miss |
| `GLOBAL_STEREO_ARCHITECTURE.md` | `edf0311d84218303fe5468612dc1011ffe241bf4d0bb8b81fee3c6f1d5fb6237` | Accepted coupled-frame architecture decision; deferred questions later resolved additively |

## Frozen result

- Dataset SHA-256:
  `b90d64bba99d36f0be2429cad255e7836b244dfc26e7c9b4281b36d9ed51fff0`
- Definitive coverage: 258/258.
- Exact chemical-identity agreement: 256/258.
- Disagreement IDs: `VS170`, `VS300`.
- The 256 result is the paper baseline. A future protocol may be reported
  separately; it must not overwrite this artifact or erase either mismatch
  explanation.

## Reproduction

```bash
PYTHONPATH=. conda run -n synkit python \
  Experiment/Stereo/Chirality/run.py acs \
  --case-timeout 5 \
  --identity-profile chemical \
  --output sprint/stereo/evidence/sprint_1_exact_acs_256_baseline.json

PYTHONPATH=. conda run -n synkit python \
  Experiment/Stereo/Chirality/vs300_diagnostic.py \
  --output sprint/stereo/evidence/vs300_global_stereo_diagnostic.json \
  --fixtures sprint/stereo/fixtures/vs300_minimal_fixtures.json
```

The benchmark report contains environment and timing metadata, so reproducing
it may change its file checksum even when all scientific outcomes and
canonical certificates are identical. Validate the frozen scientific fields,
not only byte identity.
