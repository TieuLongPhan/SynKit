# SynKit stereo and reaction-stereo sprint workspace

**Updated:** 1 August 2026  
**Status:** molecular Sprints 1--10 and reaction RX1--RX14 complete; reaction
follow-up remains active  
**Scope:** closed molecular programme, reaction programme, and bounded
reaction-stereo follow-up

[Back to the sprint workspace index](../README.md)

The molecular cycle is closed. It delivered exact coupled-framework stereo.
Stereo reaction transport is now a separate, implementation-ready programme;
its original RX1--RX14 sequence is complete. Further reaction-stereo work must
be added as a named follow-up with its own evidence gate. MTG rule composition
is tracked separately in [`../mtg/`](../mtg/).

## Active follow-up boundary

The reaction-stereo track remains open for cross-platform validation,
benchmark/evidence refreshes, and reconciliation of formal claims with the
implementation and paper. These tasks must not be folded into the MTG plan or
used as evidence for graph-rule composition.

## Stereo reaction programme

- `FOLLOW_UP_PLAN.md` — active SF1--SF4 follow-up sequence.
- `stereo_rxn_plan.html` — navigable RX1--RX14 master plan.
- `stereo_rxn_roadmap.md` — complete scientific, architectural, evidence, and
  delivery contract.
- `stereo_rxn_sprint_01.html` ... `stereo_rxn_sprint_14.html` — individual
  sprint contracts, dependencies, evidence, and hard gates.
- `CURRENT_PROGRESS.md` — current boundary and programme status.
- `SS_LOG.md` — planning and execution record.

The reaction sequence starts with a no-production-change baseline freeze.
Release, push, and manuscript submission are not authorized by the plan.

## Closed molecular programme

- `sprint_plan.html` — completed R1--R10 master plan.
- `sprint_1.html` ... `sprint_10.html` — completed sprint contracts.
- `COMPLETION_MANIFEST.md` — claim-to-evidence matrix, checksums, and gates.
- `GLOBAL_STEREO_INFORMATION_MODEL.md` — accepted information semantics.
- `GLOBAL_STEREO_ARCHITECTURE.md` — accepted coupled-frame architecture.
- `SPRINT_1_MANIFEST.md` — immutable 256/258 baseline evidence.
- `evidence/` and `fixtures/` — machine-readable reports.
- `older/` and `ARCHIVE_MANIFEST.md` — compressed Sprint 0--44 history.

## Invariants

1. The frozen exact source-declared result remains 256/258.
2. The 257/258 exact-plus-global result is a separate protocol.
3. The ACS-specialized classifier remains a separate 258/258 task.
4. Topology may prove necessary chirality but never invent configured
   orientation.
5. CIP, atom maps, expected labels, record IDs, and arbitrary parity are not
   configured identity.
6. Unsupported chemistry fails closed.

These invariants remain closed inputs to the reaction programme. They must not
be weakened to improve a reaction benchmark.
