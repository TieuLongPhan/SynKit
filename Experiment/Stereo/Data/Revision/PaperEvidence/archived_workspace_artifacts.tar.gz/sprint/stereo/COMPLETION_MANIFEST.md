# Stereo-graph Sprints 1--10 completion manifest

**Closed:** 28 July 2026  
**Branch:** `stereo`  
**Base commit:** `17f4f471c5b8b0510aa91c2b4e30a37a05aebfd1`  
**Package version:** `1.6.0`  
**Worktree state:** implementation and paper closeout changes are present but
not committed; no release or submission was performed

## Protocol results

| Protocol | Schema/task boundary | Coverage | Agreement | Disagreements |
|---|---|---:|---:|---|
| Exact source-declared chemical stereograph | frozen Sprint 1 artifact | 258/258 definitive | **256/258** | VS170, VS300 |
| Exact plus necessary-global-certificate ACS | `synkit.exact-plus-global-certificate-acs/1` | 258/258 definitive | **257/258** | VS170 |
| ACS-specialized topology completion | existing task-specific classifier | 258/258 definitive | **258/258** | none |

The 256 result remains the paper's immutable exact source-declared baseline.
The 257 result is a separate protocol: it adds a map-independent proof that
VS300 is necessarily chiral, but leaves global orientation unspecified. VS170
remains different because chemical identity retains `S-I` versus `S#I`; the
ACS connectivity profile does not.

## Artifact checksums

| Artifact | SHA-256 |
|---|---|
| `evidence/sprint_1_exact_acs_256_baseline.json` | `1ec6ce18ce54c4ab2ce2c01c65dff3da6746c40f98d400af23974773ff939ebf` |
| `evidence/sprint_9_exact_plus_global_certificate_acs.json` | `cab08f0670ab399e327cdf9be878a96d54b5a3b3cdb53f9cafa9ce694917d92f` |
| `evidence/sprint_9_global_stereo_performance.json` | `0b1b53b4b63f120faae341c4fd1c9c9ec96e3eb91691221c0c18288b0721c53c` |
| `evidence/vs300_global_stereo_diagnostic.json` | `8aed2b5f054218f5ae369629cee78eb05dde5ec0b03af8fd9b52736ac83ac9b6` |
| `fixtures/vs300_minimal_fixtures.json` | `430567b06ddb9972051ee2282b4cc0fec771ba5c125753f3293cf75a07c21216` |
| `GLOBAL_STEREO_INFORMATION_MODEL.md` | `940453499f87070127d72c33568d998b88fb7b21ef74de0eeaafc16b2111e52a` |
| `GLOBAL_STEREO_ARCHITECTURE.md` | `edf0311d84218303fe5468612dc1011ffe241bf4d0bb8b81fee3c6f1d5fb6237` |
| `paper/stereo_graph/main.pdf` | `fdf07a4bd9bc931e4cd8cbe99112b6ca82050739e0c3a849ad3f440665e92d18` |
| `Experiment/Stereo/Data/Perception/cip_native_report.json` | `1ba360198ebd55e259e4ae042aa7587c97683a5589acb05d26ae76c0191fe821` |

Dataset SHA-256 for the 258-record ACS set:
`b90d64bba99d36f0be2429cad255e7836b244dfc26e7c9b4281b36d9ed51fff0`.

## R1--R10 claim-to-evidence matrix

| Requirement | Closed evidence |
|---|---|
| R1 baseline and mismatch explanation | Frozen 256 JSON, VS300 diagnostic/fixtures, separate 257 JSON, paper benchmark table and mismatch figure. |
| R2 information semantics | `GLOBAL_STEREO_INFORMATION_MODEL.md`; mutually consistent certificate-state tests. |
| R3 formal coupled-frame value | `synkit/Graph/Stereo/global_stereo.py`; RDKit-independent `test_global_stereo_value.py`. |
| R4 interchange and registry | `to_dict`/restore, public catalogue/export, stable global key, overlap rejection, explicit RDKit projection refusal tests. |
| R5 exact canonicalization | Coupled auxiliary graph in `global_configured.py`; atom, frame, slot, descriptor, and insertion-order invariance tests. |
| R6 mirror and relations | Double inversion, enantiomer, diastereomer, mirror-fixed near-miss, and mixed local/global tests. |
| R7 molecular evidence | `analyze_global_stereo_support`; positive/near-miss/VS300, atom-renumbering, malformed, disconnected, and cap tests. |
| R8 identity profiles | VS170/215/216/300 protocol regressions; chemical and ACS meanings remain independently named. |
| R9 corpus/safety/performance | Full 258-record reports; auxiliary size, traced-memory, timing, 256-atom/64-frame caps, and production special-case audit. |
| R10 reviewability | Public docs/API pages, one JCheminformatics paper with integrated technical appendices, completed sprint HTML, full tests, lint, strict docs, PDF, HTML, and diff gates. |

## Validation gates

- Focused closure suite: **28 passed**.
- Complete maintained suite: **3,907 passed, 31 skipped, 179 subtests
  passed** in 146.90 s.
- Lint and Python 1,000-line file-size gate: passed.
- Sphinx HTML with fresh environment, warnings as errors, offline
  intersphinx: passed.
- Sprint HTML: 11 files parsed; all local links resolved.
- Paper build: one 52-page `main.pdf`; references precede the integrated
  technical appendices; no undefined references, citations, overfull boxes,
  or LaTeX fatal errors.
- Production audit: no VS300 ID, fixture SMILES, expected-label, or manual-label
  branch in `synkit/`.
- `git diff --check`: passed.

## Reproduction commands

```bash
PYTHONPATH=. conda run -n synkit python \
  Experiment/Stereo/Chirality/global_certificate_benchmark.py \
  --output sprint/stereo/evidence/sprint_9_exact_plus_global_certificate_acs.json

PYTHONPATH=. conda run -n synkit python \
  Experiment/Stereo/Chirality/global_stereo_performance.py \
  --output sprint/stereo/evidence/sprint_9_global_stereo_performance.json

PYTHONPATH=. conda run -n synkit pytest -q
conda run -n synkit ./lint.sh

SYNKIT_DOCS_OFFLINE=1 MPLCONFIGDIR=/tmp/synkit-global-stereo-mpl \
  conda run -n synkit sphinx-build -E -W -b html \
  doc /tmp/synkit-global-stereo-docs

cd paper/stereo_graph
latexmk -pdf main.tex
```

## Explicit remaining boundary

This closeout does not claim arbitrary whole-framework geometry perception,
automatic configured-orientation perception, enhanced stereo populations,
complete CIP Rules 3--5, reaction stereo transport, release readiness, or
paper submission. These remain later programmes, not missing items from the
closed global coupled-frame requirement set.
