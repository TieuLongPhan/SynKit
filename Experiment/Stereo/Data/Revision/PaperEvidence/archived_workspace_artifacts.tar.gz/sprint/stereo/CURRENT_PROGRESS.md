# Stereo-graph current progress

**Updated:** 1 August 2026  
**Cycle:** stereo reaction-graph follow-up  
**Active sprint:** none  
**Status:** RX1--RX14 complete; bounded follow-up remains open

The active sequence is defined in [`FOLLOW_UP_PLAN.md`](FOLLOW_UP_PLAN.md).
Start with SF1; do not modify production behavior until its evidence boundary
is frozen.

## Remaining reaction-stereo work

- Keep validation and evidence generation platform-independent on Linux,
  macOS, and Windows.
- Refresh benchmark evidence only when inputs or implementation behavior
  change, retaining per-reaction expansion timing separately from orchestration
  time.
- Keep the formal model, executable contracts, documentation, and paper claims
  synchronized.
- Record any new chemistry family as a separate reviewed extension with
  positive, negative, and fail-closed evidence.

MTG composition is not part of this backlog; it is tracked in
[`../mtg/CURRENT_PROGRESS.md`](../mtg/CURRENT_PROGRESS.md).

## Stereo reaction programme

The implementation-ready reaction programme is now defined as fourteen gated
sprints in six phases:

1. RX1--RX2 freeze the baseline and close the information model.
2. RX3--RX5 close stable values, reference transport, and stereo-bearing
   ITS/DPO.
3. RX6--RX8 close rule extraction, reactor branch algebra, and coupled local
   outcomes.
4. RX9--RX10 close composition/fusion proof and stepwise mechanism replay.
5. RX11--RX13 close interchange, reviewed chemistry coverage, and
   metamorphic/adversarial/performance evidence.
6. RX14 closes public documentation, the ACS manuscript, and the final
   claim-to-evidence matrix.

The master plan is `stereo_rxn_plan.html`; the normative detailed roadmap is
`stereo_rxn_roadmap.md`; individual contracts are
`stereo_rxn_sprint_01.html` through `stereo_rxn_sprint_14.html`.

The starting baseline is the existing reviewed 80-positive/8-negative
MechanismBench stereo corpus and the 62-case orbit/legacy comparison
(58 agreements, 4 registered nonbinary differences, 0 unexpected
differences). RX1 must reproduce and checksum these before any production
change.

The programme builds on existing `StereoChange`, reference alignment,
outcomes, couplings, generic extraction, reactor propagation, stereo-bearing
ITS, fusion proof v2, and mechanism replay. It is not a greenfield rewrite.

RX1 froze the 80+8 corpus, 62-case migration comparison, public surfaces,
environment lanes, dirty-worktree boundary, and manuscript/source checksums.
The focused reaction stack passed 416 tests; the complete maintained suite
passed 3,919 tests with 31 skipped and 179 subtests passed. Evidence is in
`STEREO_RXN_BASELINE_MANIFEST.md` and
`evidence/stereo_rxn_baseline.json`.

RX2 added the normative information model and typed refusal taxonomy. All 88
frozen cases map to exactly one accepted assertion or refusal. The adjacent
stereo/mechanism/reactor validation passed 1,631 tests with one skip.

RX3 added immutable, hashable schema-v2 reaction values, deterministic JSON,
schema-v1 readers, and typed lossy-downgrade refusal. The adjacent gate passed
1,670 tests with one skip.

RX4 closed reference transport, application, relabeling, reversal, and
composition across all eleven configured descriptor families. The adjacent
gate passed 1,757 tests with one skip.

RX5 closed endpoint/transition ITS layers, stereo-only reaction centres,
strict DPO support validation, and both ITS reversion paths.

RX6 closed strict source-support validation, exact/generic replay, typed
genericization refusals, and self-verifying extraction certificates.

RX7 closed the four-mode execution matrix, deterministic branch algebra,
zero-weight handling, typed product-branch limits, and exact-product
aggregation of measure, multiplicity, and provenance.

RX8 closed normalized SYN/ANTI coupling values, correlated face branching,
strict context validation, paired reverse elimination, and a reviewed
four-positive/four-negative coupling corpus.

The user-supplied Figure 11 electrocyclic conrotatory/disrotatory machinery
rule is explicitly scheduled as an RX10 mechanism deliverable, including
thermal/photochemical context and wrong-mode negatives.

RX9 closed typed reaction-stereo composition, branch-measure proofs,
information-loss refusal, conditional reversal, and complete-document
tamper evidence for fusion proof v2 without introducing a new proof version.

RX10 closed endpoint/stepwise verification, checksum-bound stereo timelines,
and the user-requested Figure 11 electrocyclic machinery rule with
conrotatory/disrotatory, activation-context, substituted, reversal, relabeling,
and negative evidence.

RX11 closed canonical dict/JSON and authenticated internal-graph/GML
round trips for the complete reaction-stereo value. Reaction SMILES,
CXSMILES, and MOL V3000 now disclose and strictly refuse every unrepresentable
reaction-semantic axis; mechanism projections also disclose correlated
electrocyclic-motion and sidecar loss.

RX12 closed the reviewed claim-to-witness matrix for every public semantic
branch and named exact blockers for every deferred chemistry family.
Serialization variants are excluded from chemistry counts.

RX13 closed the metamorphic/adversarial/budget matrix and passed the complete
maintained suite, lint, compilation, schema, module-size, offline strict
Sphinx, local-link, and clean-diff gates.

RX14 closed the public reaction-stereo API guide with integrated migration
instructions, executable workflows, SR1--SR14 traceability, machine closeout record, and
ACS `achemso` main article, SI, and cover letter. The final maintained suite
passed 4,055 tests with 31 skips and 179 subtests. Strict offline Sphinx,
lint, compilation, JSON, module-size, local-link, clean-diff, and ACS build
gates passed. Release, push, and manuscript submission remain unauthorized.

## Closed molecular programme

## Delivered

- The immutable, RDKit-independent `FrameworkStereo` value represents one
  connected coupled-frame support with positive, negative, or unspecified
  orientation.
- Potential support, necessary chirality with unspecified orientation,
  configured positive/negative, incomplete comparison, and unsupported
  evidence are separate states.
- Dict/JSON interchange, public exports, registry identity, exact auxiliary
  stereographs, relabeling, mirror, enantiomer/diastereomer relations, and
  mixed local/global registries are implemented.
- `analyze_global_stereo_support` produces a map-independent molecular
  certificate. Topology may prove necessary chirality but cannot choose an
  enantiomer; configured orientation requires explicit provenance.
- Disconnected frame systems, supports above 256 atoms, systems above 64
  frames, malformed inputs, overlapping global entries, and unsupported RDKit
  projection fail closed.

## Audited results

| Protocol | Definitive | Agreement | Disagreements |
|---|---:|---:|---|
| Exact source-declared chemical stereograph, frozen baseline | 258/258 | **256/258** | VS170, VS300 |
| Exact plus necessary-global-certificate ACS protocol | 258/258 | **257/258** | VS170 |
| ACS-specialized topology-completion classifier | 258/258 | **258/258** | none |

The 257 result is a separately named protocol and does not replace 256. VS170
remains a chemical identity/profile difference (`S-I` versus `S#I`). VS300 is
the historical independent-local-input versus global-topology capability
boundary; the new certificate proves necessary chirality while leaving global
orientation unspecified.

## Final gates

- Complete maintained suite after the coordinate-CIP follow-up: 3,907 passed,
  31 skipped, 179 subtests passed.
- Focused global closure suite: 28 passed.
- Lint and 1,000-line file-size gate: passed.
- Offline strict Sphinx build (`-E -W`): passed.
- JCheminformatics paper: one 52-page `main.pdf`, with the complete technical
  appendices integrated after the references. There is no standalone
  `si.tex` or `si.pdf`.
- HTML parsing/local links, artifact schemas, special-case audit, and
  `git diff --check`: passed.

Checksums, commands, evidence paths, and the R1--R10 claim matrix are in
`COMPLETION_MANIFEST.md` and `SS_LOG.md`.

## Later stereo-graph work

Global closure does not implement automatic configured-orientation perception
for additional framework geometries, broader helical/planar/atrop/coordinate
perception, CIP Rules 3--5 completion, enhanced stereo-group populations,
reaction stereo transport, or a package release.

## Post-close RotA/CIP follow-up

- Added 24 synthetic constitutional RotA negatives: 13 axis-like cases have
  exact axis-fixed exchange automorphisms and 11 have no supported axis
  topology. All 24 are renumbering invariant; confirmed-axis false positives
  are 0/24.
- Preserved the RotA claim boundary: these controls do not establish
  configurational stability, rotational barriers, isolation timescales, or
  handedness.
- Proved a 299/300 ceiling for the supplied CIP SMILES contract because VS010
  and VS011 have identical input but opposite helical labels.
- Audited the pinned external 3D suite. A reflection-sensitive oriented-volume
  witness distinguishes VS010 from VS011, so coordinates remove the input
  obstruction without reading reference labels.
- CIP algorithm completion remains open: the pinned-coordinate native result
  is 187/300 exact records and 926/1,252 recovered labels while emitting 937.
  The SMILES-only baseline is 175/300. Remaining primary limitations are 83
  ranking, 21 orientation, and 9 unsupported-class records. Full completion
  requires hierarchical ring/digraph ranking, multi-unit Rule 4b, the three
  unresolved AT mappings, and TH3/TH5 coordination projection.

## Handoff

The molecular stereo-graph paper remains closed. Execute the reaction
programme in RX1--RX14 order and do not reopen molecular benchmarks or claims
unless new benchmark output is explicitly supplied.
