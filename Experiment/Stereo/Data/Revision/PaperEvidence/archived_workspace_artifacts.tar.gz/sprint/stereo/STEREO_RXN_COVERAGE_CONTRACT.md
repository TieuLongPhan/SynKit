# Stereo reaction chemistry-coverage contract

RX12 indexes claims to reviewed chemistry or executable graph witnesses. It
does not count serialization variants as chemical evidence.

## Exhaustive axes

`MechanismBench-stereo-branch-coverage-v1` covers:

- all six lifecycle states, seven population states, four determinacy states,
  and five evidence states;
- all eleven configured descriptor families at their declared execution or
  graph-transport boundary;
- vicinal addition/elimination and SYN/ANTI coupling;
- off, endpoint, and stepwise mechanism verification;
- forward/reverse, exact/generic rule, ITS, reactor, fusion, mechanism, and
  interchange routes;
- all ten typed reaction-stereo refusal codes.

Every branch names one accepted witness and one boundary/refusal witness.
References resolve to the frozen stereo, coupling, and electrocyclic corpora
or to executable tests. A reviewed specification-only diastereomer-set case
closes the information-model branch without claiming an executable population
generator.

## Deferred claims

The manifest names exact promotion blockers for isotope/pseudoasymmetry,
enhanced-group populations, locked ring-relative elimination, facial
pericyclic selectivity, and advanced allene/spiro/coordination execution.
These are not described as solved.

## Gate evidence

- Focused corpus, schema, reviewer, coupling, and machinery gate: 41 passed.
- Complete adjacent Graph/Stereo, ITS, Mechanism, Fusion, MTG, Rule, and
  Reactor gate: 2,399 passed, 1 skipped, and 115 subtests passed.
- JSON parse, strict new-test lint, and `git diff --check`: passed.
