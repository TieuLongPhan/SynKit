# Stereo reaction interchange contract

RX11 separates lossless reaction-semantic formats from endpoint carriers.

## Lossless routes

`canonical_dict` and `canonical_json` carry the complete
`synkit.reaction-stereo/2` value. `internal_graph` and `gml` carry the same
normalized JSON as a SHA-256-authenticated sidecar. These routes preserve
guards, effects, outcomes, couplings, assertions, refusals, virtual
hydrogen/lone-pair identities, and normalized ordering.

## Endpoint carriers

Reaction SMILES, CXSMILES, and MOL V3000 can encode some endpoint molecular
stereo but have no normative fields for executable reaction guards, changes,
product populations, coupled outcomes, semantic assertions, or typed
refusals. Projection therefore:

- succeeds for an empty reaction-stereo value;
- returns the caller's endpoint carrier plus a complete refusal ledger in
  diagnostic mode;
- raises `ReactionStereoInterchangeError` in strict mode;
- declares that a lossless sidecar is available.

Each issue names the format, semantic axis, affected targets, severity, and
stable code. Enhanced stereo groups are never interpreted as equivalent to a
reaction population assertion.

Mechanism projections additionally disclose discarded endpoint sidecars,
metadata, local effects, correlated electrocyclic motions, fishhook events,
and group/provenance structure. The legacy descriptor GML writer now reports
all graph-level metadata that it does not serialize.

## Gate evidence

- Focused RX11 and mechanism workflow gate: 55 tests passed initially; the
  final focused workflow including loss additions passed 50 tests.
- Complete adjacent Graph/Stereo, Mechanism, Fusion, MTG, Rule, and Reactor
  gate: 2,347 passed, 1 skipped, and 115 subtests passed.
- Strict new-file lint, compatibility lint, Python compilation, and
  `git diff --check`: passed.
