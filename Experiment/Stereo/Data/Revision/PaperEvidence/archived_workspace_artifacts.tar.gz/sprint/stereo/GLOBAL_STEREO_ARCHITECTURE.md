# Architecture decision: coupled global frame systems

**Status:** Accepted for Sprint 1 implementation design  
**Date:** 28 July 2026  
**Scope:** Molecular stereograph only  
**Evidence:** `evidence/vs300_global_stereo_diagnostic.json` and
`fixtures/vs300_minimal_fixtures.json`

## Decision

Represent global/topological stereochemistry as a **coupled frame system over
one `GlobalStereoSupport`**, not as a set of independently configured local
tetrahedral descriptors.

The support and its coupled-frame certificate may establish that a rigid
framework has two mirror-related global configurations. A binary global
orientation may be attached only when authorized orientation evidence exists.
Connectivity or an arbitrary common probe orientation must not select one of
the two configurations.

The concrete configured value should live under the existing
`GlobalStereo` marker. Its final public name is deferred until the isolated
formal model is implemented and reviewed; `FrameworkStereo` is the working
name used in this decision.

## Evidence that forces this decision

### Two distinct VS300 input contracts

The ACS row contains three source `@`/`@@` tags at one central carbon and two
cage centers.

1. RDKit's sanitized molecule removes all three tags because they are not
   conventional independent local tetrahedral stereocenters.
2. The exact configured-stereograph audit restores all three tags and
   interprets them as independent `TetrahedralStereo` values.
3. The ACS-specialized molecular classifier receives the sanitized molecule
   and places topology-completion probes at the same three centers.

The resulting local configurations differ:

| Center | Restored source tag versus topology probe |
|---:|---|
| 2 | opposite |
| 4 | equivalent |
| 18 | opposite |

The exact restored registry is achiral. Its representative mirror mapping
transports every restored descriptor into the mirrored registry.

The topology-probe bundle rejects that same mapping at centers 4 and 18, which
the mapping exchanges. The specialized whole-molecule matcher finds no
alternative mirror isomorphism and returns chiral.

Therefore the 256/258 result compares two different configured-graph
contracts. It is not evidence that one local tetrahedral parity implementation
is numerically wrong.

### Minimal fixture

`C1C2(OCC1)OCCC2` is the smallest ACS topology-completion positive found in
the audited corpus:

- 9 atoms;
- exact supplied stereograph without a configuration: achiral;
- specialized classifier without topology completion: achiral;
- specialized classifier with one topology probe: chiral.

The configured forms
`C1[C@@]2(OCC1)OCCC2` and `C1[C@]2(OCC1)OCCC2` are exact enantiomers when their
source tags are explicitly retained.

The designed 9-atom near-miss `C1C2(CCC1)CCCC2` is achiral with or without
topology completion. Replacing the two oxygen paths with carbon paths restores
the mirror symmetry.

## Rejected alternatives

### A. Preserve every source tag as an independent local descriptor

**Rejected as the global model.** This is the current exact-audit contract and
must remain available for source-declared configured identity, but VS300 proves
that it does not encode the ACS rigid-framework relation.

### B. Insert `parity=1` at every eligible sp3 center

**Rejected as configured identity.** This is a valid task-specific topology
probe used by the specialized ACS classifier. The common parity is arbitrary
and cannot be presented as supplied handedness.

### C. Treat every topology-completion-positive molecule as globally chiral

**Rejected.** A binary label alone supplies no support, mirror action,
canonical identity, relabeling witness, or configured enantiomer distinction.
It would also encourage record-specific promotion.

### D. Collapse chemical identity to ACS connectivity

**Rejected.** This would hide the genuine `S-I`/`S#I` distinction in VS170 and
change reaction-relevant molecular identity merely to increase agreement.

## Selected formal model

### Support

A `GlobalStereoSupport` identifies one connected molecular component or a
validated connected rigid subframework.

The global analysis certificate contains:

- the support atoms;
- the eligible oriented local frames used to express rigidity;
- their material and virtual references;
- the allowed simultaneous frame transformations;
- the exact graph witness establishing the coupled frame orbit;
- the information source and stability/rigidity authority outside identity.

Support validation must reject absent atoms, disconnected support, incomplete
frames, repeated material references, and virtual references owned by another
center.

### Configuration states

The model distinguishes:

1. **potential support** — topology can host the coupled relation but no
   rigidity/orientation authority is supplied;
2. **globally constrained, orientation unspecified** — an authorized
   rigid-frame system establishes a mirror pair but does not select a member;
3. **configured positive/negative orientation** — sidecar, coordinates, or
   another authorized source selects one global class;
4. **unsupported** — the input cannot faithfully retain or derive the needed
   global relation.

These states must not be collapsed into one nullable parity without retaining
their information meaning.

### Equivalence

Two coupled frame systems are equivalent when one exact atom mapping:

- preserves the selected molecular identity profile;
- maps the global support onto the other support;
- maps the complete coupled-frame relation into the same allowed global orbit.

Local frame ordering, coupled-frame record ordering, atom numbering, atom-map
numbers, provenance, and CIP labels are not identity.

### Mirror

Spatial reflection acts on the global configuration once. It must not invert
each participating local frame independently unless the formal coupled group
proves that operation is the correct global reflection.

Double reflection restores the exact configured value.

### Canonical stereograph representation

The preferred implementation extends the existing coloured auxiliary
stereograph:

- one global locus vertex;
- support-incidence vertices connecting the locus to every support atom;
- frame-relation and ordered-slot vertices for the coupled frames;
- a configuration-orbit gadget encoding allowed orientation-preserving global
  transformations;
- a global-orientation selection only for specified configurations.

The exact graph canonicalizer then handles atom relabeling, descriptor order,
support order, and symmetry. No separate canonical string algorithm should be
introduced.

## API boundary

The existing exact source-declared path remains meaningful and must not be
silently reinterpreted:

```text
source @/@@ tags
  → independent local configured stereograph
```

The new path is separate:

```text
molecular topology + authorized rigidity/orientation evidence
  → GlobalStereoSupport
  → coupled frame certificate
  → optional configured global orientation
```

For ordinary SMILES that cannot distinguish the mirror pair, the system may
prove potential or necessary global chirality but must not invent which
enantiomer was supplied.

## Consequences for the 256/258 paper result

The paper must retain the audited baseline:

- **VS170:** identity-definition difference; SynKit chemical identity is
  intentionally chiral, while ACS connectivity identity is achiral.
- **VS300:** configured-input/capability boundary; restored independent local
  tags are achiral, while sanitized topology completion is chiral.

Sprint 1 must not rewrite this history. Any new result produced by the coupled
global model is a separately identified protocol/result.

## Implementation gates

1. The minimal positive and near-miss are distinguished without record IDs.
2. Configured positive and negative global states are exact mirror partners.
3. Unspecified global orientation does not become an arbitrary configured
   state.
4. All atom, frame, support, and descriptor reorderings preserve the exact
   certificate.
5. Global and existing local descriptors compose without locus collisions.
6. Chemical, Lewis-state, and ACS-topology profiles retain their documented
   meanings.
7. Unsupported RDKit projection raises explicitly.
8. The existing 256/258 baseline remains reproducible.

## Sprint 2 resolution

The deferred information questions are resolved in
`GLOBAL_STEREO_INFORMATION_MODEL.md`:

- topology completion may authorize a necessary-chirality certificate but
  cannot select configured orientation;
- necessarily chiral but orientation-unspecified is a molecular outcome while
  configured stereograph identity remains incomplete;
- the configured wire class is `framework`; its Python value is
  `FrameworkStereo`;
- `GlobalStereoCertificate` carries analysis state and proof digests outside
  configured identity;
- the current coupled group is derived from exact tetrahedral frame orbits and
  exact graph automorphism. Additional framework geometry families require a
  separately typed, tested extension rather than an implicit guess.
