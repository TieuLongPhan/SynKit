# Stereo reaction reactor contract

RX7 closes the execution boundary between stereo-aware matching and exact
product enumeration.

## Mode matrix

| Mode | Declared guard | Inverse/absent input | Product contract |
|---|---|---|---|
| `ignore` | not enforced | accepted | fixed rule metadata; no validation claim |
| `require` | exact compatibility | refused | declared effects and outcomes only |
| `propagate` | relative compatibility | accepted | transport known orientation; preserve one unknown when evidence is absent |
| `strict` | exact and scope-complete | refused | validated declared effects and outcomes only |

Unknown parity is one underdetermined configuration. It is never expanded
into a racemate or mixture unless the rule carries an explicit population
outcome.

## Branch algebra

- Effects and couplings are traversed by sorted target identifier.
- Outcome alternatives retain declared order and multiply their local weights.
- A zero-weight alternative is not materialized.
- `stereo_branch_path` is the stable sequence of `(target, branch_index)`
  choices.
- `stereo_branch_weight` is the measure of one raw branch.
- Exact-product deduplication stores the sum as `stereo_aggregate_weight`,
  the number of contributors as `stereo_branch_multiplicity`, and lossless
  per-branch evidence in `stereo_branch_contributions`.
- Coupled face provenance remains separate in `stereo_coupling_branch`.

## Resource limits

`stereo_assignment_limit` bounds completed injective typed-port assignments.
`stereo_branch_limit` bounds product branches across all accepted
applications. Both fail closed with typed exceptions exposing the permitted
and requested-at-least counts; no partial public result is returned.

## Gate evidence

- Focused branch/mode/dedup and adjacent rule tests: 62 passed.
- Complete Reactor plus generic extraction suites: 457 passed and 112
  subtests passed.
- Strict new-file lint, compatibility-module lint with existing exclusions,
  Python compilation, and `git diff --check`: passed.
