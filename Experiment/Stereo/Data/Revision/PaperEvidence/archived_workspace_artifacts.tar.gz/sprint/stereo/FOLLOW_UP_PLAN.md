# Reaction-stereo follow-up plan

**Prepared:** 1 August 2026  
**Status:** planned  
**Foundation:** completed RX1--RX14 programme and SynKit 1.6.1

This plan covers only work that remains after the original reaction-stereo
closeout. It does not reopen the accepted molecular stereo model and does not
include MTG rule composition.

## Sprint sequence

| Sprint | Focus | Deliverables | Exit gate |
|---|---|---|---|
| SF1 | Cross-platform evidence freeze | Pin inputs, versions, schemas, Windows/macOS/Linux behavior, and known failure IDs. | CI and local evidence agree; line endings, memory accounting, and timeout capability are explicit. |
| SF2 | Reaction-expansion benchmark | Record per-reaction expansion time separately from loading, orchestration, serialization, and evidence processing; retain tuple and graph-backed results separately. | Every result has reproducible inputs, timeout/failure classification, and machine-readable timing fields. |
| SF3 | Formal and technical conformance | Recheck representation independence, mapping invariance, branch completeness, tuple behavior, composition premises, and fail-closed boundaries. | Each theorem-level claim has stated assumptions and an executable witness; no benchmark success substitutes for a proof. |
| SF4 | Evidence and paper reconciliation | Refresh tables and figures from frozen evidence; align README, documentation, manuscript, changelog, and release claims. | Every public number resolves to one artifact and protocol; repository, document, and package gates pass. |

## Execution rules

1. Complete SF1 before interpreting performance or failure counts.
2. Measure reaction expansion itself; report total runtime only as operational
   context.
3. Keep tuple and graph-backed representations under the same mathematical
   contract while reporting implementation costs separately.
4. Classify timeout, unsupported capability, invalid input, no match, and
   incorrect result as different outcomes.
5. Do not move MTG overlap, composition, or pathway-construction work into
   this track. Shared abstractions require independent gates in both plans.

## Evidence boundary

New artifacts belong under `evidence/follow_up/`; reduced reproductions belong
under `fixtures/follow_up/`. Generated bulk output remains outside the commit
tree unless a sprint explicitly approves a bounded evidence artifact.
