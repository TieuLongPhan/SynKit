# Canonicalization of Permutation-Labelled Stereographs

## Core idea

Develop an exact canonicalization framework for molecular stereographs. Rather than treating a stereocentre as a local `R/S`, `E/Z`, or parity label, represent it as a configuration class under a geometry-specific local permutation group. Encode those local configuration classes in a coloured auxiliary graph and apply a complete graph canonizer to obtain a unique global stereograph representative.

The central claim is:

> A stereograph with local permutation-group semantics can be faithfully reduced to a coloured graph, enabling exact canonical labeling, stereo-aware automorphisms, global chirality classification, and later stereochemically equivariant graph rewriting.

This is not another local ranking heuristic. It is canonicalization of the complete configured stereograph.

---

## 1. Stereograph model

Let a stereograph be

\[
\mathcal X=(B,\mathcal S),
\]

where \(B\) is a labelled molecular or Lewis graph and \(\mathcal S\) is the set of stereo loci.

Use **bond incidences (ports)**, rather than only neighbouring atoms, as ligand positions. This supports rings, multiple bonds, explicit Lewis resources, loops, and half-edges.

Each stereo locus is

\[
s=(\tau_s,P_s,\Gamma_{\tau_s},[\pi_s]),
\]

where:

| Component | Meaning |
|---|---|
| \(\tau_s\) | Stereo geometry: tetrahedral, alkene, axial, square planar, etc. |
| \(P_s\) | Ordered set of \(k_s\) ligand ports/incidences |
| \(\Gamma_{\tau_s}\leq S_{k_s}\) | Permutations that preserve the same local configuration |
| \([\pi_s]\) | The configuration orbit/coset; independent of input atom ordering |

For a tetrahedral locus:

\[
\Gamma_{\mathrm{tet}}=A_4\leq S_4.
\]

The twelve even permutations describe the same configuration; any odd permutation gives its inversion.

The implementation should provide a finite geometry table:

```text
geometry → port arity → local symmetry group → mirror action
```

Global chirality must be defined only after this local table is specified.

---

## 2. Stereo-preserving isomorphism

A mapping \(f:\mathcal X\to\mathcal Y\) is a stereo-isomorphism if it:

1. is an isomorphism of the labelled molecular/Lewis graph;
2. maps each stereo locus to one of the same geometry type;
3. maps its port configuration to the same \(\Gamma_\tau\)-orbit.

Write this as:

\[
\mathcal X\cong_{\mathrm{stereo}}\mathcal Y.
\]

This is the central equivalence relation. Canonicalization, equality, deduplication, automorphisms, global chirality, and reaction rewriting all derive from it.

---

## 3. Faithful auxiliary-graph encoding

Construct a coloured auxiliary graph \(\Phi(\mathcal X)\).

### 3.1 Base-graph encoding

- Atom vertices carry element, isotope, charge, radical, and Lewis-state labels.
- Each bond or explicit resource is represented by a typed vertex linked to the relevant atoms. This uniformly permits parallel edges, loops, \(\sigma\)/\(\pi\) resources, and half-edges.
- Every stereo locus has a geometry-coloured locus vertex.
- Every ligand incidence has a port vertex.

### 3.2 Orbit-tuple encoding of a local configuration

For each stereo locus \(s\), construct its configuration orbit:

\[
O_s=\{\gamma\pi_s:\gamma\in\Gamma_{\tau_s}\}.
\]

For every ordered tuple in \(O_s\), create one tuple-relation vertex. Connect it to its \(k_s\) ports through position-coloured slot vertices:

```text
tuple relation
 ├─ slot 1 ─ port
 ├─ slot 2 ─ port
 ├─ ...
 └─ slot k ─ port
```

The slot colours preserve tuple position. The complete set of tuple-relation vertices encodes the permitted orbit.

For tetrahedral stereochemistry, one configuration contains the 12 orientation-preserving arrangements. An odd ligand exchange maps this set to the opposite orbit and therefore cannot be accepted as an automorphism.

This construction is deliberately explicit rather than minimal. It is straightforward to implement and prove correct. The relevant chemical groups are small:

\[
|A_4|=12,\qquad |D_4|=8,\qquad |O|=24.
\]

---

## 4. Main theorems

### Theorem 1 — Faithful expansion

\[
\mathcal X\cong_{\mathrm{stereo}}\mathcal Y
\iff
\Phi(\mathcal X)\cong_{\mathrm{col}}\Phi(\mathcal Y).
\]

**Proof strategy.**

- A stereo-isomorphism extends naturally to atom, bond/resource, locus, port, slot, and tuple-relation vertices.
- Conversely, a colour-preserving auxiliary-graph isomorphism must preserve all those roles.
- At a stereo locus, preservation of the entire tuple-orbit set implies that the induced port permutation belongs to \(\Gamma_\tau\).

This is the principal formal result.

### Theorem 2 — Canonical stereograph theorem

Let \(\operatorname{Can}\) be a complete coloured-graph canonical-labeling function. Define:

\[
C_{\mathrm{SG}}(\mathcal X)
=
\operatorname{decode}\!\left(\operatorname{Can}(\Phi(\mathcal X))\right).
\]

Then:

\[
C_{\mathrm{SG}}(\mathcal X)=C_{\mathrm{SG}}(\mathcal Y)
\iff
\mathcal X\cong_{\mathrm{stereo}}\mathcal Y.
\]

The proof follows directly from Theorem 1 and completeness of the underlying graph canonizer.

### Corollary 3 — Stereo-aware automorphism group

\[
\operatorname{Aut}_{\mathrm{stereo}}(\mathcal X)
\cong
\operatorname{proj}_{B}
\left[\operatorname{Aut}(\Phi(\mathcal X))\right].
\]

This yields exact atom and ligand-incidence orbits.

### Corollary 4 — Global chirality

Let \(\mu\) be the geometry-specific mirror map. Then:

\[
\mathcal X\text{ is globally achiral}
\iff
C_{\mathrm{SG}}(\mathcal X)=C_{\mathrm{SG}}(\mu\mathcal X).
\]

This captures meso structures automatically.

The mirror map is geometry-specific. It changes tetrahedral and axial handedness, but it does not automatically interchange every configuration of every geometry; an isolated \(E/Z\) alkene is not itself a chiral object.

### Theorem 5 — Stereo-equivariant rewriting (extension)

For a graph-rewrite rule \(p\), require:

\[
p(\alpha\mathcal X)=\alpha p(\mathcal X)
\]

for every stereo-isomorphism \(\alpha\). Rewriting then descends to isomorphism classes:

\[
[\mathcal X]_{\cong_{\mathrm{stereo}}}
\xrightarrow{p}
[p(\mathcal X)]_{\cong_{\mathrm{stereo}}}.
\]

This connects canonical stereographs to Lewis-labelled electron-flow rewriting.

---

## 5. Canonicalization algorithm

```text
StereoGraphCanon(X)
    1. Normalize the labelled molecular/Lewis graph.
    2. Obtain configured stereo loci and ligand incidences.
    3. Construct Φ(X) with orbit-tuple gadgets.
    4. Run a complete coloured-graph canonicalizer.
    5. Project the canonical order to obtain:
         - canonical atom order,
         - canonical bond/resource order,
         - canonical stereo-locus and port order,
         - normalized local configuration orbit.
    6. Serialize the canonical stereograph code.
```

The graph canonizer performs the operational local–global loop internally:

```text
partition refinement
→ propagation to arbitrary molecular depth
→ individualization of unresolved symmetry classes
→ refinement again
→ lexicographically minimal representative
```

Therefore, do **not** build a separate external cycle of local ranking and global ranking. Encode local stereo semantics once, then canonize the full auxiliary graph.

---

## 6. Complexity statement

For base-graph size \(n\), the expanded graph has size:

\[
O\!\left(
n+\sum_{s\in\mathcal S} k_s|\Gamma_{\tau_s}|
\right).
\]

For a fixed chemical geometry catalogue, both \(k_s\) and \(|\Gamma_{\tau_s}|\) are constants, so graphification is linear in molecular size.

Do not claim polynomial-time canonicalization in general. State instead:

> The stereograph-to-coloured-graph reduction has linear size for a fixed stereo catalogue, while complete canonical labeling is delegated to a mature individualization–refinement engine.

---

## 7. Development scope

### Initial configured-organic implementation

1. Tetrahedral atom stereo, including implicit and explicit hydrogen.
2. Double-bond \(E/Z\) stereo.
3. Isotopes and charge labels.
4. Exact canonical code and canonical atom ordering.
5. Enantiomer and meso classification through mirror comparison.

### Complete configured-stereograph implementation

6. Axial and atropisomeric stereo.
7. Square-planar, trigonal-bipyramidal, and octahedral coordination stereo.
8. Explicit Lewis resource labels.
9. Stereo-equivariant mechanism rewriting.

### Version 3: stereo perception and enumeration

10. Identify candidate stereo loci from unconfigured graphs.
11. Enumerate assignments modulo stereo-aware automorphisms.
12. Classify stereoisomers into achiral structures and enantiomeric pairs.

---

## 8. Essential validation suite

- Random atom renumbering must leave the canonical code unchanged.
- Enantiomers must have distinct canonical codes.
- Meso compounds must have the same code as their mirror.
- Duplicate ligand cases must be correctly recognized as non-stereogenic.
- Deep ligand distinctions must be resolved globally, even when directly attached atoms are identical.
- Agreement with RDKit for its supported configured tetrahedral and \(E/Z\) cases.
- Agreement with StereoMolGraph for pairwise equality/enantiomer comparisons.
- SN2 inversion and stereospecific alkene addition as graph-rewriting demonstrations.

---

## Proposed paper focus

> **Canonicalization of permutation-labelled stereographs, with global chirality and stereochemically equivariant Lewis graph rewriting.**

The principal novelty is the faithful treatment of local stereochemical permutation orbits within an exact global canonicalization framework—not the replacement of an existing graph-canonization engine.
