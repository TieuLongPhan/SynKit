# Stereo manuscript — Paper I (molecular-graph layer)

This directory is the canonical package for:

**From local permutations to global identity: exact canonicalization of
molecular stereographs**

The paper's USP is: **canonical local stereo, exact global identity, derived
labels**. The novelty claim is the auditable one-way contract connecting these
layers, not the generic use of ordered neighbour lists, permutation groups, or
local-to-global stereo comparison. Andersen et al. and StereoMolGraph are
credited for those prior foundations.

Split out of the former single manuscript in `paper/stereo`, which is retained
as the pre-split reference. This paper covers the **molecular-graph layer**:

- a staged pipeline of candidate-carrier perception, configuration-neutral
  local-neighbor frames, configuration attachment/orbit identity, exact
  configured-stereograph canonicalization, whole-molecule mirror
  classification, and optional derived naming; carrier evidence is never
  itself a confirmed or configured stereo element;

- the typed support hierarchy (atom / bond / axis / path / plane / global) that
  separates *where* a stereo element lives from *how* it is configured;
- the Lewis-labeled graph (LLG) substrate, with explicit lone-pair, radical,
  sigma-bond, and pi-bond resources, plus typed virtual references (`@H`,
  `@LP`);
- seven registered orbit shapes (tetrahedral, square-planar,
  trigonal-bipyramidal, octahedral, planar-bond, atrop-axis, cumulene-axis)
  plus configured helical-path and planar-chirality descriptors;
- an exact auxiliary stereograph certificate for all ten configured
  families, plus whole-stereograph identity/enantiomer/diastereomer
  classification that does not consult CIP labels;
- a coupled-frame ``FrameworkStereo`` value over global support, with
  topology-proven necessary chirality kept separate from configured
  positive/negative orientation;
- representative-independent double-coset relation classes and concrete
  transport witnesses, with proofs;
- neighbour alignment, stereo-preserving graph morphisms with explicit
  information/presence policies, functorial witness composition, and the
  stereo-aware value identity / hashing contract;
- derived CIP labels as *witnessed projections* — an independent ranking kernel
  recording the deciding sequence rule, with typed failure statuses instead of
  guesses — never as stored identity;
- whole-molecule chirality by exact configured-certificate mirror comparison,
  kept distinct from the ACS-specialized topology-completion classifier and
  its four-state completion-population assessor;
- RDKit and StereoMolGraph interchange boundaries.

The reaction layer — rules, ITS, reference-aligned change, reversal, fusion
proof v2, mechanism replay — is the companion paper in `paper/stereo_rxn`,
cited here as `phan2026stereorxn`.

`SynKit` is the reference implementation, not the paper's primary contribution.

Active development is tracked in `../../sprint/sprint_plan.html`.
The current ten-sprint cycle established typed tetrahedral, double-bond, cumulene, and atrop
perception; exact carrier-stabilizer ligand classes; recursive
configuration-neutral neighborhood frames; the complete auxiliary
stereograph for ten configured families; exact assignment enumeration; and
planar-chirality support. Supplied configuration and CIP are downstream outputs
and never frame-ordering or certificate inputs. Coupled tetrahedral global
stereo is configured. Synthetic constitutional negatives now cover broad-axis
specificity, while experimental stability/handedness validation, additional
global geometry families, full CIP sequence rules, coordinate-based
orientation perception, and symmetry-pruned certificate scaling remain
declared gaps.

## Files

- `main.tex` — the single manuscript source, including the technical
  appendices: support tables, orbit enumerations, extended-descriptor laws,
  P1--P11, morphism policies, CIP contracts, and benchmark tables.
- `cover_letter.tex` — Journal of Cheminformatics cover-letter draft.

### Structure

The manuscript follows a Journal of Cheminformatics-oriented structure:
Background → Methods and LLG notation → carrier perception and configuration
attachment → exact graph canonicalization → molecular chirality →
Experiments and results (protocol and result subsections) → Discussion →
Conclusions → Declarations → References → technical appendices.  The methods
include an end-to-end chirality algorithm,
a binary soundness/completeness theorem under an explicit support boundary,
and a four-state completion algorithm for underspecified input.

- `fig/` — figures used by this paper only. `support_hierarchy.tex`,
  `support_motivation.tex`, `axial_helical.tex`, `cip_projection.tex`, and
  `pipeline.tex` are new to
  this manuscript; the rest are inherited from the pre-split package.
- `authors.tex`, `references.bib`, `sn-jnl.cls`, `sn-mathphys-num.bst` —
  submission metadata and template.

## Build

```bash
conda run -n synkit python Experiment/Stereo/Chirality/draw_exact_mismatch_figure.py
cd paper/stereo_graph
latexmk -pdf main.tex
latexmk -pdf cover_letter.tex
```

`main.tex` is self-contained and produces the complete article and appendices
as one PDF.  There is no separate `si.tex` build.

## Provenance of the reported numbers

The values below are the current development snapshot and must be regenerated
from the benchmark archive before submission:

| Number | Source |
| --- | --- |
| 3,907 passed, 31 skipped, 179 subtests | `python -m pytest -q` (full suite) |
| Configuration-free local: 66,468/66,468 representations and 3,476/3,476 carriers over 1,218 rows | `Experiment/Stereo/Data/Canonicalization/{internal,acs,cip,rota}_local_canonicalization_report.json` |
| Formal A/B/C: 2,160/2,160 assignments over 30/30 cases; raw A/B plus raw C/VS146: 3,353,600/3,353,600 encodings over 22 scoped cases; zero timeout/failure | `Experiment/Stereo/Data/Canonicalization/Global/` |
| 940 raw local representations → 67/67 exact classes; 201 per-class + 528 representative relabellings | `Experiment/Stereo/Data/Canonicalization/global_local_canonicalization_report.json` |
| 888/888 public ACS atom permutations, 0 failures | same report, external tier |
| 32 multi-element assignments → 31 global classes; 13 enantiomer pairs, 64 diastereomer pairs, 5 mirror-fixed classes | `Experiment/Stereo/Data/Canonicalization/multi_element_canonicalization_report.json` |
| 7/7 multi-element ACS cases; 14/14 sampled renumberings; 18 configured elements | same report, public tier |
| RotA 40 multi-locus records/88 loci; CIP 153 multi-\(R/S\) records and 116 multi-attached records | same report, task-scoped extraction tiers |
| Pairwise relation conformance 9/9 | `Experiment/Stereo/Data/Chirality/stereoisomer_relation_report.json` |
| ACS topology completion 258/258; exact supplied-configuration chemical stereographs agree with 256/258 ACS topology labels; separately versioned exact-plus-global certificate agrees with 257/258 without selecting global orientation | `Experiment/Stereo/Data/Diagnostics/benchmark_report.json`; `Experiment/Stereo/Data/Chirality/exact_acs_mirror_report.json`; `sprint/evidence/sprint_9_exact_plus_global_certificate_acs.json` |
| Four-state 125/66/67/0, 214 constitutions, 258 definitive | same report, stereo-stripped protocol |
| ACS local perception retained/erased 1007/743 of 1007; 258/258 renumbering in each setting | `Experiment/Stereo/Data/Perception/full_detection_report.json` |
| CIP local perception retained/erased 1252/969 of 1252; 300/300 renumbering in each setting | same report |
| RotA perception 698/698 loci and 15/15 paths in both settings; 650/650 renumbering in each setting | same report |
| Synthetic RotA constitutional negatives 24/24 invariant: 13 exact symmetry witnesses, 11 no-axis controls, 0 confirmed-axis false positives | `Experiment/Stereo/Data/RotA-Synthetic/negative_axes.json` |
| Erased-input misses: ACS 264 and CIP 283, all symmetry-related carbon tetrahedral carriers and all recovered with retained neighbor frames | same report |
| CIP naming with pinned 3D: 187/300 exact; 926/1252 labels, 937 emitted; SMILES-only 175/300 | `Experiment/Stereo/Data/Perception/cip_native_report.json` |
| CIP supplied-SMILES ceiling 299/300; pinned external 3D coordinates distinguish the VS010/VS011 conflict | `Experiment/Stereo/Data/CIP/input_contract_audit.json` |
| Class sets 6 / 9 / 6 / 4 | `synkit/Graph/Stereo/descriptors.py` |
| Seven local orbit shapes; ten local configured families plus one coupled framework family | `orbits.py`; `configured.py`; `global_stereo.py` |

The 300/300 StereoMolGraph descriptor bridge and 6/6 conformance figures in the
pre-split manuscript were **not** re-measured and are not current evidence;
regenerate them before restoring either claim to a submission draft.

## Before submission

- Replace the placeholder `phan2026stereorxn` bib entry with the companion
  paper's preprint/journal reference.
- The companion paper (`paper/stereo_rxn`) may still recap older class sets and
  pre-enhancement counts; sync it after the molecular benchmark and paper
  release is frozen.
- Freeze an immutable release, regenerate every result count, verify author
  metadata/CRediT/funding text, and archive the environment.
