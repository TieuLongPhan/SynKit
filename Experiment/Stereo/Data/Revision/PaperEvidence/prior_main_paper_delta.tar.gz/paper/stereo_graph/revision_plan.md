**Stereo graph manuscript revision and submission plan**

Prepared on 2 October 2026 and updated on 3 October 2026 for the molecular stereo paper in this directory. This plan turns the critical review into an ordered programme of code corrections, independent validation, evidence reconciliation, manuscript revision, and submission preparation. Its purpose is to establish which claims the implementation and archived experiments can support before polishing those claims for publication.

**Current scope:** the user has explicitly requested “Finish the review package; no publication or submission.” The original full programme below is retained as an audit trail and future submission guidance. Public DOI assignment, publication, portal submission and submission-only declarations are outside this current task.

**Status:** scientific preparation and local document/source checks are verified in the isolated `stereo-paper-revision` worktree. Phases 0–5 and scientific writing in Phase 6 are complete within their declared scopes, including the disclosed assistant proof-review substitute. Authorship, full Syndoku funding and the requested coauthor roles are applied. The final updated local review archive is now verified. See [revision_log.md](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/paper/stereo_graph/revision_log.md) for evidence and limitations. The initial review reproduced two incorrect completeness verdicts, identified weaknesses in benchmark acceptance conditions, and found differences between manuscript results and their cited archives. These are new audit findings following the historical molecular Sprints 1–10. The historical completion records remain evidence of that earlier programme; they are not acceptance evidence for this revision.

The recommended scientific centre is a faithful encoding of configured molecular stereographs and the canonical identity it induces. Perception, topology completion, and CIP naming remain separate operations with explicit input contracts. Journal of Cheminformatics, article type Methodology, is the proposed first target.

The main starting points are [the manuscript](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/paper/stereo_graph/main.tex), [the experiment inventory](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/Experiment/Stereo/README.md), [configured identity and completeness](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/synkit/Graph/Stereo/configured.py), [the orbit kernel](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/synkit/Graph/Stereo/orbits.py), and [the historical molecular roadmap](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/sprint/stereo/stereo_graph_roadmap.md).

**Current evidence and remaining priorities**

The completed work below belongs to the isolated revision worktree. It does not mean that the original manuscript or original branch already contains the corrections. The phase descriptions retain the full programme so that its assumptions and acceptance conditions remain visible; completed phases need verification at the final release, rather than a second implementation from scratch.

| Work item | Verified revision checkpoint | What remains |
| --- | --- | --- |
| Completeness and identity profiles | Strict partial inputs refuse; isotope/phosphate and resonance-family contracts are repaired; unsupported framework helpers refuse explicitly | Preserve these contracts in the final API and manuscript |
| Independent mathematical validation | 63 cases, 2,439 assignments, all seven deliberate defects rejected; archived positive maps replay | Final proof reading and clean release reproduction |
| Public local configuration validation | 1,218 rows, 3,476 carriers, 66,468 raw representations; all 6,999 positive maps replay | Make clear that supplied/perceived carrier inventories are conditional inputs to this test |
| Mixed-family formal validation | 30 cases and 2,160 assignments pass the independent partition gate | Final result table and assumptions; no need to rerun enormous raw products merely to increase the headline count |
| Naming protocols | SMILES-only: 175/300 exact records and 902 correct of 913 emitted labels. Coordinate-assisted: 187/300 and 926 correct of 937 emitted labels | State that the coordinate protocol also uses supplied family categories; reconcile every caption and secondary table |
| Corpus overlap | 1,208 external rows represent 904 distinct constitutions under the recorded isotope-preserving key; all 258 ACS rows occur in CIP | Retain task-specific denominators and avoid an independent-corpus or retrospective holdout claim |
| Closest comparator | On all four disputed ACS cases, both algorithms agree after lossless transfer of the same configured inventory | Explain information boundaries; do not claim generic algorithm superiority from the specialized 258-versus-254 comparison |
| RDKit release representation | RDKit 2026.03.1 preserves 53 distinct-ligand states across all 165,960 atom permutations; documented equivalent encodings and round trips agree | Retain the finite-probe boundary; these results do not assess coordinates, naming or chemical stability |
| Refreshed perception and relation reports | All seven protocol stages completed; original reports' Python matches immutable commit `b1170af`; source/input checksums verified. The six remaining protocols and chemical evidence now enter a 269-claim, 37-artifact ledger with record-level contracts | Corrected detector verifies 904 constitutions and unchanged evidence for all 1,208 rows; final release reproduction remains |
| Registration | All 30 pipeline runs recover expected partitions; profile/refusal checks, final figure and manuscript interpretation complete | Retain the measured absence of a crossover and whole-study memory/host-load qualifications |
| Controlled cost study | All 540 planned trials attempted: 513 complete, 9 resource-censored and 18 expected boundary refusals; no code disagreement; source hashes verified against the immutable commit | Preserve the measured limits and reproduce from the final release |
| New chemical evaluation and submission package | 38/40 coordination cases certify and pass, with two frozen geometry refusals; all 48 sourced negatives pass. All 60 frozen RotA structural annotations replay and all 128 configured assignments pass. Main text, separate chemical table and detailed annotation appendix retain physical and source-assistance boundaries | Final editorial check and complete package reproduction |

The fresh registration report at [registration.json](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/Experiment/Stereo/Data/Revision/CleanReleaseFull/execution/registration.json) measures a from-scratch workload against comparison with existing group representatives. At 128 records the medians are approximately 0.140 s for pairwise grouping and 1.078 s for certificate grouping. Certificates are slower at every tested size. All 30 pipeline runs recover the independent partitions. Only three repetitions and recorded background host load limit generalization; the 126.52 MiB memory observation belongs to the whole study, rather than one pipeline.

The current work is to finalize the local review package, including the user-directed funding and contribution updates. All 35 clean research stages have completed, and the primary 269-claim, 37-report ledger now selects their validated results while preserving the previous selection. Every changed resource observation remains visible. Author submission approval, competing interests and any public DOI are deferred to a future submission; they are not asserted in this review package. The unconfirmed companion citations have been removed from the submission narrative; reaction transport remains outside this paper’s scope.

The structured proof review records 17 obligations in [structured_proof_review.json](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/paper/stereo_graph/revision/structured_proof_review.json). It made normalization and authorization transport explicit and corrected the automorphism projection's uniqueness argument to use the full typed carrier key. This is an assistant review supported by finite checks, not an independent human reader or formal machine verification. All 35 clean research stages now complete and their results are selected; author submission approval and exact public release identity would be required only for a future publication.

**Release progress, 3 October 2026.** The Linux/Python 3.12.12 base environment is locked with hashes for 46 wheels and installed without inherited system packages or SynKit. The package reports version 1.6.2; exact source commits and artifact hashes identify this revision. The licensed original CIP archive, metadata, prepared SMILES and original coordinates are provided under CC BY-NC 4.0 in [CIPPublished](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/Experiment/Stereo/Data/Revision/CIPPublished/ATTRIBUTION.md). Two citation punctuation repairs leave the scientific fields unchanged. Original coordinates reproduce every native and RDKit comparator record for all 300 cases. The primary 269-claim ledger uses this original-source report; its 60 focused contract checks pass. The amended GitHub coordinates remain separately identified historical evidence without an asserted publisher grant.

The clean `e2526b9` checkpoint completes all three bounded stages: 254 tests without skips, five independent cases with all seven deliberate defects rejected, and 53 RDKit states over 165,960 atom permutations. All 531 captured Python files match the immutable source. A second isolated environment verifies all 470 installed wheel files, all 46 locked dependency versions, 18 mirror/profile cases and 53 coordination encoding states under two atom orders. The extracted `9096af7` research archive verifies all 1,802 files byte-for-byte. Its distinct local verification commit is `d8e3083`. From that extracted copy, lint passes and the complete repository suite passes 5,558 tests plus 668 subtests, with 24 documented skips and no failures. Two required frozen Synister fixtures were restored unchanged; its 83 CI-selected contracts pass. An additional whole Synister research-suite run has 31 missing-evidence failures outside this paper's gate, all preserved. See [archive reader verification](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/paper/stereo_graph/revision/release/research_archive_9096af7_checkpoint.json) and [release checkpoint](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/paper/stereo_graph/revision/release/release_checkpoint.json).

The full research sequence is now complete: all **35 stages** return successfully from unchanged scientific source `e2526b9`. The original failed attempt and the hash-pinned optional-comparator dependency overlay remain preserved. The [raw archive](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/Experiment/Stereo/Data/Revision/CleanReleaseFull/archive_manifest.json) retains all 90 execution files byte-for-byte. Two separate portable projections relocate linked input paths and explicitly recount zero-valued cost display bins without editing scientific records or summaries. The [selection verification](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/paper/stereo_graph/revision/release/clean_full_selection_verification.json) checks all 531 scientific Python files, all 269 selected claims, 37 report contracts and the fresh figures. The previous primary selection remains in [its snapshot](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/paper/stereo_graph/revision/release/pre_clean_full_selection/snapshot_manifest.json).

Every local/formal record agrees with its previous scientific result apart from measured times; all 2,439 independent witnesses replay. Both 300-record CIP protocols and all comparator results are unchanged, as are all 1,208 detector records and every chemical-summary field. The five-second source-identity run has three timeouts, VS126, VS127 and VS208: **255 definitive outcomes and 253 correct decisions over 258 inputs**. The exact-plus-global 30-second protocol remains 257/258 with all inputs definitive. Controlled costs retain all 540 trials: 513 complete, three timeouts, six memory-limit outcomes and 18 expected boundary refusals, with no certificate disagreement. Four repeated tetrahedral components now reach the memory limit in full-group mode, rather than the earlier wall timeout. The numerical selection changes 32 claims, primarily timing and memory observations; manuscript text and figures use the fresh selection. All 60 focused report-contract tests pass. Journal review files provide a 54-page main paper, 55-page supporting information and 34-file editable source ZIP. All nine individual figures rebuild with identical renderings from their 23-file editable archive; final updated research-archive extraction and author review remain required.

The updated `e7f7460` [complete review archive](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/paper/stereo_graph/revision/release/research_archive_e7f7460_checkpoint.json) now verifies all 1,990 files byte-for-byte and reproduces the exact original Git tree under a separately identified local verification commit. All 531 scientific Python files still match the executed source. From extraction, every selected claim validates, all 60 focused contracts pass, and the combined manuscript and letter reproduce identical text. The nine individual journal figures and upload-caption metadata are now prepared and verified in the [journal package](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/paper/stereo_graph/revision/generated/submission_review/README.md). The [editorial checkpoint](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/paper/stereo_graph/revision/release/journal_final_editorial_checkpoint.json) binds current documents, corrected graphics and selected results. The updated review archive containing these final figure files still requires its extraction check. Author facts, author review and the exact persistent DOI must then identify the final submission freeze; the existing Zenodo concept DOI is not evidence for this revision.

The current [claim register](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/paper/stereo_graph/revision/current_claim_evidence.csv) binds 269 numerical claims and 17 proof obligations to exact evidence. The [proof release binding](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/paper/stereo_graph/revision/release/structured_proof_release_binding.json) checks all 33 labelled statement/immediate-proof blocks in both manuscript and technical appendix against the reviewed base, with current locators and clean finite checks. The SACA v2 primary abstract and author experiment code are inspected and positively credited; its full text was inaccessible, so claims about uninspected proofs are excluded. The [requirement audit](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/paper/stereo_graph/revision/release/plan_requirement_audit.json) retains all 63 original tasks, gates and submission criteria plus the explicit user enhancements, while recording the latest review-only scope. These automated checks are a disclosed substitute for reader roles; they do not establish independent human review or a formal machine proof. Final author declarations, author review and the exact archive DOI remain unresolved. Unconfirmed companion references are preserved in the earlier-source snapshot and omitted from the submission bibliography.

**Critical review and revision priorities**

My editorial judgment is that the strongest paper is about exact identity for a declared configured representation. The current submission risk comes from combining that theorem with broader statements about perception, chemical completeness, nomenclature and practical performance whose evidence has different input boundaries. Address the following reviewer questions explicitly:

| Reviewer question | Risk in the original draft | Revision and acceptance condition |
| --- | --- | --- |
| What does the faithful reduction add to earlier canonicalization and permutation models? | Local permutation encoding and molecular canonicalization already have predecessors | State the precise construction, supported catalogue and transport guarantee; compare each against primary sources and current implementations |
| Does the validation test both directions of identity? | Renumbering invariance alone also accepts a constant identifier | Retain the independent complete-partition comparison and all seven rejected mutations; disclose its shared mathematical inputs |
| Is the chirality answer about a molecule or its supplied configuration? | A partially specified registry can exclude its mirror while admitting an achiral completion | Declare the required inventory, profile and completeness policy; preserve typed refusals and the partial-to-meso counterexample |
| Are comparisons receiving equivalent information? | Supplied family categories, coordinates and different perceived inventories change the task | Present separate protocols and matched-inventory diagnoses; avoid a superiority claim from the specialized ACS score |
| How much distinct chemical evidence is present? | Record counts and repeated encodings can exaggerate chemical diversity | Report overlap and unique constitutions; add prospectively selected, independently annotated chemical examples |
| Is canonicalization practically affordable? | Output expansion and full automorphism materialization can dominate; the registration study shows no speed advantage | Publish phase costs, memory, output size and censored outcomes; limit the practical claim to measured behavior |
| Can another researcher reproduce the conclusions? | Development counts, mutable inputs and incomplete source/data licensing can break reproduction | Generate numerical prose from a checked report ledger and reproduce the essential archive from a clean checkout |

These are priorities for strengthening the paper, not a claim that every issue remains unfixed in the revision worktree. The completed correctness gates above should be retained and checked at release. Those tasks are now verified within their recorded scientific and review boundaries; publication-only gates are outside the latest user instruction.

**1. Define the submission scope**

The minimum submission should establish five things: a precise configured-stereograph model; faithful encodings for the families actually claimed; exact identity and mirror classification within a declared profile and support boundary; an implementation that respects those contracts; and independent, reproducible evidence with a practical use case.

| Required for this revision | Optional extension after the required work |
| --- | --- |
| Correct incomplete-input and isotope/profile handling | Necessary-chirality shortcuts for partially configured inputs |
| Explicit supported and unsupported framework operations | Framework enumeration and focal evidence across all consumers |
| Correct action conventions, profile ordering, and complexity statements | Compact linear encodings for variable-length cycles and planes |
| Independent validation of global configuration partitions | Exhaustion of the remaining enormous raw C products |
| Reconciled reports and accurate input/comparator descriptions | Complete CIP Rule 4b and every coordination naming projection |
| A bounded scaling study and a registration demonstration | New coordinate perception or additional global geometry families |
| New independent chemical examples and specificity evidence | Prediction of experimental configurational stability |
| A complete reproducible submission archive | Broad reaction-layer enhancements |

The plan does not make a perfect CIP score a condition of publication. It makes honest naming coverage and separation from identity a condition. Any capability left incomplete must have a clear refusal and a narrower manuscript claim.

**2. Work sequence and planning estimate**

The following is a planning estimate for one primary researcher, with theory or chemical review where available. Allow approximately four to six working weeks for the minimum path, subject to the implementation findings and availability of independent chemical annotations. The dates are not runtime forecasts or a submission commitment.

| Phase | Work | Dependencies | Suggested window | Exit evidence |
| --- | --- | --- | --- | --- |
| 0 | Capture the baseline and establish a claim register | None | Start of week 1 | Source/environment provenance and a discrepancy ledger |
| 1 | Correct completeness and API boundaries | Phase 0 | Week 1 | Counterexamples fixed and targeted suites passing |
| 2 | Repair the mathematical contracts and novelty argument | Phase 0; finalise against Phase 1 | Weeks 1–2 | Revised definitions/proofs and a sourced comparison |
| 3 | Build independent correctness validation | Phases 1–2 conventions | Week 2 | Exact partition agreement and rejected mutations |
| 4 | Reconcile and regenerate empirical evidence | Phase 1; depends on Phase 3 for stronger correctness claims | Weeks 2–3 | Versioned reports, matched inputs, overlap accounting |
| 5 | Measure performance and demonstrate usefulness | Stable implementation and Phase 3 | Weeks 3–4 | Controlled runtime/memory report and registration example |
| 6 | Add independent chemical validation and rewrite the paper | Stable definitions; final results from Phases 4–5 | Weeks 4–5 | Audited new examples and a concise manuscript |
| 7 | Freeze, independently reproduce, and prepare submission | All required phases | Weeks 5–6 | Clean archive, successful reproduction, submission package |

Literature comparison, manuscript outlining, and selecting chemical validation cases can proceed alongside the code corrections. Final numerical prose must wait for the relevant experiment archive. Do not spend time on the long raw stress products until correctness and independent validation pass.

**3. Phase 0 — Capture the baseline and claim register**

**Purpose:** preserve enough provenance to explain every subsequent result change and prevent manuscript counts from drifting independently of the reports.

1. Record the current commit, working-tree state, interpreter, dependency versions, and checksums of the relevant stereo source and reports. The reviewed HEAD was `c3c85cea311bc495e4f0bb40f17214f4baaa2ad1`, with Python 3.12.12, RDKit 2026.03.1, and NetworkX 3.6.1. Because the workspace contains unrelated Mapper edits, that commit alone is not a complete environment description.
2. Preserve the current source-declared ACS, topology-completion, and exact-plus-global reports separately. Keep their original labels and protocols even if later results change.
3. Create a machine-readable claim register, proposed at `paper/stereo_graph/claim_evidence.csv`. Each row should include the claim, manuscript location, input contract, identity profile, required carrier boundary, report path, schema, source revision, denominator, uncertainty/refusal treatment, and status.
4. Mark claims as supported, contradicted, awaiting regeneration, or requiring new evidence. Use these statuses to determine what can remain in the submission.
5. Put source changes on an isolated revision branch or worktree when implementation begins, preserving unrelated user changes. Add a new revision log rather than rewriting the earlier sprint completion history.

The baseline discrepancy ledger contains the following items. These describe the initial review, not the latest revision scores:

| Item | Baseline evidence | Required resolution |
| --- | --- | --- |
| Strict incomplete molecule | Partial 2,3-dichlorobutane is called chiral, but has an achiral meso completion | Correct the verdict boundary |
| Isotope-labelled phosphorus | Unknown P configuration is suppressed for an isotope-distinct terminal O pair | Apply exact profile-aware equivalence or retain incomplete status |
| Large canonicalization gates | Constant certificates can pass individual local/global gates | Add an independent partition oracle |
| CIP record accuracy | Manuscript 187/300; cited JSON 175/300 | Freeze separate SMILES-only and coordinate-assisted reports |
| CIP label counts | Manuscript 926 correct/937 emitted; cited JSON 902/913 | Regenerate or use the supported archive values |
| CIP figure interpretation | 187/300 is described as coordinate scope | Describe exact-record accuracy; coordinates cover all 300 inputs |
| Perception diversity | 1,208 rows but 903 unique neutral constitutions; ACS is a 258-row subset of CIP | Report overlap and unique structure counts |
| Framework helper coverage | Accepted framework inputs reach unsupported branches | Implement or explicitly refuse each operation |
| Mathematical conventions | Composition, binary opposite, profile ordering, and size statements need repair | Align definitions, proofs, and implementation |
| Release metadata | Manuscript mentions 2.0.0b2 while the inspected project metadata declares 1.6.2 | Identify one submission source release and exact commit |

**Exit gate:** every headline claim has an evidence entry; original artifacts are preserved; missing provenance and mismatches are visible. No corrected result is presented as though it belonged to the original frozen run.

**4. Phase 1 — Correct completeness and operation boundaries**

**Task 1A: restore strict incomplete-input behavior.** Start in `synkit/Graph/Stereo/configured.py` and `Test/Graph/Stereo/test_configured_stereograph_families.py`. Remove the early promotion based on the partial registry's mirror inequality. With `require_complete=True`, unresolved required loci must return incomplete unless a separate sound completion proof is explicitly invoked. Preserve the distinction between strict molecule assessment and `require_complete=False`, which assesses the represented source-declared graph.

Use the following regression matrix:

| Input | Required strict behavior | Additional check |
| --- | --- | --- |
| `C[C@H](Cl)C(Cl)C` | Incomplete | Completion assessment, if invoked, finds both outcome types |
| `C[C@H](Cl)[C@H](Cl)C` | Achiral | Retain a valid mirror map |
| `C[C@H](Cl)[C@@H](Cl)C` | Chiral | Distinct complete mirror certificates |
| Renumbered versions of all three | Same outcome and equivalent evidence | Incomplete locus identifiers transport correctly |

Update the existing unresolved-amine test that currently expects the shortcut's verdict. If a necessary-chirality shortcut is later retained, formulate its obligation as the existence or non-existence of an achiral admissible completion under constitutional automorphisms. Exact equality of partial registries is not that proof.

**Task 1B: repair phosphate equivalence under each profile.** Inspect the terminal-phosphate exemption and its interaction with perception. Suppress an apparent missing locus only when the relevant ligand equivalence is justified under the requested identity profile. An isotope equality check alone is not a general proof of that contract.

Test the ordinary terminal phosphate, isotope-labelled oxygen on either terminal drawing, both configured P orientations, and atom-renumbered equivalents. Run these under `chemical`, `lewis_state`, and `acs_topology`; define expected behavior from each profile's attributes rather than forcing all profiles to agree. The isotope-distinct chemical example `COP(=O)(N)[18O-]` must retain its unresolved configuration, while its two explicitly configured forms remain distinct mirror configurations. Strict Lewis identity must retain the distinctions it declares.

**Task 1C: make framework helper support explicit.** Inspect `enumeration.py`, `global_configured.py`, and the framework tests. For the minimum submission, explicitly refuse unsupported framework enumeration and focal operations with a documented exception or typed refusal. Preserve already supported canonicalization and mirror operations. Full helper support may be developed separately.

If implementing focal framework evidence, erase overall orientation while preserving the relative coupling between frames. Do not independently erase every frame and thereby destroy the framework relation. Test fixed and unknown orientations, coupled multi-frame inputs, relabelling, symmetric collapse, and mixed local/global descriptors. An accepted input must never fall through to `plane_atoms` or a missing shape-table key.

**Task 1D: expose consistent identity and information boundaries.** Audit `canonical.py`, `configured.py`, `pairwise.py`, and result types. Add explicit profile parameters or clearly documented fixed-profile behavior, and include profile/schema information in persisted results. Preserve existing defaults unless their change is deliberately versioned. Chemical resonance-family identity requires a defined family certificate; a single Lewis-state code cannot be renamed to provide it.

Require corresponding carrier inventories and completeness boundaries before assigning chemical enantiomer/diastereomer relations. Inputs with different represented information should return an information/scope mismatch or incomplete outcome as defined by the API contract. Use VS215/216, isotope cases, and absent/unknown/fixed descriptor pairs to test consistency across canonicalization, pairwise comparison, and mirror classification under the same profile.

**Task 1E: make coordinate transport refuse uncertain map enumeration.** In `Experiment/Stereo/Perception/cip_labels.py`, check whether the 10,000-match cap can truncate constitutional map enumeration. If exhaustiveness is not established, return a typed unresolved transport instead of claiming every map agrees. An exact automorphism-based reduction is an optional alternative.

**Exit gate:** required unknown configuration never produces an unjustified binary answer; unsupported helper operations refuse explicitly; cross-operation profile differences are observable; coordinate transport does not treat a truncated search as exhaustive. Run the relevant existing suites and the new counterexamples after each package, followed by a combined stereo regression gate. Record changed verdict IDs for later benchmark regeneration.

**5. Phase 2 — Repair theory and establish the contribution**

**Task 2A: define the mathematical domain before revising proofs.** State the constitutional attributes, identity profile, carrier inventory, configuration states, admissible graph class, and mirror operation. Define source-declared and strict boundaries separately. State binary exactness conditional on a complete supported registry and a successfully completed exact search; interrupted computation returns a refusal.

**Task 2B: harmonize permutation and transport conventions.** Preserve the existing API's sequential reordering behavior unless there is a compelling compatibility reason to change it. Under `result[i] = source[image[i]]`, the implementation's `p.then(q)` has slot image `p[q[i]]`. Rewrite the action law, alignment cocycle, witness composition, double-coset calculations, and appendix together. Use noncommuting three-slot permutations to check the equations; commuting or binary examples alone can conceal reversed composition.

**Task 2C: narrow the binary-opposite claim.** Prove that index two specifies a unique other configuration. Remove the assertion that higher index prohibits an invariant pairing. Explain how an improper extension or normalizer action can supply a mirror involution for TBP and octahedral configurations. Distinguish binary reconfiguration from geometric reflection.

**Task 2D: correct the size and cost analysis.** Give separate expressions for fixed finite-frame loci, open paths, cyclic paths, planes, and coupled frameworks. The current cyclic-helix and plane implementations contribute quadratic terms in support length. State construction time as linear in the expansion's output size, not universally linear in molecular size. Separate normalization, resonance-family work, canonical search, automorphism-group materialization, and serialization.

**Task 2E: define profile ordering correctly.** Start from a fully declared attributed substrate and define when one profile coarsens another. State isomorphism-set containment only for profiles related by that order. Isotope-sensitive profiles cannot be treated as automatic coarsenings of bare element/Lewis colors.

**Task 2F: make perception's inputs and outputs precise.** Distinguish constitution-only `K_0(G,s)` from a constructor that consumes neighboring configured frames. Call the latter focal-configuration-neutral. Make the returned object an orbit/evidence record when symmetry prevents an equivariant concrete ordering. Require neighboring frames to transport with an isomorphism in the equivariance statement.

**Task 2G: give the extended families explicit faithfulness arguments.** For each path, plane, and framework gadget, define allowed support transformations and explain why its colored automorphisms are exactly those transformations. State uniqueness assumptions needed for the automorphism-projection theorem. Use a capability table generated from the audited consumers: ten local configured families, the separate framework family, and narrower legacy/interchange sets.

**Task 2H: add and audit the missing literature comparison.** Read Molassembler's molecular model and canonicalization sections, Andersen et al.'s ordered-list construction, StereoMolGraph's comparison method, and current supported RDKit canonicalization. Record precisely which inputs, geometries, identity conventions, canonical outputs, and guarantees each supplies. Cite sources for capability-table entries. Avoid inferring absence of a capability from the absence of a theorem in a paper.

The first sourced comparison is now recorded in [revision/prior_art_audit.json](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/paper/stereo_graph/revision/prior_art_audit.json). The draft credits existing canonicalization and replaces its categorical availability table. Final release-specific comparisons and review of the newly listed Circular Stereo preprint remain required before freezing novelty claims.

The proposed contribution is a precisely specified faithful encoding across a declared catalogue, together with transport and completeness contracts. Do not claim the first use of permutation groups, global stereochemical comparison, or canonical stereo identifiers. If the Molassembler comparison removes the apparent uniqueness of an individual component, narrow the claim to the demonstrable combination or construction.

**Exit gate:** a reviewer can identify the domain and assumptions of every theorem; noncommuting examples agree with the code; complexity covers the actual implementation; each claimed extended family has an explicit argument; the novelty statement survives comparison with the closest predecessors.

**6. Phase 3 — Validate global partitions independently**

**Purpose:** test both whether equivalent encodings collapse and whether inequivalent configured objects stay separate. Large invariance counts alone do not establish both directions.

Add a proposed independent runner, `Experiment/Stereo/Canonicalization/independent_orbits.py`, and a report under `Experiment/Stereo/Data/Canonicalization/`. Keep its mathematical comparison independent of the production auxiliary canonicalizer, production canonical forms, and production stereo-isomorphism predicate.

For each small typed constitutional fixture:

1. Declare the carrier inventory and local shape actions explicitly. Freeze the inventory before assigning configurations.
2. Enumerate the constitution's color-preserving automorphisms, restricting them to those that transport the declared supports and family types correctly.
3. Enumerate the formal assignment product using independently checked local group actions.
4. Transport every assignment under those automorphisms and form the assignment orbits directly.
5. Independently obtain the production certificate for every assignment.
6. Compare the complete partitions as sets of assignment sets, allowing arbitrary class labels. Equal class counts alone are insufficient.
7. Check mirror transport, mirror-fixed classes, enantiomer pairing, and composition across several loci against the same independent partition.

Start with asymmetric tetrahedral centers, equivalent-center meso cases, planar bonds, TBP/octahedral examples, mixed geometry cases, virtual references, paths/planes, and coupled frameworks within the independent runner's declared scope. Add tractable public fixtures and cover the formal A/B/C cases where exact constitutional automorphism enumeration is feasible. Every excluded or capped case must be named and cannot count as a pass.

For the reference runner, suggested initial limits are 50,000 constitutional automorphisms, 1,024 formal assignments, 10 seconds per case, and 1 GiB per worker. Pilot these limits on the designed corpus before fixing the study scope. A reached limit produces `oracle_incomplete`; it does not validate production behavior. Where group tables are reused as mathematical inputs, verify them independently against geometric rotations or separately specified permutations and disclose that shared dependency.

Require the validation harness to reject these controlled defects:

| Mutation | What the oracle must detect |
| --- | --- |
| Return a constant certificate | Incorrect merging |
| Erase configuration/parity at a selected locus | Missing local-state constraints |
| Include input atom index in identity | Incorrect splitting after renumbering |
| Omit one configured element | Lost simultaneous constraints |
| Use the wrong mirror action for a planar bond | Incorrect molecular relation |
| Prohibit exchange of equivalent carriers | Incorrect global symmetry quotient |
| Reverse one transport composition | Incorrect local witness or induced action |

Use a separate canonizer on the same expansion as an additional check if practical. This validates the graph-canonicalization engine, but it is not independent evidence for faithfulness of the expansion itself. Direct orbit partitions supply that evidence.

**Exit gate:** production and independent partitions agree on every executed case; all controlled defects are rejected; merged assignments have independent transport evidence; skipped and resource-limited cases are explicit. Revise the existing local/global acceptance conditions so arbitrary invariant merging cannot be labelled a proved symmetry quotient.

**Recorded completion:** the clean-source full run at `c592292` passes all 63
declared cases and 2,439 assignments, with no incomplete oracle and all seven
mutations rejected. The archive audit replays every stored transport witness.
See [revision/independent_full_verification.json](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/paper/stereo_graph/revision/independent_full_verification.json)
and the revision log. This closes Phase 3; the input and chemical truth gates in
later phases remain required.

**7. Phase 4 — Reconcile reports and input contracts**

**Current checkpoint, 3 October 2026:** the new full local matrix passes on
3,476 carriers and 66,468 representations, and all 6,999 positive witnesses
replay. The formal A/B/C reruns pass 30 cases and 2,160 assignments. A
separately validated exact rooted transport-query oracle resolves the large
local symmetry kernels without raising the original enumeration cap. The
current/pinned comparator's four ACS discrepancies disappear when frozen
inventories are aligned; this is an information-boundary difference, not
evidence of canonizer superiority. Remaining report/prose/archive work is
listed in [revision/status.json](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/paper/stereo_graph/revision/status.json).


**Task 4A: maintain separate naming protocols.** Preserve the existing schema-2 SMILES-only report under an unambiguous historical name. Generate a separate coordinate-assisted report from the pinned SDF and the corrected transport code. Do not overwrite provenance merely to match the manuscript's expected 187/300. Accept the new measured values even if they are lower than the development claim.

Each protocol should record source commit, dirty-state policy, environment, runner options, dataset checksums, coordinate checksums where applicable, supplied family metadata, parsed/evaluated/excluded counts, exact records, emitted labels, correct labels, wrong labels, missing labels, typed limitations, and all mismatch IDs. State whether family categories or supports are externally supplied.

**Task 4B: compare systems on matched inputs.** Report a SMILES-only comparison separately from coordinate-assisted results. Where both systems accept the pinned coordinates, evaluate both from the same structural input. If a comparator cannot consume a particular family or input, report that limitation rather than converting it into a matched comparison. Keep source annotations used for input preparation separate from target handedness labels used only for scoring.

**Task 4C: expose dataset overlap and annotation assistance.** Add row counts, unique configured structure counts where defined, unique neutral constitution counts, and ACS/CIP overlap to the main protocol and report. Keep task-specific denominators. For structural generalization, split or deduplicate by constitution and scaffold rather than record ID.

Label the retained perception protocol as using neighboring orientations. Label RotA recovery as family-conditioned when the annotated category selects a projection. Add a family-blind evaluation with that category withheld if blind perception is claimed. Additional unannotated candidates must remain unadjudicated until independent truth is obtained.

**Task 4D: retain the three ACS procedures as distinct experiments.** Archive and regenerate source-declared configured identity, exact-plus-global evidence, and ACS-specialized topology completion independently. Document the profile, support boundary, topology sanitization, allowed inputs, time budget, and completeness meaning for each. Promote the exact-plus-global runner/report into the maintained experiment tree and manifest. Audit changes caused by Phase 1 instead of inheriting the original 256/257/258 counts.

**Task 4E: generate manuscript values from the reports.** Add a proposed table generator, `Experiment/Stereo/manuscript_tables.py`, that validates report schemas and writes small LaTeX fragments or a numerical ledger. Every number in the abstract, figures, tables, README, and cover letter should resolve to that ledger. Label 187/300, if reproduced, as exact-record accuracy rather than coordinate scope. Separate historical regression counts from the final release's test result.

The generator must refuse missing artifacts, incorrect hashes, incomplete scopes presented as exhaustive, and duplicate claims with contradictory values. Required correctness failures must make the benchmark command exit unsuccessfully. Cases expected to be unsupported or incomplete should pass only when their expected refusal is observed.

**Task 4F: define bounded and full reproduction entry points.** Keep a fast validation path for correctness fixtures, independent partitions, and representative report checks. Keep the full research run separate, with the long raw A/B/C-VS146 stress tasks explicitly identified. Run the full required archive once from the final release candidate; repeat affected experiments when subsequent changes invalidate them.

**Exit gate:** a single command or documented command sequence regenerates every submitted result; its source/input contracts are complete; hashes match; manuscript numbers match the selected reports; no result borrows a stronger profile, budget, input, or truth annotation from another protocol.

**8. Phase 5 — Measure performance and show a useful workflow**

**Current checkpoint:** registration has completed its declared size sweep with correct independently labelled groups. The full cost sweep and archive audit are complete: 540 trials, 513 completed computations, six timeouts, three memory-limit terminations and 18 expected boundary refusals. Both output modes complete on 85 inputs with equal full codes. Cost, registration and resource plots are integrated into the revised manuscript; the numerical ledger has 141 claims from 23 checked inputs/reports. The registration result supports correctness in its curated common scope; it supplies no measured speed advantage. See the current evidence table above and [revision/performance_protocol.json](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/paper/stereo_graph/revision/performance_protocol.json) for the frozen study design.

**Task 5A: define a controlled performance study before interpreting runtimes.** Add a proposed runner, `Experiment/Stereo/Canonicalization/performance.py`, with reports under a dedicated performance data directory. Reuse deduplicated public constitutions and add constructed stress families with a clear purpose.

Stratify cases by atom count, configured-element count, auxiliary vertices/edges, local shape, constitutional symmetry, repeated components, and variable support length. Include complete, incomplete, unsupported, and bounded-search outcomes; measure each without treating refusals as successful identity decisions.

Measure preparation/loading, normalization or resonance processing, expansion construction, canonical search, group materialization, mirror/pairwise comparison, and serialization separately. Record median, p95, maximum, process peak RSS, search nodes, witness/generator counts, certificate size, and timeout/refusal coverage. Run one case in an isolated process when measuring peak memory. Record hardware, interpreter, thread/process count, and whether native memory is included.

Use a short pilot to choose sample size. Suggested initial planning caps are 30 seconds per ordinary case, a separately labelled 120-second stress tier, and four hours of total wall time for the controlled sweep. These are proposed resource limits, not guarantees of performance. Run three repetitions initially; increase repetitions only where variance changes interpretation. Include timed-out cases in coverage and censored-runtime summaries. Do not silently remove them from averages.

The implemented design fixes 90 inputs, three repetitions and two group-output modes, for 540 planned runs. Execute serial fresh workers with one native thread, a 1 GiB process-memory cap and the recorded output-size cap. Every planned run must remain in the report, including those not executed because the total study cap was reached. Check equality of full certificates between modes wherever both complete. With only three repetitions per input, a per-input p95 is a coarse descriptive statistic, usually the maximum, rather than a reliable tail-latency estimate; show individual repetitions and their range alongside the median.

Evaluate generator-only output against complete automorphism-group output on the same inputs. Inspect consumers before changing the default. If full groups remain required, report their output cost separately from canonical search and do not attribute it all to the canonizer.

**Task 5B: demonstrate stereochemical registration and deduplication.** Create a curated collection containing known duplicates under renumbering, alternative local encodings, enantiomers, diastereomers, mixed supported geometries, and profile-sensitive examples. Declare the expected partition independently.

Compare the total workload of repeated pairwise stereo-isomorphism with computing one certificate per record followed by indexed grouping and full-certificate equality. Include parsing, certificate computation, and storage costs; use the same supported scope and identity profile for both approaches. Where an external toolkit covers only a subset, report that subset separately. Evaluate several collection sizes to locate the amortization crossover rather than assuming certificates are always faster.

The primary practical outcomes are correct registration groups, preserved stereochemical distinctions, explicit refusals, and total time/memory. A speed advantage is an empirical question. If it is absent, the paper can still establish correctness and scope, but its practical advantage must be stated accordingly.

If a further practical performance study is justified, freeze a second workload before measuring it: varied duplicate proportions, more distinct constitutional/configuration classes, or repeated queries against a persistent precomputed index. Count certificate setup and storage in total cost. Compare against sensible cached pairwise representatives under the same information profile. Keep this study separate from the completed 8–128-record experiment, and do not select a favourable workload after searching for a speedup. It is optional unless the paper retains a performance-advantage claim.

**Exit gate:** cost claims have reproducible hardware and denominators; performance includes failures and refusals; group-output overhead is visible; the registration example has correct independently labelled groups and explains when canonicalization is useful.

**9. Phase 6 — Validate new chemical examples and revise the manuscript**

**Current checkpoint:** selection and truth contracts are frozen in [revision/chemical_coordination_selection.json](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/paper/stereo_graph/revision/chemical_coordination_selection.json), [revision/chemical_negative_selection.json](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/paper/stereo_graph/revision/chemical_negative_selection.json) and [revision/rota_adjudication_selection.json](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/paper/stereo_graph/revision/rota_adjudication_selection.json). The coordination inputs retain every source-declared frame; 38 of 40 certify, retaining 18 local tetrahedral frames, and two remain geometry refusals. All forty source-file hashes and coordinate donor indices match their committed bytes. Every certified source/mirror comparison, all 48 sourced negatives and all 60 fixed RotA annotations pass their declared production checks. The chemical summary binds the four unchanged reports, and the main paper distinguishes reference enumeration, actual production coverage, source assistance and unknown physical persistence. These results complete Task 6A for the retained empirical scope. Planar, path and additional framework chemistry remains formal representation validation only.

**Task 6A: select an independent chemical evaluation.** Freeze the selection criteria before inspecting algorithm predictions. Avoid duplicates from ACS/CIP/RotA development data. Prioritize coordination geometries, planar chirality, coupled global frameworks, and axial near-misses that are poorly represented by the current public evidence.

The existing corpora remain development-corpus validation. Splitting them now does not create an untouched holdout retrospectively. Use newly sourced or prospectively withheld cases for that claim, and group duplicate structures and stereoisomers by constitution when selecting partitions.

A proposed initial scope is 20–40 source-documented examples spanning these gaps, plus 30–50 independently selected axial/topological negatives. These are study-design targets, not existing validated records. Actual coverage depends on verifiable annotations and usable source terms. Report family counts and incomplete annotations. Do not call a source independent merely because it has a different filename.

Before prediction, save a selection manifest containing source citation/revision, redistribution terms, source record ID, constitution/overlap key, family, input information, expected relation or configuration, and the basis for that annotation. Reserve cases with unverifiable handedness as unresolved rather than supplying truth from the production code. For coordination coordinates, use an independently defined geometric rotation/reflection test or externally declared configurations, with degeneracy and atom-transport tolerances fixed in advance. Audit annotation conventions before constitutional deduplication: some source generators use atom maps or donor isotopes as coordination-slot labels, which must not silently become chemical isotope identity. Coordinate examples from a generator remain generated chemical examples, not evidence of experimental stability.

Constructed axial near-misses can strengthen structural specificity by carrying an independently replayable constitutional symmetry that exchanges equivalent terminal ligands. Keep these separate from newly sourced chemical negatives and from barrier or isolation-time evidence. If usable independent examples do not cover a claimed path, plane or framework family, either obtain the missing source or restrict the empirical claim to formal representation validation of that family.

For the 1,562 additional RotA candidates, select a fixed, stratified adjudication sample—for example, 60 cases split across support types, structural symmetry, and molecule sizes. Review chemistry without seeing the algorithm's confirmed/rejected status where practical. Record reasons and uncertainty. If a second chemical reviewer is available, assess disagreements before resolving them.

Keep three truths separate: a broad candidate carrier, constitutional stereogenicity under a defined profile, and experimentally persistent stereoisomerism. An experimental stability claim requires a source specifying a relevant barrier, isolation condition, or timescale. Without that evidence, retain constitutional validation and explicitly limit the conclusion.

**Task 6B: restructure the main paper.** Use the following scientific sequence as an editorial outline:

| Main-text component | What the reader should learn |
| --- | --- |
| Concrete example and background | Why connectivity/local descriptions alone do not settle the stated global identity task |
| Related work and problem | What is already solved and the precise remaining contribution |
| Representation and scope | Profiles, supports, ports, configuration, information states, and completeness |
| Faithful expansion and theorem | Why isomorphism is preserved and reflected |
| Algorithms and costs | How identifiers and mirror relations are computed, with refusal conditions |
| Validation and practical example | Independent correctness, chemical coverage, runtime/memory, and registration value |
| Discussion and limitations | What follows from the model and where evidence remains incomplete |

Retain the essential faithfulness proof in the main text. Move extensive orbit enumerations, compatibility inventories, API data contracts, detailed transport algebra, expanded proof obligations, and secondary CIP analysis to appendices or supporting information. For Journal of Cheminformatics, choose the packaging that best preserves access and clarity; a separate supporting document is an editorial option, not an assumed journal requirement.

Suggested editorial targets are approximately 7,000–9,000 main-text words, a 250–300-word abstract, and a one-page cover letter. These are recommendations, not verified journal limits. Include a section titled "Scientific Contribution" within the abstract, using at most three sentences, as required by the proposed article type.

An approximate 7,900-word main-text budget is: motivation 900; related work 700; model and scope 1,300; construction and essential faithfulness argument 1,500; algorithms and costs 800; validation and practical results 1,700; discussion and limitations 1,000. Treat this as an editing aid. Count the actual main text separately from references and supporting material before deciding what to move. The main paper must retain enough of the construction and proof that a reader can understand the contribution without navigating API documentation.

Use one title in `main.tex`, `README.md`, and `cover_letter.tex`; a proposed title is **Exact canonicalization of configured molecular stereographs**. Use "connectivity-only molecular graphs" in the opening. Explain the limits of CIP labels for the proposed uniform representation rather than claiming that constitution dependence makes them universally unsuitable for identity.

**Task 6C: redesign the result presentation.** Keep the pipeline, one complete orbit-to-graph worked example, a global symmetry/meso example, a sourced capability table, a task-separated evidence table, and runtime/memory plots. Consider replacing crowded descriptor galleries in the main text with a compact set of chemically sourced examples.

Correct the CIP tile and caption. Make figure percentages correspond to labelled tasks and denominators. Describe profile/support disagreements as such, with replayable evidence, and use a single clear account of VS170/VS300 instead of repeating development history throughout the abstract, results, discussion, and cover letter.

**Task 6D: rewrite the cover letter around the final contribution.** State the problem, new construction, why it is a demonstrable advance over the closest methods, the independent validation, and journal fit. Remove development-release promises and claims whose artifacts are not in the submission archive. Mention the companion paper only to clarify scope and dependency.

**Exit gate:** the main narrative is readable without the development logs; every capability is supported or explicitly bounded; all numerical claims resolve to final reports; the closest prior work is represented fairly; independent chemical cases support the retained scope.

**10. Phase 7 — Freeze and prepare submission**

1. Choose one source release and immutable commit. Resolve package-version differences, freeze an environment lock or container digest, and record the exact input checksums and report schemas.
2. Package the maintained experiment runners, small independent fixtures, report generators, machine-readable results, provenance, and reproduction instructions. Verify that experiment material omitted from a standard package distribution is included in the research archive.
3. Resolve the CIP validation suite's access/licensing contract against the target journal's reproducibility criteria. If its inclusion cannot satisfy those criteria, establish an acceptable accessible source/permission arrangement or narrow the paper so its conclusions do not require unavailable material. Preserve dataset attribution and declared terms.
4. Reproduce from a clean checkout or independently extracted archive. Run focused and repository-required tests, regenerate required reports, compare partitions and denominators, and build the manuscript and cover letter. Audit skipped tests instead of advertising only the pass count.
5. Have a theory reader check action conventions and faithfulness, a chemical reader check truth/input boundaries, and a software reader reproduce a representative subset. If these roles cannot be filled, record the limitation and use a clean-room reproduction with explicit instructions.
6. Finalize author metadata, affiliations, contribution statements, funding, references, and the companion-paper citation. Describe any relevant AI assistance according to the target journal's policy and actual use.
7. Prepare the submission files and verify current journal instructions at that time. Archive the exact source/data/environment and make the DOI/version in the paper resolve to that archive.

**Submission gate:** all required criteria below are satisfied or the affected claim has been removed and the resulting narrower paper still demonstrates a coherent advance.

| Criterion | Required evidence |
| --- | --- |
| Strict incompleteness | Partial-to-meso counterexample refuses; complete forms classify correctly |
| Profile-aware chemistry | Isotope/phosphate and resonance regressions match declared semantics |
| Explicit API support | Framework operations implement their contract or refuse deliberately |
| Mathematical agreement | Code, equations, proofs, and mirror conventions agree |
| Global correctness | Independent partition oracle agrees and rejects deliberate defects |
| Accurate denominators | Dataset overlap, assistance, exclusions, and refusal counts are visible |
| Matched comparisons | Systems receive equivalent inputs for each claimed comparison |
| Reproducible results | Reports, tables, figures, and source revision match |
| Measured costs | Runtime, memory, output costs, and timeout coverage are reported |
| Practical value | Registration example gives independently correct groups |
| Chemical scope | New sourced cases validate the retained families and claims |
| Submission archive | A clean reproduction produces the submitted results and PDF |

**11. Next five working days from the current checkpoint**

The original four-to-six-week estimate described the complete programme. The following schedule starts from the verified revision checkpoint and does not repeat completed correctness work. New chemical annotation and external reading may determine the remaining calendar time.

| Day | Primary work | Independent work that can proceed alongside it | Concrete output |
| --- | --- | --- | --- |
| 1 | Freeze new chemical selection and independent truth contracts before predictions; costs/registration are already archived | Verify source terms and overlap | Dated selection manifest with explicit annotation and access boundaries |
| 2 | Implement the new chemical evaluator against independently frozen geometry/symmetry truth | Complete release-specific RDKit representation checks and sourced comparison table | Independent evaluator and a checked novelty statement |
| 3 | Regenerate remaining perception/relation reports with complete provenance; extend numerical ledger | Independently annotate new chemical cases and the stratified RotA sample | Report manifest with no unexplained discrepancy |
| 4 | Evaluate the frozen new cases, document errors and uncertainty | Draft the shorter main narrative and select supporting material | Chemical validation report and a complete editorial outline |
| 5 | Integrate checked numbers, chemical scope and measured limitations into text and figures | Plan clean-checkout reproduction and check input redistribution terms | Coherent release-candidate manuscript and an explicit list of remaining submission gates |

Do not treat these dates as permission to skip an unresolved gate. If a task takes longer, move its dependent tasks. Report discrepancies openly instead of recovering a headline count by weakening a boundary.

**12. Journal decision and supporting sources**

The proposed first target is [Journal of Cheminformatics Methodology](https://link.springer.com/journal/13321/submission-guidelines/methodology), whose criteria emphasize a demonstrable methodological advance and third-party reproducibility. Its [scope](https://link.springer.com/journal/13321/aims-and-scope) includes chemical representations, information systems, and software. Guidance rechecked on 3 October 2026 requires essential data and methods to be accessible without registration or restrictive agreements, with Creative Commons terms for data/text and OSI-approved software licenses. Dataset licensing is therefore a submission requirement, not just an archive preference.

[Journal of Chemical Information and Modeling](https://researcher-resources.acs.org/publish/author_guidelines?coden=jcisd8) is a plausible alternative after the comparative, practical, and performance evidence is strong. [Journal of Mathematical Chemistry](https://link.springer.com/journal/10910/aims-and-scope) is an alternative if the final paper emphasizes the mathematical results and their chemical significance. These rankings are editorial judgments, not predictions of acceptance. Recheck the relevant guidance before submission.

For JCIM, the present theory-and-method contribution is best considered as a full Article. A software-centred Application Note would be a different, substantially shorter paper; the current guidelines limit that type to 5,000 words including graphics and require the application name in the title. Do not compress the faithfulness argument into an application note simply to change journals.

The closest-primary-source review includes [Molassembler](https://arxiv.org/html/2005.04525), [MACE](https://doi.org/10.1021/acs.jctc.3c01313), [StereoMolGraph](https://pubs.acs.org/doi/10.1021/acs.jcim.5c02523), [Andersen et al.](https://doi.org/10.1007/978-3-319-61470-0_4), and [RDKit's stereochemistry documentation](https://www.rdkit.org/docs/RDKit_Book.html). MACE already compares rotation-related sets of canonical coordination SMILES; the revised related-work prose and table credit that contribution. Treat supported stereo families and identity conventions as part of every comparison.

The central decision after the required work is whether the evidence supports the whole claimed catalogue and end-to-end pipeline. If it does, submit the broad methods paper. If it supports only the configured-graph kernel and selected consumers, submit that narrower contribution with explicit boundaries, rather than presenting unverified peripheral capabilities as established.

**13. Decisions for the final release candidate**

| Decision | Evidence to inspect | Required action |
| --- | --- | --- |
| Retain an exactness claim | Definitions, catalogue-specific faithfulness arguments, independent partitions and typed resource refusals | State exactness for complete supported configured inputs and completed search; do not transfer it to unverified perception or physical stability |
| Retain a comparison advantage | Matched profiles, hydrogen treatment, carrier inventories and annotation inputs | Describe differences in supported representation; remove accuracy superiority based on unmatched information |
| Retain a speed claim | Full cost report, all censored cases, host conditions and registration workloads | Use only measured scope; if no advantage appears, explain certificate persistence and exact identity without claiming a speedup |
| Retain blind perception language | Protocol with all target-family/support assistance withheld | Otherwise describe the assistance precisely and call the evaluation conditional |
| Retain broad chemical coverage | Frozen source-documented cases with independent annotations for each claimed empirical family | Narrow unsupported chemical claims while preserving proved representation scope |
| Submit to Journal of Cheminformatics | Complete third-party reproduction and acceptable access/licensing for essential inputs | Resolve access terms or remove dependence on those inputs before submitting |

The final handoff should contain the concise manuscript, supporting proofs and detailed reports, generated figures/tables, source and input manifests, an immutable source revision, a locked environment, bounded and full reproduction commands, a skip/failure inventory, and a one-page cover letter. Authorship, funding and any archive DOI must reflect confirmed facts. Preparing this package does not itself establish that a human reviewer has checked it or that a journal submission has been made.


**Journal figure and formatting checkpoint, 3 October 2026.** All eleven cropped vector upload files have embedded fonts, compliant titles/legends and first-mention ordering. Their 29-file editable archive passes inventory checks and independently rebuilds identical 180 dpi renderings. The 38-file manuscript source archive rebuilds the 56-page main PDF and 56-page supplement without unresolved references or layout overflow. Additional file 1 is explicitly cited/described and its named PDF is byte-identical to the supplement. A rendering error introduced in an earlier editorial change is corrected: the ACS percentage now reads 98.06% for 253/258, checked in both exported and rebuilt graphics. All 33 reviewed statement/proof blocks and all 531 scientific Python files remain unchanged. Numbered web references and tested software metadata are included; the broken documentation link is replaced with working Read the Docs documentation. [Author decisions](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/paper/stereo_graph/revision/release/author_decisions.md) identify the remaining facts, approval statements and exact public release identifier; none is inferred from automated checks.

**User-requested author/thesis enhancement, 3 October 2026.** The Syndoku source supplies Tieu-Long Phan, Peter F. Stadler and Daniel Merkle, in that order, with seven affiliation blocks and emails. That author instruction is applied. The thesis notation/style review adds graph-indexed constitution labels, a notation table, an explicit graph-valued `Can` versus serialized `can` distinction and the shared vector palette. The canonical-form prose implication is corrected. Two new diagrams explain incomplete-input refusal and invariant collisions; their chemical/graph semantics pass 18 profile/order verdicts and 2,160 independently enumerated illustrative serializations. These are explanatory populations, not new benchmark evidence. All eleven graphics have been visually inspected and independently rebuilt from their editable archive. The updated main/SI each have 56 pages; the combined authoring PDF has 80. See [thesis alignment](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/paper/stereo_graph/revision/release/thesis_alignment.md) and [source audit](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/paper/stereo_graph/revision/release/author_thesis_source_audit.json). Funding, competing interests, coauthor roles, author approval, originality/exclusivity and the exact public release identifier still require study-specific facts. The earlier `00110d0` archive is already verified and is a historical nine-figure checkpoint; the requested additions are separately verified in the updated review freeze.

**Updated review freeze verified.** Source `3c10948` retains 2,063 tracked files (all Git/archive/extracted bytes and trees agree), the complete 35-stage execution, all 269 selected claims and the requested three-author/thesis additions. Extracted checks pass the eleven-figure binding, 18 chemical diagram verdicts, 2,160 illustrative serializations and all 60 focused result contracts. Combined manuscript/letter text rebuilds identically. The journal's 38-file source ZIP and 29-file figure ZIP transfer their successful reader checks by exact hashes. [Archive checkpoint](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/paper/stereo_graph/revision/release/research_archive_thesis_checkpoint.json) and [requirement audit](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/paper/stereo_graph/revision/release/plan_requirement_audit.json) retain scopes and receipts; documentation receipts added after the source freeze are not members of that source archive. The next action is to resolve study-specific declarations, author approval and exact public release identity.

**Final user scope and declarations, 3 October 2026.** The user directed copying all funding from Syndoku and retaining Peter/Daniel roles in revision, supervision and funding acquisition. Those facts are applied and checked in the rebuilt manuscript; all five grant identifiers and the EU disclaimer are included. The user explicitly chose to finish the review package without publication or submission. Competing interests are visibly pending, submission approval is not asserted, and this review version has no public DOI. The review deliverables are the manuscript/SI, editable sources, eleven figures, result/proof records, exact local source archive and the draft cover letter. All existing publication guidance is retained for a possible future task, rather than claimed completed. See [review scope](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/paper/stereo_graph/revision/release/review_scope_decision.json) and [author facts](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/paper/stereo_graph/revision/release/author_decisions.md).

**Review package complete under the explicit user scope.** The final local source freeze includes the full Syndoku funding and requested Peter/Daniel roles. All tracked Git/archive/extracted bytes agree, all selected result contracts and eleven figure bindings validate from extraction, and combined manuscript/letter rebuild with identical text. [Final archive verification](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/paper/stereo_graph/revision/release/review_package_final_archive_checkpoint.json) records the exact source commit, archive SHA-256 and inventory. [Review handoff](/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision/paper/stereo_graph/revision/release/review_package_handoff.md) names the deliverables. The 68-requirement audit proves completion of the review scope; public DOI assignment, publication, submission and submission-only declarations remain explicitly deferred by user instruction. Post-freeze completion receipts are separate from the immutable source archive.
