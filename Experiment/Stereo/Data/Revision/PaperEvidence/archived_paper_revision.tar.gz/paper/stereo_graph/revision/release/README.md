**Review package complete.** See [review_package_handoff.md](review_package_handoff.md) for final artifacts and [review_package_final_archive_checkpoint.json](review_package_final_archive_checkpoint.json) for exact local source/archive verification. User requests no publication or submission.

**Current scope — local review package.** The user requested “Finish the review package; no publication or submission.” Funding and contribution facts are applied; unconfirmed competing interests are visibly pending. Public DOI assignment and submission declarations in the reproduction/submission guidance below are future steps. The final local review archive retains an exact source commit, complete byte inventory and verification receipt. No external release or submission is requested.

# Research release and clean reproduction

This directory freezes the Linux x86_64/Python 3.12.12 research environment. The source checkout and distribution metadata report SynKit 1.6.2. An exact Git commit identifies the stereo revision; the version string alone does not distinguish it from other development states. This is a local review version; future publication would require final declarations, approval and a public archive identifier. The complete 35-stage clean execution and its primary numerical selection are now verified.

`requirements-linux64-py312.lock` pins 46 scientific, test and build distributions to exact downloaded wheel SHA-256 hashes. `environment.json` records the package closure, wheel filenames, compiler and TeX tool versions. `conda-explicit-linux64.txt` records the original conda bootstrap, including Python 3.12.12. The isolated verification uses a virtual environment with system site packages disabled and does not inherit the host SynKit installation.

Create the bootstrap with conda and install the locked wheels in an isolated environment:

```sh
conda create --prefix /tmp/synkit-python-bootstrap \
  --file paper/stereo_graph/revision/release/conda-explicit-linux64.txt
/tmp/synkit-python-bootstrap/bin/python -m venv /tmp/synkit-stereo-env
/tmp/synkit-stereo-env/bin/python -m pip install --require-hashes \
  -r paper/stereo_graph/revision/release/requirements-linux64-py312.lock
```

The lock targets this platform and interpreter. A C++ compiler is required by native tests; the recorded run uses GCC 15.2.1. PDF builds use TeX Live 2023 and latexmk 4.88. Timing and memory results retain the measured host and resource limits; reproducing exact wall-clock values is not an identity-correctness criterion.

The ordinary wheel and source distribution contain SynKit code and package data. They omit the research experiments, frozen source selections, independent fixtures and manuscript. The separate research archive must include those materials. Build and verify the standard distributions with:

```sh
python -m build --no-isolation --outdir /tmp/synkit-stereo-distributions
python scripts/check_package_artifacts.py /tmp/synkit-stereo-distributions --mapper-smoke
```

Before freezing a research archive, ensure all intended research files are committed and the worktree is clean. Export that exact tracked tree:

```sh
git archive --format=tar --prefix=synkit-stereo-research/ HEAD | \
  gzip -n > /tmp/synkit-stereo-research.tar.gz
```

The release verification records the source commit, archive digest and per-file inventory. In particular, the archive must retain `Experiment/Stereo`, relevant tests, `scripts`, the project metadata, all selected unchanged MACE geometries and attribution, the numerical manifest and reports, the environment lock, and `paper/stereo_graph`. It must not substitute the standard source distribution for that archive. The licensed original CIP archive, its prepared SMILES, original 3D coordinates, publisher metadata and attribution must also be retained.

`data_access_audit.json` retains the GitHub access audit and the separately licensed publisher source. The original publisher supporting archive is provided under CC BY-NC 4.0. Run `python -m Experiment.Stereo.cip_sources` to check its unchanged bytes, licence metadata, original 3D coordinates and two citation punctuation repairs. All 300 SMILES, identifiers and expected labels are unchanged. The later amended GitHub 3D file has a separate checksum and is not provided or covered by an asserted publisher grant. Fresh primary reproduction uses the included original coordinates; historical coordinate reports retain their original hashes. ACS, RotA and MACE retain their separate terms and attribution.

From a clean checkout, run the repository checks and research sequence:

```sh
PYTHON=python bash scripts/lint.sh
PYTHON=python bash scripts/pytest.sh -q Test/ --junitxml=/tmp/synkit-repository-tests.xml
python -m Experiment.Stereo.reproduce --tier bounded --jobs 2 \
  --output-dir /tmp/synkit-bounded
python -m Experiment.Stereo.reproduce --tier full --jobs 2 \
  --stereomolgraph /tmp/StereoMolGraph-stereo-paper-current \
  --output-dir /tmp/synkit-full
```

The optional current comparator must be checked out at `2b99f62c40aa93ee73887ab3882badeb8d29804e`; its source and MIT license are recorded in the existing prior-art audit. The legacy `2189f610f23eaaf992e2e01a12ea4d0532496601` comparison remains separately identified.

Install `requirements-comparator.lock` in the research environment when using that comparator. Its declared `typing-extensions` dependency is a separate hash-pinned overlay on the unchanged 46-package base lock. The installed-wheel and bounded checks retain their original base environment. The first clean full run completed 14 stages, then stopped at the comparator import because this dependency was absent; that failed attempt is preserved. `resume_full_reproduction.py` checks the original source and input hashes, completed report hashes, exact stage arguments, base dependency versions and pinned comparator before running the remaining stages through the maintained research runner. It combines the verified prefix and continuation, retains both attempts, and requires all 35 stages before declaring sequence completion.

```sh
python -m pip install --require-hashes \
  -r paper/stereo_graph/revision/release/requirements-comparator.lock
```

The full sequence excludes optional raw Cartesian stress. Existing complete raw-B/raw-C-slice reports remain supplemental evidence. Use their explicitly expensive tier only when studying those raw populations. No failed, incomplete or skipped check is promoted to a successful reproduction; record names and reasons for skipped repository tests. Compare complete assignment partitions, witnesses, input/task denominators, refusal populations and numerical values with the retained reports. Audit timing/censoring separately.

The installed stereo smoke check uses a second virtual environment with no inherited system packages. Install the locked dependencies there, install the built wheel with `--no-deps`, and run `installed_wheel_smoke.py` from outside the checkout with `--wheel`, `--lock`, `--fixtures`, and `--output`. The recorded check verifies every packaged byte, all 46 dependency versions, 18 mirror/profile cases under two atom orders, and all 53 distinct-ligand coordination encoding states under two atom orders. This finite smoke check is separate from the full research reproduction.

The repository suite requires two existing frozen Synister application fixtures under `paper/synister/evidence/pilot100_v4` and `alternative_its_case_v1`. The release retains them unchanged and records their original local hashes in `required_fixture_restoration.json`. Their inclusion supports repository contracts; their scientific conclusions are not used as stereo evidence. The CI-selected Synister suite passes 83 deterministic tests. An additional run of the whole Synister research suite finds 31 missing-evidence failures outside this paper's scope; its complete failure inventory is preserved in `release_checkpoint.json`.

An ordinary `git archive` contains no `.git` directory. The reproduction tools record Git provenance, so an extracted archive requires a local repository after all extracted bytes have been checked against the archive inventory:

```sh
git init
git add -f .
git -c user.name='Archive verification' \
  -c user.email=archive-verification@localhost \
  commit -m 'Verify extracted stereo research archive'
```

That local verification commit differs from the original source commit. Record both identities and bind them by the complete file inventory and source/input checksums; do not present the locally created commit as the original release. The archive-verification reader role is an automated substitute, not an independent human reviewer.

Build the manuscript and letter, then verify numerical macros against the checked manifest:

```sh
python -m Experiment.Stereo.manuscript_tables \
  --manifest paper/stereo_graph/revision/result_manifest.json \
  --output-dir /tmp/synkit-ledger
cd paper/stereo_graph
latexmk -pdf main.tex
latexmk -pdf cover_letter.tex
```

The theory, chemical and software reader roles are unfilled by independent humans in this automated revision. The documented substitute is a clean checkout and isolated-environment reproduction, finite convention/geometry checks, complete independent partition and chemical-annotation replay, plus a structured review of the written proof and information boundaries. These checks are not a formal machine proof or independent human review. Funding and contribution roles are now applied under explicit user instructions. Author approval, competing interests and a public release identifier would be needed for any future formal submission.

The complete clean execution is retained under `Experiment/Stereo/Data/Revision/CleanReleaseFull/execution`: 90 unchanged files, including both attempts, every stage log and all raw reports. Its source is clean `e2526b9`; all 531 scientific Python hashes match the current revision. `controlled_costs.json` and `chemical_results.json` beside that directory are explicit portable projections. Restoring their linked input paths and removing projection metadata yields the exact original report objects. Cost display bins are recounted from all 540 retained trials, including zero counts; original Counter summaries remain unchanged.

The primary `result_manifest.json` and all 269 generated values now select these results. `pre_clean_full_selection` retains the previous manifest, ledger, performance figures and manuscript, including the unconfirmed draft references. The fresh selection changes 32 numerical claims. VS208 joins VS126/VS127 as a five-second timeout; full-group four-component trials reach the RSS limit. Neither outcome is removed from coverage. Every completed certificate comparison remains correct. Both CIP protocols, detector records and all chemical summary fields retain their previous scientific results. Three repetitions and background load continue to limit performance interpretation.

Verify the selected release and build the separate journal sources with:

```sh
python paper/stereo_graph/revision/release/verify_clean_full_selection.py \
  --repository . --output /tmp/stereo-selection-verification.json
python paper/stereo_graph/revision/release/build_journal_submission.py \
  --paper-dir paper/stereo_graph --output-dir /tmp/stereo-journal-build
python paper/stereo_graph/revision/release/verify_journal_source_archive.py \
  --package-dir /tmp/stereo-journal-build \
  --extraction-dir /tmp/stereo-journal-reader \
  --output /tmp/stereo-journal-reader-verification.json
```

The journal builder separates the combined authoring text at its existing appendix boundary. Main and supplemental review PDFs use double spacing, line/page numbers and distinct supplemental numbering. The editable ZIP includes every observed local TeX dependency. The combined authoring PDF remains available separately. Local builds use TeX Live 2023; compatibility with the publisher's stated TeX Live 2021 compiler has not been tested. The policy checkpoint records the journal's 20 MB limit per additional file; the full research archive requires an accessible repository and its exact persistent identifier.


Eleven individual figure uploads are now in `revision/generated/submission_review/figures`. `build_journal_figures.py` exports their composites without captions, while retaining titles/legends in the manuscript and caption file. `verify_journal_figure_archive.py` compiles only their checked 29-file ZIP and compares all eleven 180 dpi renderings exactly. `verify_journal_figure_binding.py` confirms exported graphical wrappers, dependencies, captions and first-mention order against the current manuscript after non-graphical edits. The separate journal manuscript archive contains 38 files and rebuilds both the 56-page main document and 56-page supplement. `Additional_file_1.pdf` is an identical upload alias for the supplement.

```sh
python paper/stereo_graph/revision/release/build_journal_figures.py \
  --paper-dir paper/stereo_graph --output-dir /tmp/stereo-figures
python paper/stereo_graph/revision/release/verify_journal_figure_archive.py \
  --package-dir /tmp/stereo-figures --extraction-dir /tmp/stereo-figure-reader \
  --output /tmp/stereo-figure-reader.json
python paper/stereo_graph/revision/release/verify_journal_figure_binding.py \
  --paper-dir paper/stereo_graph --package-dir /tmp/stereo-figures \
  --output /tmp/stereo-figure-binding.json
```

`journal_final_editorial_checkpoint.json` records the corrected ACS percentage rendering and the bound result/document checks. Executed helper bytes are retained compressed where subsequent Python line wrapping leaves abstract syntax unchanged. Assistant visual review is separate from independent human review and author approval. The concrete missing author facts and proposed cover-letter declarations are in [author_decisions.md](author_decisions.md). The exact final public release identifier and author-only portal submission remain unresolved.

The user-requested three-author list is applied from Syndoku. [thesis_alignment.md](thesis_alignment.md) maps the thesis graph/label conventions and distinguishes graph-valued `Can` from serialized `can`. Self-contained thesis style dependencies and two new explanatory diagrams are included. Their drawn configurations and exact graph partition pass [explanatory_figure_validation.json](explanatory_figure_validation.json): 18 profile/order verdicts and 2,160 illustrative serializations, separate from the benchmark. The source audit retains author/thesis provenance hashes. All 531 executed scientific Python files and 33 labelled statement/proof blocks remain unchanged.

```sh
python paper/stereo_graph/revision/release/validate_explanatory_figures.py --help
```

The nine-figure archive at `00110d0` is a verified historical checkpoint (2,040 exact files), retained in `research_archive_journal_figures_checkpoint.json`. It predates the requested three-author/thesis changes; the updated eleven-figure review freeze is verified separately. Receipt files added after a frozen source commit are not represented as members of that source archive.

[research_archive_thesis_checkpoint.json](research_archive_thesis_checkpoint.json) verifies the `3c10948` review source: all 2,063 tracked bytes/files and the extracted Git tree agree, all 60 focused contracts pass, all 35-stage/269-claim selection checks and eleven current figure bindings pass, and both combined manuscript/letter rebuild with identical text. The two journal source-reader results transfer through exact ZIP/PDF hashes. This archive includes the requested three authors, notation table, thesis style and two validated explanatory diagrams. The inventory and compressed raw outputs are retained alongside the checkpoint. It is a verified review freeze, not an author-approved public submission release. Subsequent receipt/documentation commits do not alter its scientific or manuscript source bytes.
