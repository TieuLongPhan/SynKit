**Author facts and review scope**

The user explicitly requested **“Finish the review package; no publication or submission.”** The local package is prepared for scientific and author review. Journal-only declarations and a public DOI are future publication steps, not blockers for this task. No public upload or journal submission is performed.

**Applied facts.** The manuscript lists **Tieu-Long Phan, Peter F. Stadler and Daniel Merkle**, in that order, with source affiliations/emails. The user subsequently directed copying **all funding from Syndoku** and retaining Peter and Daniel's roles as revision, supervision and funding acquisition. Long's existing method, code, validation, figures and writing roles are retained.

The funding subsection is copied verbatim, including the EU disclaimer: TACsy grant 101072930; Novo Nordisk MATOMIC grant NNF21OC0066551; Peter's DAAD/SECAI project 57616814, ScaDS.AI project SCADS24B and DFG Excellence Strategy EXC-3105/1, 533765739. The [source audit](author_thesis_source_audit.json) records the exact funding-section digest and explicit user instruction.

| Item | Review-draft status | Any future submission |
| --- | --- | --- |
| Authors and affiliations | Requested source metadata applied | Check for subsequent changes |
| Funding | Full Syndoku statement copied under explicit user instruction | Update only if facts change |
| Contributions | Long's existing roles retained; Peter/Daniel revise, supervise and secure funding | Update only if facts change |
| Competing interests | Explicitly labelled pending in the manuscript | Obtain the authors' declaration |
| All-author submission approval | Not asserted | Obtain approval of the final submission version |
| Preprint/originality/exclusivity | Not inferred | Record accurate facts if submitting later |
| Release identifier | Local immutable source and SHA-256 inventory | A public persistent identifier would be needed for a future public release |

The [manuscript](../generated/submission_review/manuscript.pdf), [Additional file 1](../generated/submission_review/Additional_file_1.pdf), [editable sources](../generated/submission_review/journal_latex_sources.zip), [eleven figures](../generated/submission_review/figures/figure_upload_manifest.json) and one-page draft cover letter are review artifacts. The cover letter is retained for review and does not assert unconfirmed approval/originality facts.

All 35 clean stages, 269 claims from 37 reports, 540 cost trials and unchanged 33 reviewed statement/proof blocks remain verified. Assistant review and automated reproduction do not establish independent human review or author submission approval.
