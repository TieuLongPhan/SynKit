"""Bind exported figure inputs and captions to the current authoring manuscript."""

import argparse
import hashlib
import json
from pathlib import Path
import re
import zipfile

from build_journal_figures import caption, require, sha256


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--paper-dir", type=Path, required=True)
    parser.add_argument("--package-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    paper, package = args.paper_dir.resolve(), args.package_dir.resolve()
    report = json.loads((package / "figure_upload_manifest.json").read_text())
    archive = package / "figure_sources.zip"
    require(sha256(archive) == report["source_zip_sha256"], "Figure archive hash differs.")
    preamble, narrative = (paper / "main.tex").read_text().split("\\begin{document}", 1)
    narrative = narrative.split("\\appendix", 1)[0]
    figures = list(re.finditer(r"\\begin\{figure\*?\}.*?\\end\{figure\*?\}", narrative, re.S))
    require(len(figures) == len(report["figures"]) and figures, "Figure inventory changed.")
    mentions = []
    with zipfile.ZipFile(archive) as packed:
        require(packed.testzip() is None and set(packed.namelist()) == set(report["source_inventory"]),
                "Figure archive inventory differs.")
        for name, entry in report["source_inventory"].items():
            require(hashlib.sha256(packed.read(name)).hexdigest() == entry["sha256"], "Source hash differs.")
            if not re.fullmatch(r"Figure_\d\d\.tex", name):
                require(sha256(paper / name) == entry["sha256"], "Current graphic dependency changed: " + name)
        for match, row in zip(figures, report["figures"]):
            block = match.group(0)
            text, start, end = caption(block)
            require(re.findall(r"\\label\{([^}]+)\}", block) == [row["label"]], "Figure label changed.")
            title, legend = text.split(".", 1)
            require(" ".join(title.split()) + "." == row["title_tex"] and
                    " ".join(legend.split()) == row["legend_tex"], "Figure caption changed.")
            first = narrative.find("\\ref{" + row["label"] + "}")
            require(0 <= first < match.start(), "Figure is not introduced before placement.")
            mentions.append(first)
            body = block[:start] + block[end:]
            body = re.sub(r"\\(?:begin|end)\{figure\*?\}(?:\[[^]]*\])?", "", body)
            body = re.sub(r"\\label\{[^}]+\}", "", body)
            expected = preamble + "\n\\pagestyle{empty}\n\\setlength{\\textwidth}{170mm}\n"
            expected += "\n\\begin{document}\n\\noindent\\begin{minipage}{170mm}\n"
            expected += body + "\n\\end{minipage}\n\\end{document}\n"
            require(packed.read(Path(row["file"]).stem + ".tex") == expected.encode(),
                    "Current figure source changed: " + row["label"])
            require(sha256(package / row["file"]) == row["sha256"], "Figure PDF changed.")
    require(mentions == sorted(mentions), "First-mention order changed.")
    result = {"schema": "synkit.stereo-journal-figure-binding/1", "passed": True,
              "binding_driver_sha256": sha256(Path(__file__)),
              "original_figure_build_main_sha256": report["main_tex_sha256"],
              "current_main_sha256": sha256(paper / "main.tex"),
              "source_zip_sha256": sha256(archive), "figures_checked": len(figures),
              "source_files_checked": len(report["source_inventory"]),
              "boundary": (
                  "All graphical wrappers, dependencies, captions, PDFs and first mentions "
                  "agree with the current manuscript. Non-graphical editorial changes can "
                  "change its whole-file hash without requiring another identical graphic "
                  "build.")}
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"passed": True, "figures": len(figures), "source_files": len(report["source_inventory"])}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
