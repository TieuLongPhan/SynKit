"""Refresh document locators only when reviewed mathematical blocks still match."""

import argparse
import csv
import hashlib
import json
from pathlib import Path
import re
import sys


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repository", type=Path, required=True)
    parser.add_argument("--editorial-note", required=True)
    args = parser.parse_args()
    root = args.repository.resolve()
    sys.path.insert(0, str(root))
    from Experiment.Stereo.manuscript_tables import build_ledger
    paper = root / "paper/stereo_graph"
    binding_path = paper / "revision/release/structured_proof_release_binding.json"
    binding = json.loads(binding_path.read_text())
    pattern = re.compile(r"\\begin\{(definition|lemma|theorem|corollary|proposition)\}.*?\\end\{\1\}"
                         r"(?:\s*\\begin\{proof\}.*?\\end\{proof\})?", re.S)
    checked = 0
    for name, entry in binding["source_documents"].items():
        blocks = [match.group(0) for match in pattern.finditer((root / name).read_text())]
        for label, statement in binding["labelled_statements_and_immediate_proofs"].items():
            if statement["file"] != name:
                continue
            block = next((b for b in blocks if "\\label{" + label + "}" in b), None)
            if block is None or hashlib.sha256(block.encode()).hexdigest() != statement["statement_and_proof_sha256"]:
                raise RuntimeError("Reviewed statement/proof changed; a new review is required: " + label)
            checked += 1
        entry["sha256"] = sha256(root / name)
    if checked != 33:
        raise RuntimeError("The reviewed mathematical block inventory changed.")
    if args.editorial_note not in binding["new_editorial_changes"]:
        binding["new_editorial_changes"].append(args.editorial_note)
    manifest = json.loads((paper / "revision/result_manifest.json").read_text())
    ledger = build_ledger(manifest, root)
    if ledger != json.loads((paper / "revision/generated/numerical_ledger.json").read_text()):
        raise RuntimeError("The selected numerical ledger is stale.")
    register = paper / "revision/current_claim_evidence.csv"
    with register.open() as stream:
        reader = csv.DictReader(stream)
        fields, rows = reader.fieldnames, list(reader)
    numeric = {row["claim_id"]: row for row in ledger}
    if len(numeric) != 269 or len(rows) != 286:
        raise RuntimeError("The claim catalogue changed.")
    source_names = ["main.tex", "technical_details.tex", "cover_letter.tex", "fig/benchmark_evidence_map.tex"]
    sources = {name: (paper / name).read_text().splitlines() for name in source_names}
    binding_path.write_text(json.dumps(binding, indent=2) + "\n")
    for row in rows:
        if row["claim_kind"] != "numerical":
            row["report_sha256"] = sha256(binding_path)
            continue
        claim = numeric[row["claim_id"]]
        row.update({"value": claim["value"], "denominator": claim["denominator"], "scope": claim["scope"],
                    "report_path": claim["report"], "report_schema": claim["schema"],
                    "report_sha256": claim["sha256"], "source_revision": claim["source_commit"],
                    "json_pointer": claim["json_pointer"]})
        locations = []
        macro = re.compile(r"\\" + row["claim_id"] + r"\b")
        for name, lines in sources.items():
            hits = [str(i) for i, line in enumerate(lines, 1) if macro.search(line)]
            if hits:
                locations.append(name + ":" + ",".join(hits))
        row["manuscript_location"] = "; ".join(locations) or "generated numerical ledger; supporting reports/tables"
    with register.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps({"reviewed_blocks_unchanged": checked, "claim_rows": len(rows), "numerical_claims": len(numeric)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
