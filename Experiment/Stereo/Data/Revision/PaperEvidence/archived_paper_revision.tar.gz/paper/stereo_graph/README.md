# Stereo manuscript — Paper I (molecular-graph layer)

This directory is the canonical package for:

**Exact canonicalization of configured molecular stereographs**

The revision is in progress. Current verified values are generated from
`revision/result_manifest.json` into `revision/generated/numerical_ledger.csv`.
The ledger now contains 269 numerical claims from 37 checksummed artifacts,
including the frozen chemical annotations and their production comparisons.
Primary identity, perception, naming and chemical results use these values.
The historical rows below remain explicitly separate evidence; final clean
release reproduction is still required before submission.

The contribution is a **faithful uniform reduction of configured molecular
stereographs to colored graphs**, with explicit identity, transport, mirror
and information contracts. Perception and derived naming have separate
validation boundaries. M\O D, Molassembler, RDKit, MACE and StereoMolGraph
are credited for their prior representation, comparison and canonicalization
contributions.

Split out of the former single manuscript in `paper/stereo`, which is retained
as the pre-split reference. This paper covers the **molecular-graph layer**:

- a staged pipeline of candidate-carrier perception, configuration-neutral
  local-neighbor frames, configuration attachment/orbit identity, exact
  configured-stereograph canonicalization, whole-molecule mirror
  classification, and optional derived naming; carrier evidence is never
  itself a confirmed or configured stereo element;

- the typed support hierarchy (atom / bond / axis / path / plane / global) that
  separates *where* a stereo element lives from *how* it is configured;
- the Lewis-labeled graph (LLG) substrate, with explicit lone-pair, radical,
  sigma-bond, and pi-bond resources, plus typed virtual references (`@H`,
  `@LP`);
- seven registered orbit shapes (tetrahedral, square-planar,
  trigonal-bipyramidal, octahedral, planar-bond, atrop-axis, cumulene-axis)
  plus configured helical-path and planar-chirality descriptors;
- an exact auxiliary stereograph certificate for all ten configured
  families, plus whole-stereograph identity/enantiomer/diastereomer
  classification that does not consult CIP labels;
- a coupled-frame ``FrameworkStereo`` value over global support, with
  topology-proven necessary chirality kept separate from configured
  positive/negative orientation;
- representative-independent double-coset relation classes and concrete
  transport witnesses, with proofs;
- neighbour alignment, stereo-preserving graph morphisms with explicit
  information/presence policies, functorial witness composition, and the
  stereo-aware value identity / hashing contract;
- derived CIP labels as *witnessed projections* — an independent ranking kernel
  recording the deciding sequence rule, with typed failure statuses instead of
  guesses — never as stored identity;
- whole-molecule chirality by exact configured-certificate mirror comparison,
  kept distinct from the ACS-specialized topology-completion classifier and
  its four-state completion-population assessor;
- RDKit and StereoMolGraph interchange boundaries.

The reaction layer — rules, ITS, reference-aligned change, reversal, fusion
proof v2, mechanism replay — is the companion paper in `paper/stereo_rxn`,
cited here as `phan2026stereorxn`.

`SynKit` is the reference implementation, not the paper's primary contribution.

Active development is tracked in `../../sprint/sprint_plan.html`.
The current ten-sprint cycle established typed tetrahedral, double-bond, cumulene, and atrop
perception; exact carrier-stabilizer ligand classes; recursive
configuration-neutral neighborhood frames; the complete auxiliary
stereograph for ten configured families; exact assignment enumeration; and
planar-chirality support. Supplied configuration and CIP are downstream outputs
and never frame-ordering or certificate inputs. Coupled tetrahedral global
stereo is configured. Synthetic constitutional negatives now cover broad-axis
specificity. Newly sourced coordination and biaryl examples validate the
retained configured and constitutional claims; a frozen 60-locus RotA review
is source-assisted development-corpus adjudication. Experimental
stability/handedness validation, additional
global geometry families, full CIP sequence rules, coordinate-based
orientation perception, and symmetry-pruned certificate scaling remain
declared gaps.

## Files

- `main.tex` — manuscript entry point, retaining the essential faithfulness proof and independent validation.
- `technical_details.tex` — included technical appendices with detailed algebra, information boundaries, historical gates and resource measurements.
- `revision/generated/performance/` — PDF/SVG controlled cost, memory/output and registration figures with input hashes.
- `cover_letter.tex` — Journal of Cheminformatics cover-letter draft.
- `revision/chemical_ledger_checkpoint_verification.json` — committed-source
  verification of the 247-test bounded run, chemical summary and result ledger.
- `../../Experiment/Stereo/Data/Revision/Chemical/manuscript_summary.json` —
  counts recomputed from four byte-unchanged frozen annotation/evaluation reports.

### Structure

The manuscript follows a Journal of Cheminformatics-oriented structure:
Background → Methods and LLG notation → carrier perception and configuration
attachment → exact graph canonicalization → molecular chirality →
Experiments and results (protocol and result subsections) → Discussion →
Conclusions → Declarations → References → technical appendices.  The methods
include an end-to-end chirality algorithm,
a binary soundness/completeness theorem under an explicit support boundary,
and a four-state completion algorithm for underspecified input.

- `fig/` — figures used by this paper only. `support_hierarchy.tex`,
  `support_motivation.tex`, `axial_helical.tex`, `cip_projection.tex`, and
  `pipeline.tex` are new to
  this manuscript; the rest are inherited from the pre-split package.
- `authors.tex`, `references.bib`, `sn-jnl.cls`, `sn-mathphys-num.bst` —
  submission metadata and template.

## Build

```bash
conda run -n synkit python Experiment/Stereo/Chirality/draw_exact_mismatch_figure.py
cd paper/stereo_graph
latexmk -pdf main.tex
latexmk -pdf cover_letter.tex
```

`main.tex` is self-contained and produces the complete article and appendices
as one PDF.  For journal review, `revision/release/build_journal_submission.py` generates separate main and supporting-information PDFs and a complete editable source ZIP from this combined source.

## Provenance of the reported numbers

The rows below preserve the historical development snapshot. They are not
the current release acceptance record. The current numerical ledger and
checkpoint verifications are the authoritative revision evidence; final
reproduction from the release archive remains required.

| Number | Source |
| --- | --- |
| 3,907 passed, 31 skipped, 179 subtests | `python -m pytest -q` (full suite) |
| Configuration-free local: 66,468/66,468 representations and 3,476/3,476 carriers over 1,218 rows | `Experiment/Stereo/Data/Canonicalization/{internal,acs,cip,rota}_local_canonicalization_report.json` |
| Formal A/B/C: 2,160/2,160 assignments over 30/30 cases; raw A/B plus raw C/VS146: 3,353,600/3,353,600 encodings over 22 scoped cases; zero timeout/failure | `Experiment/Stereo/Data/Canonicalization/Global/` |
| 940 raw local representations → 67/67 exact classes; 201 per-class + 528 representative relabellings | `Experiment/Stereo/Data/Canonicalization/global_local_canonicalization_report.json` |
| 888/888 public ACS atom permutations, 0 failures | same report, external tier |
| 32 multi-element assignments → 31 global classes; 13 enantiomer pairs, 64 diastereomer pairs, 5 mirror-fixed classes | `Experiment/Stereo/Data/Canonicalization/multi_element_canonicalization_report.json` |
| 7/7 multi-element ACS cases; 14/14 sampled renumberings; 18 configured elements | same report, public tier |
| RotA 40 multi-locus records/88 loci; CIP 153 multi-\(R/S\) records and 116 multi-attached records | same report, task-scoped extraction tiers |
| Pairwise relation conformance 9/9 | `Experiment/Stereo/Data/Chirality/stereoisomer_relation_report.json` |
| Controlled costs: 540 planned trials, 513 completed, 6 timeouts, 3 memory-limit outcomes, 18 expected boundary refusals; no full-code disagreement | `Experiment/Stereo/Data/Revision/Performance/controlled_full.json` |
| Registration: all 30 pipelines recover independent partitions; no speed crossover over 8–128 records | `Experiment/Stereo/Data/Revision/Performance/registration_full.json` |
| Historical ACS selection: topology completion 258/258; source-declared chemical identity 254 correct/258 inputs, 256 definitive at 5 s; exact-plus-global 257/258 at 30 s; pinned live SMG replay 254/258 | Earlier `Experiment/Stereo/Data/Revision/Protocols/` reports |
| Four-state 125/66/67/0, 214 constitutions, 258 definitive | same report, stereo-stripped protocol |
| ACS local perception retained/erased 1007/743 of 1007; 258/258 renumbering in each setting | `Experiment/Stereo/Data/Perception/full_detection_report.json` |
| CIP local perception retained/erased 1252/969 of 1252; 300/300 renumbering in each setting | same report |
| RotA perception 698/698 loci and 15/15 paths in both settings; 650/650 renumbering in each setting | same report |
| Synthetic RotA constitutional negatives 24/24 invariant: 13 exact symmetry witnesses, 11 no-axis controls, 0 confirmed-axis false positives | `Experiment/Stereo/Data/RotA-Synthetic/negative_axes.json` |
| Erased-input misses: ACS 264 and CIP 283, all symmetry-related carbon tetrahedral carriers and all recovered with retained neighbor frames | same report |
| CIP naming with pinned 3D: 187/300 exact; 926/1252 labels, 937 emitted; SMILES-only 175/300 | `Experiment/Stereo/Data/Perception/cip_native_report.json` |
| CIP supplied-SMILES ceiling 299/300; pinned external 3D coordinates distinguish the VS010/VS011 conflict | `Experiment/Stereo/Data/CIP/input_contract_audit.json` |
| Class sets 6 / 9 / 6 / 4 | `synkit/Graph/Stereo/descriptors.py` |
| Seven local orbit shapes; ten local configured families plus one coupled framework family | `orbits.py`; `configured.py`; `global_stereo.py` |

The 300/300 StereoMolGraph descriptor bridge and 6/6 conformance figures in the
pre-split manuscript were **not** re-measured and are not current evidence;
regenerate them before restoring either claim to a submission draft.

## Before submission

- Unconfirmed companion references are omitted from the submission bibliography;
  the molecular paper is self-contained and preserves its reaction-layer scope boundary.
- The companion paper (`paper/stereo_rxn`) may still recap older class sets and
  pre-enhancement counts; sync it after the molecular benchmark and paper
  release is frozen.
- Freeze an immutable release, regenerate every result count, verify author
  metadata/CRediT/funding text, and archive the environment.

The primary clean-full selection is now `revision/result_manifest.json`: 269 claims over 37 reports, checked by `release/clean_full_selection_verification.json`. All 35 research stages complete. The current five-second ACS row is 253 correct/258 inputs with 255 definitive outcomes, retaining VS126/VS127/VS208 timeouts. Controlled costs retain three timeouts and six RSS limits. Fresh registration medians at 128 records are 0.140 s pairwise and 1.078 s certificates; no speed crossover is observed. The previous primary selection is preserved under `revision/release/pre_clean_full_selection`.
