"""Preserve a complete full run and derive explicitly portable linked reports.

Raw execution bytes remain unchanged. Two separate projections relocate only
the input paths that numerical validators must dereference in an extracted tree.
"""

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import shutil


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--repository", type=Path, required=True)
    parser.add_argument("--destination", type=Path, required=True)
    args = parser.parse_args()
    run = args.run_dir.resolve()
    root = args.repository.resolve()
    destination = args.destination.resolve()
    require(destination.is_relative_to(root), "Archive destination must be inside the repository.")
    require(not destination.exists(), "Use a new archive destination to preserve prior evidence.")
    manifest = json.loads((run / "stage_manifest.json").read_text())
    names = manifest["selected_stage_names"]
    rows = manifest["records"]
    require(manifest["tier"] == "full" and manifest["complete"] and len(names) == 35,
            "A complete 35-stage full sequence is required.")
    require([row["stage"] for row in rows] == names and
            all(row["status"] == "complete" and row["returncode"] == 0 for row in rows),
            "A required stage is missing or unsuccessful.")
    source = manifest["provenance"]
    require(source["source_unchanged_during_run"] and source["inputs_unchanged_during_run"],
            "Executed source or inputs changed.")
    for name, value in source["source_sha256"].items():
        require(sha256(root / name) == value, "Repository code differs from executed code: " + name)
    for row in rows:
        require((run / (row["stage"] + ".log")).is_file(), "Required stage log missing.")
        if "report_sha256" in row:
            require(sha256(run / (row["stage"] + ".json")) == row["report_sha256"],
                    "Completed report changed: " + row["stage"])
    require(manifest.get("attempt_history") and "resume_validation_sha256" in manifest,
            "The preserved failed attempt and resume validation are required.")
    require(sha256(run / "resume_validation.json") == manifest["resume_validation_sha256"],
            "Resume validation changed.")
    for attempt in manifest["attempt_history"]:
        require(sha256(Path(attempt["manifest"])) == attempt["sha256"], "Attempt manifest changed.")
    execution = destination / "execution"
    inventory = {}
    for path in sorted(run.rglob("*")):
        if not path.is_file():
            continue
        relative = path.relative_to(run)
        target = execution / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)
        require(sha256(target) == sha256(path), "Raw execution copy differs: " + str(relative))
        inventory[str(relative)] = {"sha256": sha256(target), "bytes": target.stat().st_size}
    projections = {}
    mappings = {
        "controlled_costs": {"inputs": "controlled_costs_inputs.json"},
        "chemical_results": {"coordination_annotation": "chemical_annotation.json",
                             "coordination_production": "chemical_validation.json",
                             "rota_annotation": "rota_annotation.json",
                             "rota_production": "rota_validation.json"},
    }
    for name, mapping in mappings.items():
        original_path = execution / (name + ".json")
        original = json.loads(original_path.read_text())
        projected = json.loads(original_path.read_text())
        changes = []
        for role, filename in mapping.items():
            entry = projected["inputs"] if name == "controlled_costs" else projected["inputs"][role]
            target = execution / filename
            require(sha256(target) == entry["sha256"], "Linked scientific input differs: " + filename)
            previous = entry["path"]
            entry["path"] = str(target.relative_to(root))
            changes.append({"role": role, "original_path": previous, "archive_relative_path": entry["path"],
                            "input_sha256_unchanged": entry["sha256"]})
        projected["archive_relocation"] = {
            "execution_report_path": str(original_path.relative_to(root)),
            "execution_report_sha256": sha256(original_path), "changes": changes,
            "boundary": "Only dereferenced input paths change. Scientific records, numerical summaries and original execution provenance remain unchanged."
        }
        if name == "controlled_costs":
            # Counter serialization omits zero bins. Derive a complete display
            # table from every trial without editing the original summaries.
            statuses = ("complete", "timeout", "rss_limit", "incomplete_input",
                        "unsupported_input", "bounded_search")
            counts = {}
            for mode, summary in original["summary"].items():
                observed = Counter(row["status"] for row in original["records"] if row["mode"] == mode)
                require(dict(observed) == summary["outcomes"] and set(observed) <= set(statuses),
                        "Unexpected or inconsistent controlled-cost outcome.")
                counts[mode] = {status: observed[status] for status in statuses}
            projected["archive_relocation"]["derived_outcome_counts"] = counts
            projected["archive_relocation"]["derived_count_boundary"] = (
                "Every display bin is counted from all retained trials; absent Counter bins have count zero. "
                "Original scientific summaries and every trial remain unchanged.")
        target = destination / (name + ".json")
        target.write_text(json.dumps(projected, indent=2) + "\n")
        reverse = json.loads(target.read_text())
        reverse.pop("archive_relocation")
        for change in changes:
            entry = reverse["inputs"] if name == "controlled_costs" else reverse["inputs"][change["role"]]
            entry["path"] = change["original_path"]
        require(reverse == original, "A scientific field changed during relocation: " + name)
        projections[name] = {"path": str(target.relative_to(root)), "sha256": sha256(target),
                             "execution_sha256": sha256(original_path), "reverse_projection_matches_original": True}
    report = {"schema": "synkit.stereo-full-execution-archive/1", "execution_source_commit": source["source_commit"],
              "captured_python_sources": len(source["source_sha256"]), "completed_required_stages": 35,
              "original_run_directory": str(run), "raw_archive_path": str(execution.relative_to(root)),
              "raw_inventory": inventory, "raw_file_count": len(inventory),
              "raw_bytes": sum(entry["bytes"] for entry in inventory.values()),
              "all_raw_bytes_preserved": True, "portable_projections": projections,
              "archiving_driver_sha256": sha256(Path(__file__)), "scientific_reconciliation_complete": False}
    (destination / "archive_manifest.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"stages": 35, "raw_files": len(inventory), "raw_bytes": report["raw_bytes"],
                      "portable_projections": list(projections)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
