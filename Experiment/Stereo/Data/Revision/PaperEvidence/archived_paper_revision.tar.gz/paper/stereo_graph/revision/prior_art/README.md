# Release-specific representation checks

The RDKit 2026.03.1 probe checks canonical SMILES representation independently
of SynKit identity, perception and naming. Fixtures come from the official
RDKit Book source at the `Release_2026_03_1` tag. The fixture manifest records
the exact URL and document checksum. These are formal encodings with distinct
ligands, including the documentation's invented coordination examples. They
are not chemically adjudicated observations.

From the repository root, run:

```sh
python paper/stereo_graph/revision/prior_art/rdkit_representation_probe.py \
  --fixtures paper/stereo_graph/revision/prior_art/rdkit_representation_fixtures.json \
  --output /tmp/rdkit_representation_report.json
```

The archived run uses Python 3.12.12 and RDKit 2026.03.1. Sanitization is
enabled, explicit hydrogens are retained, non-tetrahedral chirality is enabled,
and canonical isomeric SMILES are requested. The probe restores RDKit's
previous non-tetrahedral setting afterwards.

| Family | Distinct numbered states | Atom permutations checked |
|---|---:|---:|
| Square planar | 3 | 360 |
| Trigonal bipyramidal | 20 | 14,400 |
| Octahedral | 30 | 151,200 |
| Total | 53 | 165,960 |

Every state retains one canonical output across all atom permutations.
Parse/write round trips preserve it, all documented equivalent encodings
agree within each family, and removing stereo collapses the states to a
single constitutional output. Equality comparisons use complete strings.

These observations rule out claiming that this release categorically lacks
non-tetrahedral canonical representation. They do not prove RDKit's
canonicalization on all inputs, validate 3D coordinate interpretation, assign
CIP labels, or establish experimental configurational persistence.

The Circular Stereo v2 preprint remains a separate review item. Its Crossref
metadata identifies `https://chemrxiv.org/doi/pdf/10.26434/chemrxiv.15002723/v2`
as the full-text URL; it was still inaccessible on 3 October 2026. No theorem
from that uninspected text is attributed in the manuscript. The primary
experiment source and immutable StereoMolGraph comparison records remain
documented in `../prior_art_audit.json`.
