"""Resume a failed full sequence after validating its completed prefix.

The maintained research runner executes the suffix. The combined manifest keeps
the original failed attempt and validates all reports before declaring completion.
Run with the original interpreter and checkout; never edit the research sources.
"""

import argparse
import hashlib
import importlib.metadata
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--stereomolgraph", type=Path, required=True)
    parser.add_argument("--environment", type=Path, required=True)
    parser.add_argument("--comparator-lock", type=Path, required=True)
    options = parser.parse_args()
    root = options.source.resolve()
    out = options.output_dir.resolve()
    manifest_path = out / "stage_manifest.json"
    prior = json.loads(manifest_path.read_text())
    require(prior["tier"] == "full" and not prior["complete"], "Expected an incomplete full sequence.")
    records = prior["records"]
    require(bool(records) and records[-1]["status"] != "complete", "Expected a failed final attempt.")
    prefix = records[:-1]
    require(all(row["status"] == "complete" and row["returncode"] == 0 for row in prefix),
            "The retained prefix contains an unsuccessful stage.")

    sys.path.insert(0, str(root))
    from Experiment.Stereo import reproduce
    from Experiment.Stereo.provenance import capture_source, finish_source
    from Experiment.Stereo.cip_sources import COORDINATE_PATH, SMILES_PATH
    require(reproduce.ROOT == root, "Research module imported from the wrong checkout.")
    args = argparse.Namespace(tier="full", output_dir=out, jobs=prior["jobs"],
                              stage_timeout=prior["stage_timeout_seconds"],
                              cip_path=SMILES_PATH, coordinate_path=COORDINATE_PATH,
                              stereomolgraph=options.stereomolgraph.resolve(), allow_expensive_raw=False)
    original_stages = reproduce.stages
    selected = original_stages(args)
    names = [name for name, _ in selected]
    require(names == prior["selected_stage_names"], "Selected stage list changed.")
    for record, (name, argv) in zip(records, selected):
        require(record["stage"] == name and record["command"] == argv,
                "Stage arguments or interpreter changed: " + name)
    require(len(records) <= len(selected), "Manifest has more records than selected stages.")
    for record in prefix:
        name = record["stage"]
        require("report_sha256" in record and
                digest(out / (name + ".json")) == record["report_sha256"],
                "Completed report changed: " + name)
        require((out / (name + ".log")).is_file(), "Completed stage log missing: " + name)

    old_source = prior["provenance"]
    require(old_source["source_unchanged_during_run"] and old_source["inputs_unchanged_during_run"],
            "The failed attempt did not preserve source/input identity.")
    source = capture_source([Path(path) for path in old_source["input_sha256"]])
    for key in ("source_commit", "source_sha256", "input_sha256", "python", "rdkit", "networkx", "platform"):
        require(source[key] == old_source[key], "Source or runtime changed: " + key)
    require(not source["working_tree_dirty"], "Original research checkout is dirty.")

    environment = json.loads(options.environment.read_text())
    expected = environment["dependency_closure"]
    for name, version in expected.items():
        require(importlib.metadata.version(name) == version, "Base dependency changed: " + name)
    lock = options.comparator_lock.read_text()
    versions = re.findall(r"^typing-extensions==([^\s]+) --hash=sha256:([0-9a-f]{64})$", lock, re.M)
    require(len(versions) == 1, "Expected exactly one hash-pinned comparator dependency.")
    require(importlib.metadata.version("typing-extensions") == versions[0][0],
            "Comparator dependency version does not match the overlay.")
    comparator = args.stereomolgraph
    comparator_commit = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=comparator, text=True).strip()
    require(comparator_commit == "2b99f62c40aa93ee73887ab3882badeb8d29804e", "Comparator commit changed.")
    require(not subprocess.check_output(["git", "status", "--porcelain"], cwd=comparator, text=True).strip(),
            "Comparator checkout is dirty.")
    comparator_hashes = {str(p.relative_to(comparator)): digest(p)
                         for p in sorted((comparator / "src").rglob("*.py"))}
    sys.path.insert(0, str(comparator / "src"))
    importlib.import_module("stereomolgraph.graphs.crg")

    attempt = out / "attempt_01_dependency_failure"
    require(not attempt.exists(), "Preserved attempt already exists; inspect before retrying.")
    attempt.mkdir()
    shutil.copy2(manifest_path, attempt / "stage_manifest.json")
    failed_name = records[-1]["stage"]
    shutil.copy2(out / (failed_name + ".log"), attempt / (failed_name + ".log"))
    validation = {
        "schema": "synkit.stereo-full-resume-validation/1",
        "source": source,
        "original_manifest_sha256": digest(attempt / "stage_manifest.json"),
        "reused_complete_stage_names": [row["stage"] for row in prefix],
        "resumed_stage_names": names[len(prefix):],
        "base_dependency_versions": expected,
        "base_environment_sha256": digest(options.environment),
        "environment_change": {"package": "typing-extensions", "version": versions[0][0],
                               "wheel_sha256": versions[0][1],
                               "overlay_lock_sha256": digest(options.comparator_lock),
                               "reason": "Declared optional StereoMolGraph import dependency missing in base environment."},
        "comparator_commit": comparator_commit,
        "comparator_source_sha256": comparator_hashes,
        "claim_boundary": "Prefix hashes verified; report-specific scientific contracts remain separate gates."
    }
    write_json(out / "resume_validation.json", validation)
    print(json.dumps({"state": "resume_validated", "reused_stages": len(prefix),
                      "remaining_stages": len(selected) - len(prefix)}), flush=True)
    reproduce.stages = lambda unused: selected[len(prefix):]
    try:
        returncode = reproduce.run(args)
    finally:
        reproduce.stages = original_stages
    suffix = json.loads(manifest_path.read_text())
    shutil.copy2(manifest_path, out / "continuation_stage_manifest.json")
    require(suffix["selected_stage_names"] == names[len(prefix):], "Continuation stage list changed.")
    combined = prefix + suffix["records"]
    require([row["stage"] for row in combined] == names[:len(combined)], "Combined order invalid.")
    for row in combined:
        if row["status"] == "complete" and "report_sha256" in row:
            require(digest(out / (row["stage"] + ".json")) == row["report_sha256"],
                    "Final report hash changed: " + row["stage"])
    for name, value in comparator_hashes.items():
        require(digest(comparator / name) == value, "Comparator source changed: " + name)
    for name, value in expected.items():
        require(importlib.metadata.version(name) == value, "Base dependency changed during continuation: " + name)
    require(importlib.metadata.version("typing-extensions") == versions[0][0], "Overlay changed during continuation.")
    report = {**suffix, "provenance": finish_source(source), "selected_stage_names": names,
              "records": combined,
              "complete": len(combined) == len(selected) and
              all(row["status"] == "complete" and row["returncode"] == 0 for row in combined),
              "attempt_history": [{"manifest": str(attempt / "stage_manifest.json"),
                                   "sha256": digest(attempt / "stage_manifest.json"),
                                   "status": "failed", "failed_stage": failed_name},
                                  {"manifest": str(out / "continuation_stage_manifest.json"),
                                   "sha256": digest(out / "continuation_stage_manifest.json"),
                                   "status": "complete" if suffix["complete"] else "incomplete"}],
              "resume_validation_sha256": digest(out / "resume_validation.json")}
    write_json(manifest_path, report)
    print(json.dumps({"state": "combined_manifest_written", "complete": report["complete"],
                      "stage_count": len(combined)}), flush=True)
    return returncode


if __name__ == "__main__":
    raise SystemExit(main())
