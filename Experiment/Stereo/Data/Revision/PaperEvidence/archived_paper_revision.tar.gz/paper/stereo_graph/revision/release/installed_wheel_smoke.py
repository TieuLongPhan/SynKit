"""Check installed wheel bytes and stereo behavior outside any source checkout."""

import argparse
import hashlib
from importlib import metadata
import json
from pathlib import Path
import platform
import re
import sys
from zipfile import ZipFile

from rdkit import Chem
import rdkit
import synkit
from synkit.Graph.Stereo import (
    canonicalize_rdkit_configured_stereograph,
    classify_rdkit_configured_stereograph_mirror,
)


def digest(path):
    """Hash a complete artifact without changing its byte representation."""
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify(args):
    """Verify isolation, locked dependencies, installed payload and stereo boundaries."""
    prefix = Path(sys.prefix).resolve()
    package = Path(synkit.__file__).resolve().parent
    assert sys.prefix != sys.base_prefix
    assert package.is_relative_to(prefix)
    assert "include-system-site-packages = false" in (prefix / "pyvenv.cfg").read_text().lower()
    assert metadata.version("synkit") == synkit.__version__ == args.version
    versions = {}
    for line in args.lock.read_text().splitlines():
        match = re.match(r"([A-Za-z0-9_.-]+)==(\S+)\s+--hash=sha256:[0-9a-f]{64}$", line)
        if match:
            name, expected = match.groups()
            versions[name] = metadata.version(name)
            assert versions[name] == expected, name
    assert len(versions) == 46
    verified_files = {}
    with ZipFile(args.wheel) as archive:
        for name in archive.namelist():
            if name.startswith("synkit/") and not name.endswith("/"):
                actual = package / name.removeprefix("synkit/")
                expected = hashlib.sha256(archive.read(name)).hexdigest()
                assert digest(actual) == expected, name
                verified_files[name] = expected
    boundaries = []
    cases = (
        ("C[C@H](Cl)C(Cl)C", ("incomplete",) * 3),
        ("C[C@H](Cl)[C@H](Cl)C", ("achiral",) * 3),
        ("C[C@H](Cl)[C@@H](Cl)C", ("chiral",) * 3),
        ("COP(=O)(N)[18O-]", ("incomplete",) * 3),
        ("CO[P@](=O)(N)[18O-]", ("chiral",) * 3),
        ("COP(=O)(N)[O-]", ("achiral", "incomplete", "achiral")),
    )
    profiles = ("chemical", "lewis_state", "acs_topology")
    for smiles, expected in cases:
        molecule = Chem.MolFromSmiles(smiles)
        assert molecule is not None
        for profile, status in zip(profiles, expected, strict=True):
            for reverse in (False, True):
                order = list(range(molecule.GetNumAtoms()))
                result = classify_rdkit_configured_stereograph_mirror(
                    Chem.RenumberAtoms(molecule, order[::-1] if reverse else order), identity_profile=profile,
                )
                assert result.status.value == status
                assert result.is_definitive == (status != "incomplete")
            boundaries.append({"input": smiles, "profile": profile, "expected_status": status,
                               "atom_orders_checked": 2})
    fixtures = json.loads(args.fixtures.read_text())
    parameters = Chem.SmilesParserParams()
    parameters.removeHs = False
    coordination = []
    for group in fixtures["groups"]:
        codes = set()
        for state in range(1, group["state_count"] + 1):
            molecule = Chem.MolFromSmiles(group["ordered_ligand_template"].format(state), parameters)
            assert molecule is not None
            code = canonicalize_rdkit_configured_stereograph(molecule).canonical_code
            reverse = Chem.RenumberAtoms(molecule, list(reversed(range(molecule.GetNumAtoms()))))
            assert canonicalize_rdkit_configured_stereograph(reverse).canonical_code == code
            codes.add(code)
        assert len(codes) == group["state_count"]
        coordination.append({"family": group["family"], "states": len(codes), "atom_orders_checked": 2})
    return {"schema": "synkit.installed-wheel-stereo-smoke/1", "passed": True,
            "python": platform.python_version(), "rdkit": rdkit.__version__, "synkit": synkit.__version__,
            "sys_prefix": str(prefix), "sys_base_prefix": sys.base_prefix, "package_origin": str(package),
            "inherited_system_packages": False, "locked_dependency_versions": versions,
            "wheel_sha256": digest(args.wheel), "lock_sha256": digest(args.lock),
            "fixtures_sha256": digest(args.fixtures), "script_sha256": digest(__file__),
            "installed_payload_sha256": verified_files, "mirror_boundaries": boundaries,
            "coordination_encoding_states": coordination,
            "scope": "Installed-byte verification and finite smoke checks; not full research reproduction."}


def main():
    """Write the reproducible installed-package verification record."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--wheel", type=Path, required=True)
    parser.add_argument("--lock", type=Path, required=True)
    parser.add_argument("--fixtures", type=Path, required=True)
    parser.add_argument("--version", default="1.6.2")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = verify(args)
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"passed": report["passed"], "verified_installed_files": len(report["installed_payload_sha256"]),
                      "mirror_cases": len(report["mirror_boundaries"]),
                      "coordination_states": sum(row["states"] for row in report["coordination_encoding_states"])}))


if __name__ == "__main__":
    main()
