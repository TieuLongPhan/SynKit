**Stereo graph revision evidence log**

Work started on 2 October 2026 in the isolated `stereo-paper-revision` branch at `/home/lolo/Documents/TACsy/SynEco/SynKit-stereo-revision`. The original workspace and its unrelated changes are preserved. The complete objective remains the programme in [revision_plan.md](revision_plan.md); this log records completed work and outstanding gates.

**Phase 0 — completed baseline capture**

[revision/baseline.json](revision/baseline.json) records the starting commit, the original dirty-tree paths, environment, and 191 source/artifact checksums. [revision/baseline_environment.txt](revision/baseline_environment.txt) records the installed dependency versions. [claim_evidence.csv](claim_evidence.csv) registers 38 numerical, mathematical, API, novelty, and submission claims with their evidence boundaries and discrepancies. Ten key reports are preserved with checksums in [revision/historical_manifest.json](revision/historical_manifest.json).

The starting package version is 1.6.2. The paper's 2.0.0b2 reference is unresolved until the final source freeze; it is not silently treated as the audited release. Numerical claims awaiting reproduction or an independent oracle are marked accordingly.

**Phase 1 — correctness implementation and combined regression gate completed**

Strict mirror assessment now refuses required unresolved loci. The partial 2,3-dichlorobutane counterexample returns incomplete, while its complete meso and chiral forms return achiral and chiral respectively. Source-declared assessment remains a separate boundary. Regression tests cover all three identity profiles and reversed atom numbering.

The terminal phosphate exemption is restricted to neutral, nonradical, four-coordinate phosphorus of valence five with terminal hydrogen-free, nonradical oxygen ligands. Equal isotope identity is required. Lewis-state assessment retains the localized charge/order distinctions. Chemical identity explicitly closes the supplied resonance drawings under the declared terminal phosphate charge/bond-order exchange; isotope identity is never exchanged. This supplies a concrete transposition argument rather than an isotope-only heuristic about unspecified ligand environments.

The resonance audit exposed an additional defect: the default RDKit supplier omitted a neutral Kekulé drawing for VS215/216. With `ALLOW_CHARGE_SEPARATION | KEKULE_ALL`, the four drawing certificates have a mirror-invariant full family. Chemical identity now compares the complete sorted family; intersection of two incompletely enumerated families is not its definition. This is a declared computational resonance convention, not a claim to enumerate every chemically conceivable resonance state. Reaching the safety cap refuses the computation. The flag and supplier interface are documented in [RDKit's primary API documentation](https://www.rdkit.org/docs/source/rdkit.Chem.rdchem.html#rdkit.Chem.rdchem.ResonanceFlags).

Canonicalization and pairwise RDKit operations now accept `identity_profile="chemical"`, `"lewis_state"`, or `"acs_topology"`. Their existing Lewis-state default is preserved; mirror assessment retains its chemical default. Callers can select the same profile across operations. Profile-aware drawing keys use `synkit.rdkit-stereograph/1`; chemical families use `synkit.resonance-family-stereograph/1`. These new persisted keys deliberately differ from the unqualified graph schema. Old stored RDKit keys must be regenerated for comparison with these keys. The generic graph schema remains `synkit.canonical-stereograph/2`.

`ResonanceFamilyCanonicalResult.members` retains drawing-specific orders and witnesses. A member's automorphisms are not advertised as the full family's automorphisms. Mirror results expose `original_identity` and `mirror_identity` for profile-level comparison, alongside the member witnesses used for an actual mirror map. Tests check agreement between canonicalization, pairwise identity, and mirror classification, including VS215/216 and isotope-labelled phosphorus.

Pairwise comparisons now return `information_mismatch` for incompatible represented carrier inventories. Their schema is `synkit.stereoisomer-relation/2`. Framework relative frame coupling remains part of the information boundary. Unknown or unsupported configurations retain their nondefinitive outcomes.

Framework local enumeration, whole-registry enumeration, and focal evidence explicitly raise `TypeError` identifying unsupported framework stereo. Fixed-framework canonicalization and mirror operations remain supported. Unknown framework orientation is an explicit canonicalization refusal and an incomplete mirror input. No helper falls through to a plane attribute or an absent shape-table key.

Coordinate transport requests one constitutional match beyond its budget. Exceeding the budget raises `CoordinateTransportLimitError`; the naming runner records `unresolved_coordinate_transport` and supplies no invented coordinate configuration. Exactly-at-budget enumeration can still be proved exhaustive. Full molecular size, atom isotope/charge/hydrogen/radical/aromatic identity, and bond identity are checked after the substructure match. Synthetic cap tests and the checksum-verified pinned coordinate cases pass.

**Verification and measured changes**

The combined graph-stereo, chemical perception/coordinate integration, and coordinate-transport gate passed **1,763 tests**, with **one skip**. The skip is the optional pinned upstream StereoMolGraph replay because its checkout was unavailable; it is not counted as validation. Four existing pytest iterator deprecation warnings were recorded. The exact test command and machine-readable result are in [revision/phase1_verification.json](revision/phase1_verification.json) and [revision/phase1_tests.xml](revision/phase1_tests.xml). Changed-file lint, source-size policy, and docstring policy pass.

The fresh five-second-per-record source-declared chemical ACS run is saved separately as [revision/exact_acs_mirror_phase1.json](revision/exact_acs_mirror_phase1.json). It produced **256 definitive decisions out of 258**, with **254 correct definitive decisions**. VS126 and VS127 timed out; VS170 and VS300 remain profile/support disagreements. This yields 99.22% definitive coverage, 99.22% accuracy among definitive decisions, and 98.45% correct decisions over all inputs. This run does not substantiate the earlier claim of 258/258 definitive coverage. The old frozen report remains unchanged. Final numerical prose must use the final reproduced protocol, including refusals and the actual resource budget.

**Phase 2 — mathematical draft repairs and finite audits**

The draft now uses the implemented slot-map convention: `p.then(q)` has image `p ∘ q`, while its tuple action replays `q.apply(p.apply(frame))`. The induced alignment cocycle uses the corresponding reversed `then` order. [revision/theory_audit.json](revision/theory_audit.json) exhausts 36 noncommuting action pairs and 7,776 frame/mapping cocycle cases. All corrected laws pass; the reversed laws fail on 18 and 3,888 cases respectively.

The audit constructs TBP rotations from the axial/equatorial geometry and octahedral rotations from exact integer coordinates, independently of production shape tables. Their groups have orders 6 and 24, their frame indices are 20 and 30, and their normalizers have orders 12 and 48. Both normalizer quotients have order two. The revised opposite theorem therefore distinguishes index-two uniqueness from separately available mirror involutions.

The profile definition starts from a fully attributed substrate and asserts isomorphism containment only for a declared coarsening order. Drawing-level canonicalization and finite-family identity have separate contracts. Perception distinguishes constitution-only evidence from evidence retaining neighboring orientations; symmetric inputs return orbit/tie evidence rather than requiring an impossible equivariant unique tuple.

The cost analysis now accounts explicitly for open paths, cyclic paths, planes, coupled framework frames and virtual resources. Eleven output-size fixtures agree with the revised formulas, including quadratic cycle/plane growth. Complete automorphism output, resonance enumeration and assignment products are recognized as separate potentially superlinear costs. Mathematical total canonicalization is distinguished from a bounded implementation's refusal.

The draft adds admissible-support and uniqueness assumptions, a proof for path/plane/framework support relations, compatible-inventory conditions for pairwise chemical relations, and corrected consumer counts. [revision/consumer_inventory.json](revision/consumer_inventory.json) records eight finite orbit shapes, ten local configured families, and the separate framework family, with each narrower consumer boundary stated. The draft builds successfully; its empirical sections remain awaiting final report reconciliation. This is a draft proof revision, not completion of the independent oracle or the closest-prior-art comparison. Phase 2's final gate remains open.

**Phase 2H — sourced closest-method comparison**

[revision/prior_art_audit.json](revision/prior_art_audit.json) records primary sources, locators, information conventions and limitations for the closest methods. The related-work section now credits prior canonicalization and states the proposed advance in terms of the faithful construction and its contracts. The categorical capability table has been replaced with a descriptive, cited comparison. A newly listed Circular Stereo preprint remains a required reading item because its DOI page was inaccessible during this audit. Release-specific matched experiments and the final novelty gate remain open.

**Phase 3 — independent validator implemented; full reproduction pending**

The new reference model derives its finite actions geometrically and reads only
raw descriptor fields. The oracle exhausts attributed constitutional maps that
preserve the frozen inventory, validates the full local choice set, constructs
global assignment orbits, and retains an atom-map witness for every member.
It checks composition, mirror commutation, mirror-fixed classes and enantiomer
pairing. The production comparison uses complete certificates, including for
mirror and offset-renumbered versions of every selected assignment.

The catalogue declares 33 constructed fixtures (279 assignments) and 30 public
formal cases (2,160 assignments). Public carrier inventories remain conditional
inputs rather than independently validated perception. These constructed cases
are mathematical fixtures, not a chemical holdout. The five-case pilot in
[revision/independent_pilot.json](revision/independent_pilot.json) passes, including
the meso exchange, a coupled framework and a tetrahedral/octahedral mixture.
All seven executable mutations are rejected. The canonicalization suite currently
has 42 passing tests and seven skips for optional historical generated artifacts;
[revision/independent_gate_tests.xml](revision/independent_gate_tests.xml) records
the canonicalization subset extracted from the combined test execution. The
combined graph-stereo/perception/canonicalization gate has 1,785 passes, eight
skips and four deprecation warnings; its [full XML](revision/independent_combined_tests.xml)
identifies seven missing historical generated-artifact checks and the absent
optional pinned comparator checkout. Lint, file-size and docstring checks pass
for the changed modules.

The local and global benchmark acceptance conditions now require independent
full-partition agreement and independently exhaustive raw input enumeration.
Constant certificates fail both gates. Comparison uses full equality rather
than finite digests, with an explicit digest-collision regression. The new reports
have schema revision 2; historical revision-1 reports remain historical evidence.

The first full development run was deliberately interrupted after retaining
large certificate copies exceeded the planned worker memory boundary. Its
[interruption record](revision/independent_draft_interruption.json) records the
measured memory and excludes a final full-run claim. The comparison runners now
intern complete codes on disk and compare full bytes within each hash bucket;
colliding hashes remain separate identities. A fresh, unchanged-source run of
all 63 cases is required before the Phase 3 exit gate is closed.

Typed-attribute checks additionally exposed an accepted-input inconsistency:
helical descriptors treated `1`, `True` and `1.0` as equal signed configurations,
but their auxiliary colors produced different full certificates. The descriptor
now normalizes accepted non-null signed values to integers; unknown remains
unknown. A five-case alias regression checks wire type, descriptor equivalence
and global full-certificate equality. This is a follow-up correctness repair
discovered during Phase 3, not a result attributed to the frozen Phase 1 run.
The [signed-state audit](revision/helical_signed_state_audit.json) preserves
the before/after observation and the corrected module hash.

**Outstanding work**

**Phase 3 — full unchanged-source reproduction and archive audit completed**

The [full report](../../Experiment/Stereo/Data/Canonicalization/Independent/full_report.json)
was generated from clean source commit `c59229262172cb12683fa5a295b163f5dc35e4ab`.
All 63 cases and 2,439 formal assignments pass complete partition, mirror, and
offset-renumbering comparisons. No reference is incomplete; all seven mutations
are rejected. Source hashes remained unchanged throughout the run. The production
action audit passes 36 action pairs and 7,776 cocycle cases.

[revision/independent_full_verification.json](revision/independent_full_verification.json)
records a second archive check: all 2,439 retained atom-map witnesses replay,
preserve typed constitutional attributes, and reach their declared assignment;
the archived reference and production partitions agree in every case. All
63 declared fixtures are accounted for, and all hashed sources still match.

The maximum worker process peak RSS was 109.23 MiB. The largest temporary full-code
store used 1,203.12 MiB on disk, for VS126's 1,024 assignments. Disk equality
storage controls memory, but certificate output costs remain substantial and
must be measured in Phase 5. These figures are resource observations from this
validation run, not a controlled performance comparison. The largest case took
520.06 seconds. The independent mathematical oracle remains conditional on the
declared carrier inventory and does not establish chemical perception truth.

Phases 2 and 4–7 remain active: final mathematical and closest-prior-art gates;
separate naming protocols, matched comparisons, overlap accounting and numerical
ledger; controlled performance and registration; new chemical cases and
adjudication; manuscript/cover-letter revision; and a clean submission archive.
No submission-readiness claim follows from the test or orbit counts alone.

**Phase 4 — separate protocols and partial numerical ledger reproduced**

The historical schema-2 SMILES naming report is preserved unchanged under
`Experiment/Stereo/Data/Revision/Historical/`, with its original checksum.
Fresh schema-4 reports in `Experiment/Stereo/Data/Revision/Protocols/` retain
all label sets, exact flags, wrong/missing counts, metadata assistance,
coordinate coverage, transport refusals, source hashes and environment.
The SMILES-only run gives 175 exact records of 300, 902 correct labels of
1,252 expected, 913 emitted, 11 wrong and 350 missing. The family-conditioned
coordinate run gives 187 exact records, 926 correct, 937 emitted, 11 wrong
and 326 missing. All 300 inputs have coordinates; 46 receive additional
coordinate descriptors. Thus 187/300 is exact-record accuracy, not coordinate
availability. No SynKit transport cap is reached.

RDKit's SMILES comparator gives 245 exact records and 1,129 correct labels.
The separate SDF-derived protocol gives 176 exact records and 430 correct
labels, with 226 evaluated records and 74 ambiguous atom transports refused.
It receives the same coordinate availability but uses a different family and
orientation policy; these totals do not establish naming superiority.
StereoMolGraph has no local CIP naming API in the inspected protocol.

The overlap audit retains isotope and charge, erases stereo and map labels,
and does not normalize resonance. Its 1,208 development rows contain 904
distinct constitutions: ACS 214, CIP 255, RotA 650. All 214 ACS constitutions
occur in CIP; one CIP constitution occurs in RotA. Parser-visible configured
representations count 252, 293 and 650, respectively; they are not complete
stereograph identity counts or an untouched chemical holdout. Full strings
are compared internally, while external reports contain digest indices and
case IDs rather than CIP structures.

The three ACS procedures are reproduced separately. Source-declared chemical
identity at five seconds gives 256 definitive and 254 correct decisions:
VS126/127 time out, VS170/300 disagree. Exact identity plus global evidence
at thirty seconds gives 258 definitive and 257 correct, with VS170 the sole
disagreement. Specialized topology completion gives 258 correct. The pinned
live SMG replay at `2189f61` gives 254 correct in the current RDKit environment,
disagreeing on VS246/247/248/299. These observations remain separate from the
published comparator column; their causes require diagnosis. All eight pinned
SMG conformance tests pass.

The report generator verifies hashes, schemas, named scopes, correctness gates
and label-count consistency. Its partial manifest currently has eight reports
and 31 claims, exported as JSON/CSV/TeX under `revision/generated/`. The abstract
and primary naming/ACS rows use those values. The CIP figure now distinguishes
record accuracy from coordinate availability. The manuscript, README and
cover-letter titles are unified as *Exact canonicalization of configured
molecular stereographs*. A new results section explains the independent oracle
and its limits. Both manuscript and cover-letter builds pass; older experiment
rows and the main-text length remain pending final revision.

The bounded entry point reproduces its tests and five-case independent pilot;
full formal validation and explicitly selected raw stress are separate tiers.
Stage timeouts terminate worker process groups. Full local/global arguments
are checked against their actual parsers. The pipeline gate gives 49 passes
and one optional historical-artifact skip; the broader benchmark audit gives
102 passes and 21 such skips. Eighteen focused historical-naming and report-
contract tests pass. The historical naming assertions now execute against an
explicitly archived file. Skipped artifact assertions are not counted as
report validation.

The fresh internal schema-2 local report passes ten carriers, 940 raw inputs
and 67 classes with complete independent references. Full ACS, CIP and RotA
local reports remain running from fixed source hashes. Their outcomes must
be inspected before the historical 66,468/3,476 totals are used as final values.
Phases 2 and 4–7 remain required.


**Phase 4 local full-run outcome: oracle limitations retained**

The fixed-source local runs complete all 66,468 raw representations over 3,476
carriers. Internal (940/10), ACS (23,808/1,062) and CIP (24,632/1,118) pass
with complete independent references. RotA completes all 17,088 representations
of 1,286 carriers, but 41 carrier references in 21 named records reach the
ten-second oracle limit. They are not passes: the command exits 1, and the
required-correctness numerical generator refuses that report. Production
representation invariance remains true in those cases. The report preserves
all limiting IDs and reasons; full independent coverage is not inferred from
the old 100% headline. The next step is to investigate map enumeration while
retaining the same truth and budget, rather than relaxing the acceptance gate.


**Refined independent matcher: full audit repeated; large kernels exposed**

The reference constitutional matcher now uses exact equitable typed-color
refinement and VF2++ proposals with mandatory original edge-color checks.
It uses no production stereo gadget. The complete map sets match the original
GraphMatcher on all 33 constructed fixtures, including a two-edge-color cycle
that refinement alone cannot distinguish. Bool/int and signed-zero controls
pass. The 76-test gate is archived in `revision/refined_matcher_tests.xml`.

A fresh full run from `03c0b01` passes all 63 cases and 2,439 assignments,
rejecting all seven defects. Its partitions and constitutional automorphism
counts agree with the original full run; every new witness replays. The report
and audit are `independent_refined_full.json` and
`revision/refined_full_verification.json`. These are both completed audits,
not a claim that all large public symmetry groups fit the enumeration budget.

On the 21 previously limited RotA rows (43 carriers), the refined follow-up
passes 16 and refuses 27 at the explicit 50,000-automorphism boundary. Fourteen
formerly limited carriers are resolved; the remaining limitations are genuine
large-group enumeration limits. No cap is raised and no refusal is counted as
validation. The next reference method is a separately declared exact rooted
transport-query protocol, frozen in `revision/direct_transport_protocol.json`.
It remains unimplemented and must pass independent fixture and mutation gates
before the complete local matrix is rerun. This follow-up selection is
retrospective development work, not a chemical holdout.

Five CSV tables were regenerated with portable LF line endings; their parsed
fields and all JSON result bytes were unchanged. Current changed-file lint,
whitespace checks, manuscript and cover-letter builds pass. The overall goal
remains active, with Phases 2 and 4–7 still required.

**Single-carrier transport-query reference: implementation and gate**

Implemented the frozen protocol in `independent_transport.py`. It exhausts
proper target frame/support representations and binds material vertices and
virtual-port owners before querying the original typed constitution. Joint
refinement shares a palette across both rooted copies; every proposed map
passes the original node/edge checks. Accepted equivalences have replayable
maps, and negative decisions exhaust admissible bindings. The complete
partition follows from representative-to-remaining-state relation queries.
Whole-group orders are explicitly unenumerated. Composition and mirror laws
are checked on distinct retained positive witness maps. The map-proposal cap
was specified before public runs, alongside the existing 50,000 binding/query
limits, ten-second and 1 GiB limits; every refusal remains incomplete.

The focused gate passes 111 tests, with one optional historical artifact test
skipped. All 17 tractable one-carrier fixtures agree with complete-map truth,
four additional terminal-exchange cases transport virtual references through
owners, and all seven injected defects remain rejected. A constitution with
at least 16,384 frame-trivial symmetries is resolved without enumerating the
group, while the capped full-group oracle correctly refuses. Local CLI users
can explicitly select either reference method; joint-carrier truth retains
complete-map enumeration. Public follow-up and full-matrix runs are pending.

**RotA development follow-up: all direct-query checks complete**

At clean commit `4844dc7`, all 43 carriers in the 21 previously limited rows
pass direct-query partition validation, with all 408 raw canonicalizations
complete. The maximum reference time is 0.056 seconds, with at most 14 frame
bindings, 13 rooted queries and two proposed maps per carrier. This is
reference diagnostic evidence, not a controlled performance comparison. All
86 stored positive maps replay against the original typed constitution,
frozen inventory and configuration; mirror relations reconstruct exactly.
This remains a retrospective development subset. The original 41 timeouts
and refined 27 enumeration-cap refusals remain archived as limitations of
those separately declared methods. The full local matrix must be rerun.

Added a reusable independent witness-replay command and six corruption
controls covering node colors, original edge colors, incomplete maps,
configurations and mirror relations. The audit verifies positive maps and
stored partition consistency; it does not replace the tested exhaustion of
negative rooted queries.

**Full current local and formal matrices complete**

At source commit `6022ddf`, all four local sources pass direct-query partition
validation: 1,218 rows, 3,476 carriers and 66,468 raw representations. All
6,999 positive witnesses replay against the original typed constitution,
frozen inventory and configuration; mirror assignments/classes reconstruct
exactly. They yield 5,885 observed whole-graph classes and 1,114 symmetry
quotients. No reference refusal, production failure or parse failure is
counted as a pass. Original large-group enumeration refusals remain archived.
The formal A/B/C reruns also pass: 30 cases, 2,160 assignments and 38/95/752
classes. Their full-group truth remains separate from direct local queries.

The numerical ledger now contains 87 claims from 20 checksummed reports. Main
local/formal rows use those values; historical raw runs are labelled, and
uncontrolled elapsed times are removed from the main quotient table. The
full reproduction sequence now replays every local witness archive.

The current StereoMolGraph checkout `2b99f62` reproduces the pinned checkout's
254/258 ACS agreement and the same four IDs. A lossless full-inventory transfer
into generic SynKit yields the same mirror verdict in every disputed row. Both
systems change to achiral when planar-bond descriptors are removed. Unrefined
upstream map search agrees with its circular-assisted search. Thus the 258 vs
254 specialized comparison is an adapter-information difference, not evidence
of superiority of one comparison algorithm. The ablation does not adjudicate
the preferred chemical convention. A maintained diagnostic command now
records this boundary; its archived clean-source run follows.

The controlled performance/registration study design is frozen in
`revision/performance_protocol.json`. Inspection confirms canonical search
statistics are recorded before group materialization and serialization; use
that interval directly, rather than subtracting group output from it.
Overall Phases 2 and 4–7 remain active.

The maintained comparator diagnostic passes at clean source `ef4ae67`, with
all four full-inventory comparisons agreeing and both systems changing on
planar-inventory ablation. Its output retains raw descriptor fields and
complete comparator/source hashes. The updated bounded entry point also
completes its focused tests and five-case independent audit at this commit.
The rebuilt manuscript compiles successfully after numerical and scope
corrections. The full revision remains active; performance, chemical
validation, final writing and reproducible submission archive are required.

**Controlled cost and registration harnesses: development gates**

The cost input manifest defines 90 cases and 540 runs at three repetitions
and two output modes: 33 independent fixtures, 24 unique ACS constitutions
selected by input atom-count strata, 24 variable-support inputs, three repeated
component stresses, three explicit boundary probes and three resonance cases.
Fresh workers measure preparation, resonance processing, expansion, input
snapshot, search, witness output, packaging, mirror/pairwise costs and report
serialization. Parent wall/RSS/output limits retain partial checkpoints and
never complete codes. A 64 MiB worker-report cap was declared before public
and stress controlled measurements to bound parent parsing.

The 12-run and 14-run development pilots pass all executed scopes, including
typed boundary refusals and full-code equality between output modes. The
registration 32-row pilot matches independently labelled partitions for
both methods and validates chemical/Lewis/ACS differences and strict partial
input refusal. Pairwise representative registration is faster in this pilot;
it does not support a from-scratch canonicalization speed advantage. The
controlled sweep will measure rather than assume a crossover. The methods
share six conventional frame families and exact attribute selectors; richer
canonical geometries remain in the separate cost study.

The 25-test gate rejects constant-certificate and always-equal pairwise
defects, verifies independent groups, exercises real worker wall/output
limits, and excludes censored runs from completed-only medians. Publication
PDF/SVG plot generation is implemented; development preview only has been
rendered. Controlled final runs and their numerical/prose interpretation
remain pending.

**Phase 5 — registration sweep completed and host conditions disclosed**

The declared registration sweep at clean source `e275a04` completed all 30 pipeline runs across sizes 8, 16, 32, 64 and 128, with three repetitions per method. Both pipelines reproduce the independently declared partitions. Chemical/Lewis/ACS profile checks and strict partial-input refusal also pass. The report and checksummed input manifest are retained under `Data/Revision/Performance/registration_full*`. Source hashes remained unchanged during execution.

No runtime crossover is observed: pairwise comparison with existing group representatives is faster at all tested sizes. At 128 records, medians are 0.202 s versus 1.427 s for from-scratch certificate grouping. This curated small collection is not a chemical holdout or evidence of general registration acceleration. Host load at the end of the report is approximately 19.6 on 22 logical CPUs; memory is whole-study native peak RSS, not independent pipeline memory.

Before the first full cost sweep, a process check found no live stereo research worker but substantial unrelated background CPU work. The prospective protocol now explicitly allows and records that contention. Trial load before/after, exact completed-worker CPU and sampled censored-worker CPU are recorded alongside wall time. The sample, 540 planned runs, group-output modes, resource limits and correctness gates are unchanged. No quiet-host performance claim is made.

**Phase 5 complete — controlled costs, registration and publication figures**

The full controlled sweep at clean `23cf120` attempted every one of 540 prospective trials over 90 inputs. It records 513 completed computations, six wall timeouts, three native-memory limit terminations, six incomplete-input refusals, six unsupported-input refusals and six deliberate search-node refusals. No unexpected error or full-certificate disagreement occurs. Both output modes complete on 85 cases; 86 cases have at least one complete code. Every captured Python hash matches its immutable source commit and the source remained unchanged throughout execution.

Four identical tetrahedral components complete with generators; all complete-group repetitions time out. Eight components time out with generators and reach the memory limit with complete-group output. These nine censored runs stay in coverage and never enter completed timing summaries. Generator-mode completed operation/search medians are 0.038865/0.008894 s; maximum completed native RSS is 365.945 MiB and maximum certificate size 34,945,023 bytes. These pooled statistics describe a heterogeneous chosen workload, not general deployment latency. Pairwise mirror checking dominates the completed four-component workload.

Final PDF/SVG cost, resource and registration figures are rendered and visually inspected. Main text includes the coverage table, measured limits and the registration result without a speed claim. The numerical ledger now contains 141 claims from 23 checksummed inputs/reports. New adversarial contracts reject missing/duplicated trials, codes on censored rows, code disagreement, contaminated timing summaries, fabricated partitions and profile-boundary failures. The 37-test shared gate passes without skips; changed Python passes flake8 at complexity 13 and line length 120. `revision/performance_full_verification.json` records the archive audit.

**Main narrative condensed and proof boundaries tightened**

The mathematical map is total on its admissible domain; bounded executable verdicts require both exact searches to finish. Four-state completion statements require a nonempty valid population and completed comparisons, with explicit mixed witnesses or a justified one-sided proof. Detailed frame/transport algebra, input-boundary algorithms, quotient and automorphism proofs, electron bookkeeping, historical production-only gates and the broad descriptor gallery move into `technical_details.tex`; all 119 labels in the preserved pre-condensation manuscript remain available. The essential expansion faithfulness proof stays in the main text.

After adding cost/registration results, main-text prose is 8,909 words versus 11,107 before condensation, excluding 1,169 caption words and references. This is an editorial measure, not a journal word limit. The integrated 72-page PDF compiles with no undefined citations/references or multiply defined labels; new result pages and all three plots are visually inspected. Further chemical/results integration and final editorial review remain required. Phases 0, 1, 3 and 5 are complete; Phases 2, 4, 6 and 7 remain active.

**Phase 6A — prospective chemical inputs and truth contracts frozen**

Forty unchanged MACE-generated coordination XYZ files spanning twenty constitutions are selected from the published 4TU computational archive, DOI `10.4121/539c7137-c285-4543-be11-e230a4fca8b7.v1`. The archive's recorded MD5 `c7ff7f601a6d603f4637529db1f7787d` matches the download, and its CC BY 4.0 terms are verified at that source. The alternate ACS Figshare archive advertises CC BY-NC 4.0; those terms are not silently substituted for the actual 4TU download. Selection balances Mn/Ru over declared backbone/substituent strata and takes the first two tridentate configurations. No selected constitution overlaps ACS/CIP/RotA development inputs.

The independent truth contract fixes geometric octahedral rotations, proper Kabsch fitting, normalized RMSD/gap refusal limits and a fixed coordinate-to-registered-slot basis before predictions. Source donor isotopes 1–6 are slot labels, including on a hydride; they must be erased from chemical isotope identity while preserving coordinate-row transport. These are generated chemical examples, not experimental stability data. The final input contract retains all 40 supplied OH carriers and twenty source-declared local orientation annotations. A parser preserving those tags is required, and independent geometric/constitutional truth must satisfy all supplied frames simultaneously.

A separate 55-name prospective PubChem query manifest yields 49 retrieved records and six source refusals. One constitution overlaps the existing development negatives; the remaining 48 distinct source structures have independently replayed typed bijections fixing a biaryl bond and exchanging the two branches of one unsubstituted phenyl terminal. This proves absence of constitutional bond atropisomerism under the declared profile, without making a rotational barrier or lifetime claim. Production outputs have not been evaluated.

The additional RotA sample freezes 60 of the 1,562 historical broad candidates, across 26 input strata and 48 source records. Source category, molecule-size bin and a radius-two branch-tie proxy determine strata; confirmation/rejection statuses are withheld from the review sheet. Correct one-based record IDs versus zero-based atom indices are explicitly recorded and all support indices checked. The proxy is not truth, the source corpus remains development evidence, and adjudication is still pending.

The imported XYZ files preserve their original CRLF bytes and published checksums. A scoped `.gitattributes` rule treats CR as the source line ending and disables text normalization for these files; no source coordinates or metadata are rewritten. Chemical production evaluation and adjudication have not yet run.

**Phase 6A — sourced coordination and negative validation completed**

The maintained `ChemicalValidation` package derives proper octahedral poses from all 720 donor assignments and verifies the frozen distortion and pose-gap limits. It preserves source nitrogen tags, checks the explicit-H coordinate export against the compact constitution, and retains every source-declared frame. Source donor isotopes are erased as slot labels, while coordinate-row witnesses remain attached to owner-scoped implicit hydrogen ports. Thirty-one tests pass, including corrupted input/witness cases, coupled-inventory omission, false frozen class/partition claims, and the signed-volume convention checked against an independent RDKit geometry assignment. Changed Python passes flake8 at complexity 13 and line length 120.

At clean source `e330c7d`, independent annotation certifies 38 of the 40 selected configurations. `Mn_PNhP_iPr_tri_0` and `Ru_NNhN_iPr_tri_0` exceed the unchanged normalized RMSD limit of 0.35 (0.490299 and 0.488580). They remain unresolved, without replacement or a production prediction. The accepted records retain 38 metal frames and all 18 supplied nitrogen frames belonging to those records; the other two nitrogen annotations remain accounted for with the unresolved inputs. Among accepted geometries, maximum normalized RMSD is 0.222422 and minimum inequivalent-pose gap is 0.475822, above the frozen 0.02 minimum.

The twenty accepted constitutional groups have complete independent partitions of 900 formal assignments into 230 reference classes. The 38 supplied configurations include 29 achiral and nine chiral cases under this configured-graph profile. The independent annotation report is committed at `1313127` before production evaluation. All 48 sourced structural negatives have full typed bijections fixing both biaryl endpoints, fixing atoms outside the unsubstituted phenyl ring, and exchanging its two terminal branches.

Production at clean `1313127` first independently replays all twenty reference partitions. It then completes 152 full-code computations: source, coordinate mirror, production mirror and atom-renumbered state for each accepted coordination record. All checks pass, including equality in both directions for the 47 observed source/mirror classes. Both original and renumbered perception checks pass for all 48 negative controls (96 computations). The 20.527 s execution retains unchanged Python source hashes. Every captured hash matches its immutable source commit, and the frozen annotation bytes occur in the production source commit. `revision/chemical_full_verification.json` records coverage, hashes and limitations.

These are initial source-generated chemical configurations and constitutional symmetry controls, not experimental persistence evidence. Production does not exhaust the 900 unsourced formal poses, and no independent human chemical review is claimed. The frozen 60-case RotA adjudication, manuscript/ledger integration and final release gates remain pending.

**Phase 6A complete — all sixty RotA structural annotations and production checks**

Independent structural annotation at clean `701144f3` covers all sixty frozen loci, retaining all fifty-two supplied axis supports and independently constructing four adjacent tetrahedral-pair and four spiro-center inventories. It verifies actual adjacency, material ports, hidden hydrogen and the restricted neutral-nitrogen lone-pair contract. Spiro cases have explicit graph-cycle intersection witnesses. All neighboring orientations are neutral. The 128 formal assignments yield a sum of 98 per-case classes; this is not a count of distinct molecules. The sample still spans 48 source records and is assisted development evidence. Twenty-six axis supports have exact terminal-exchange symmetry witnesses and twenty-six have exhausted negative queries. Seven of the latter use aromatic ring edges; their configured-graph distinction does not establish ordinary single-bond atropisomerism. Experimental persistence is unknown in every case.

The annotation artifact is committed at `74c1f1a` before production comparison. At clean `da6d2eb`, all sixty independent structural conclusions and partitions replay before evaluating any code. All 128 assignment triplets complete: 384 full-code computations reproduce exact partitions, mirror images and reverse atom-renumbering equivalence. The 120 original/renumbered perception computations agree with the declared constitutional carrier and category-projection contracts. Source hashes remain unchanged during the 47.588 s execution and match the immutable source commits. `revision/rota_full_verification.json` records the complete coverage and source/annotation audit.

The sample exposed an experimental projection defect: the old spiral-category projection ignored its filtered element list and could place a geometry-only spiro center in the `confirmed` set. Confirmed projections now require actual confirmed tetrahedral supports at the spiro center or both chain terminals; broad geometry remains separate, and unsupported coupled global spiro geometry is not certified. A nonstereogenic focal tetrahedral candidate may be omitted by perception rather than emitted with a symmetry reason; the new report records that omission explicitly and requires no false confirmed support or projection. Historical reports and selection remain unchanged; the affected current full-detection report must be regenerated.

A separate independent regression proves that a simultaneous exchange of both axial terminal pairs can preserve the configured orientation. Terminal-reference equivalence therefore cannot replace whole-configuration mirror comparison. Production full codes agree with the reference counterexample; the witness documentation and technical manuscript now state this distinction. The current combined gate passes 78 tests. Three legacy artifact assertions skip because the common historical report manifest is absent; their names and reasons remain in the XML, and this is not advertised as an all-test pass. The updated manuscript builds successfully after the boundary clarification.

New chemical validation now supports the retained configured OH/tetrahedral examples and structural negatives, with the RotA follow-up reported under its precise assistance and topology boundary. Other path, plane and framework families retain proved representation/formal validation; this work adds no unsupported claim of empirical chemical coverage or experimental persistence for them. Manuscript/ledger integration, remaining report provenance/regeneration, final proof/prior-art reading, cover letter and clean submission reproduction are still required.

**Proof review, current RDKit representation and seven protocol reports**

A structured review records seventeen proof and comparison obligations. Normalization equivariance is now an explicit binary-pipeline premise; authorization transports with its evidence collection and invariant typing predicates; automorphism projection uses the full typed carrier key and ordered support relations. A uniquely colored K4 with two distinct helical traversals over the same atom set has exactly one atom and auxiliary automorphism, supporting the corrected uniqueness explanation. The finite action/geometry/size audit again passes: 36 action pairs and 7,776 cocycles, including detection of reversed conventions. This is an assistant review, not an independent human reader or formal machine verification.

A SynKit-free RDKit 2026.03.1 probe exhausts all 165,960 atom permutations of 53 distinct-ligand states: three square-planar, twenty trigonal-bipyramidal and thirty octahedral. All state strings remain distinct, documented equivalent encodings agree and parse/write round trips preserve them. Removing stereo collapses each geometry to one constitutional string. Source/fixture hashes and runtime options accompany the standalone probe, now included in bounded and full reproduction. This is formal representation evidence, not coordinate, naming, chemical-truth or physical-persistence validation. Circular Stereo v2 full text remains inaccessible and no uninspected theorem is attributed.

All seven missing perception/relation stages finish. Every report's 527 captured Python hashes matches immutable commit b1170af, every supplied input checksum verifies and every report hash matches the parent stage manifest. Reports and logs are archived unchanged in Data/Revision/ProtocolReconciled. Later documentation edits are disclosed by stage dirty state; executed Python remains unchanged. The new spiro confirmation contract recovers 688/698 annotated RotA loci with 1,521 confirmed projections, leaving 833 additional projections. The earlier figure of 843 is corrected in the supporting discussion using generated ledger macros. Broad recovery remains 698/698 with 1,562 additional projections; these are annotation differences rather than measured false positives.

Coverage reconciliation finds that the detector's legacy isomericSmiles=False count suppresses isotope identity: 903 instead of the separately audited 904 constitutions. A complete input-key recomputation isolates one split group across all 1,208 rows. The detector now uses the same isotope-preserving constructor as the overlap audit, erasing configuration and atom maps while retaining isotopes, charges, hydrogen counts and aromaticity. Three dataset-level counterexample tests verify this behavior. Archived detection records remain unchanged; a corrected full report still needs regeneration.

The focused protocol/RotA gate passes 28 tests; the numerical, provenance, representation and coverage contracts pass 41 tests. New adversarial checks reject omitted states/numberings, false invariance, failed round trips, duplicated detection rows, inflated recovery and concealed unevaluated rows. The ledger has 147 claims from 26 checksummed artifacts; six further protocol and chemical reports remain to integrate. Manuscript integration and clean release reproduction remain required.

At clean source checkpoint `347b818`, the complete bounded sequence passes 212 tests without skips, the five-case independent pilot and the 53-state / 165,960-numbering RDKit probe. The current theory audit again passes against exact current source/manuscript hashes. These fresh reports and stage hashes are archived in `BoundedProofProtocols`, and `proof_protocol_checkpoint_verification.json` records the checks. This is a current-worktree bounded reproduction; the final full release and independent reader substitute remain required.


**Chemical/protocol numerical integration and corrected isotope coverage**

Committed source `3611bf2` adds pure report contracts for the four frozen chemical annotation/evaluation schemas and all six remaining protocol schemas. The chemical summary binds unchanged input checksums, replays record coverage/partitions/mirror expectations and recomputes every summary count. Separate adversarial tests reject concealed refusals, changed annotations, incomplete assignment populations, constant codes, false category confirmation, substituted negatives and fabricated totals. Retained detection contracts now also reconcile assistance, family, renumbering and miss-structure counts from individual records. The final focused gate passes 73 tests; all changed Python passes flake8 at line length 120 and complexity 13.

At that clean checkpoint, bounded reproduction passes all 247 tests without skips, the five-case independent pilot with seven deliberate defects rejected, and all 53 RDKit states across 165,960 numberings. Every captured source hash matches the immutable commit. Stage bytes and logs are retained unchanged in `BoundedChemicalLedger`; the chemical summary captures all 530 experiment/runtime Python sources and recomputes its counts from the four unchanged originals.

The fresh full detector completes in 744.122 seconds with unchanged clean-source and input checksums. It reports 904 constitutions under the shared isotope/charge-preserving key, correcting the legacy 903. All 1,208 individual records, locus sets, symmetry explanations and renumbering evidence are byte-equivalent as parsed records to the previous report; no parse or detection failure occurs. Original reports remain unchanged. The corrected report is archived in `ProtocolIsotopeCorrected` and now supplies the manuscript ledger. That ledger validates 269 claims from 37 artifacts. `isotope_preserving_detection_verification.json` records immutable source/input hashes and complete dataset-by-dataset comparisons.

The main paper now reports coordination, sourced negatives and RotA adjudication separately, distinguishing 900 reference assignments from 152 production code computations on certified source/mirror states. The RotA 98-class total is explicitly a sum per case. Two coordination geometry refusals, aromatic-axis model tests, source assistance, automated annotation and unknown physical persistence remain visible in both prose and the new table. Detailed frozen annotation and replay contracts appear in a dedicated appendix. MACE receives credit for prior rotation-related canonical-SMILES set comparisons and mirror screening in the related-work prose/table, bibliography and primary-source audit.

The one-page cover-letter draft is rewritten around the faithful uniform construction, independent validation, chemical scope and measured absence of a registration speed advantage. Its numerical statements use the generated ledger macros. Main/letter PDFs build without undefined references/citations, multiply defined labels or overfull boxes. Chemical results and letter layouts are visually inspected. The main prose count is 9,053 including abstract/declarations, with 1,190 caption words; the abstract has 252 words. Reviewable PDFs and logs are in `revision/generated/manuscript`. Final version/environment freezing, full clean-release reproduction, data-access/metadata/DOI resolution and reader substitutes remain required; this checkpoint is not submission-ready.

**Release continuation and current claim audit, 3 October 2026**

The full clean sequence stopped after 14 successful stages at the optional StereoMolGraph import: its declared `typing-extensions` dependency was absent from the isolated base environment. The original failure manifest and log are preserved under `revision/release/full_attempt_01_dependency_failure.*.gz`. A separate wheel-hash lock supplies version 4.15.0; all 46 base versions remain unchanged. The validated continuation runs the remaining 21 stages through the maintained research runner, reusing only reports whose hashes, source/input identity and exact commands still agree. Sequence and scientific completion are not inferred while that continuation is running.

The current claim register contains 269 numerical claims and 17 proof obligations. All 33 labelled statement/immediate-proof blocks across `main.tex` and `technical_details.tex` match the reviewed base; current proof locators resolve. A 63-requirement audit covers the complete original programme rather than only recent release work. SACA v2 is positively cited from its inspected primary abstract and author experiment code; the inaccessible full text is disclosed in the access audit. This review remains an assistant substitute, with independent human review and formal verification unclaimed.


### Complete clean execution and primary selection, 3 October 2026

All 35 required research stages finish successfully from unchanged clean source `e2526b9`. The optional comparator overlay supplies its declared dependency without changing the 46-package base. The initial failed attempt, verified prefix and continuation remain retained. The archive contains 90 raw execution files, 78,905,304 bytes, copied unchanged. Two explicitly separate portable projections relocate validator input paths and derive zero-valued cost display bins by recounting all retained trials; reversing those projections reproduces the exact original report objects.

All 531 scientific Python hashes match the executed source. Every local/formal scientific record is unchanged apart from measured times, all 2,439 independent witnesses replay, both 300-record native/comparator CIP protocols reproduce exactly, all 1,208 detector records are unchanged, and every chemical-summary field agrees. The five-second supplied-configuration ACS protocol now retains VS126, VS127 and VS208 timeouts: 255 definitive outcomes and 253 correct decisions among 258 inputs. The two definitive disagreements remain VS170/VS300. The separate 30-second exact-plus-global result remains 257/258 with all inputs definitive.

The complete 540-trial controlled study has 513 completed results, three timeouts, six RSS limits and 18 expected boundary refusals; no certificate disagreement occurs. Four-component full-group trials now reach the RSS guard instead of their historical timeout. All 30 registration pipelines recover the independent partitions and show no runtime crossover. At 128 records fresh medians are 0.140359 s pairwise and 1.078216 s certificates; 126.523438 MiB is whole-study RSS. Three repetitions and measured background load limit interpretation.

The primary manifest and generated ledger now select all 269 claims from 37 checked reports. Thirty-two values change, mainly timing and memory observations. The previous selection, figures, manuscript and unconfirmed draft references remain in `revision/release/pre_clean_full_selection`. Current figures and prose reflect the fresh censors and resources. All 60 report-contract tests pass; the 286-row current evidence register binds 269 numerical claims and 17 proof obligations. All 33 labelled mathematical statements and their immediate proofs remain byte-identical to the reviewed base.

Journal review PDFs comprise a 53-page main paper and 55-page supplement; their 34-file source ZIP passes byte checks and compiles both PDFs from extraction, with no unresolved references/citations or overfull boxes and all fonts embedded. The combined authoring paper and one-page letter also build. Unconfirmed companion citations are omitted from the submission bibliography; reaction transport is explicitly outside this molecular study. This is an automated review substitute, not an independent human assessment. Final individual figure preparation, the complete updated research-archive extraction, final author facts/review and the exact persistent archive DOI remain required; no publication or submission occurs.


The complete `e7f7460` review archive exports 1,990 files (509,649,727 source bytes), compressed to 122,174,852 bytes with SHA-256 `b948acb5c059462c1588d288bd9902ac17eea4faf028ea64c7ad959d2674dd23`. All extracted bytes match. Its distinct local verification commit is `1922bb2`; the original and local Git trees are both `842b1981c24172881a8552589c1524e2f3a74528`. Before the documented Git bootstrap, four tests could not invoke provenance; those failures are preserved. After seeding only the verified original files, all 60 focused contracts pass with no code change. All 269 claims validate from extraction; rebuilt main/letter text is identical to the selected PDFs. This is a complete review archive, with final figure uploads, author confirmation/review and persistent submission-release identity still pending.


### Individual journal figures and current editorial package, 3 October 2026

All nine composite graphics are exported as cropped vector PDFs, with captions retained in the main document and a separate caption file. Titles are at most 13 words, conservative legends at most 209 words, and the largest graphic is 128,775 bytes. All fonts are embedded. First textual mentions precede placements and agree with upload order. The 23-file source ZIP passes CRC/inventory/hash checks; extraction builds all nine figures with byte-identical 180 dpi renderings. Assistant visual inspection covers all nine final renders, including explicit identity checks when transferring an earlier inspection. Human author review and a formal stroke-width audit are unclaimed.

An ACS percentage rendering error introduced in the earlier editorial change used TikZ’s overwritten `pgfmathresult`, displaying -3.39% while the selected report and fraction 253/258 were correct. The named `AcsAgreementPercentage` macro fixes the label to 98.06%. Export and reader checks derive the expected percentage from the selected ledger and inspect actual PDF text. Figure 2’s subtitles are shortened to avoid wrapping into the chemical drawings. No chemical diagram, scientific observation or mathematical statement changes.

The current separate review PDFs contain 54 main pages and 55 supplemental pages. All 34 manuscript dependencies rebuild both documents without unresolved references/citations or overfull boxes and with embedded fonts. The explicitly cited/described `Additional_file_1.pdf` is byte-identical to the supplement. Numbered references identify project URLs, the working Read the Docs documentation and the project-level Zenodo archive, which is explicitly separate from the exact revision DOI. Tested language/platform/dependencies and license boundaries are stated. All 33 reviewed mathematical statement/proof blocks and all 531 scientific Python hashes remain unchanged. New publication helpers are outside the captured scientific source. They pass flake8; exact executed driver bytes and abstract-syntax identity after formatting are retained.

The updated research archive containing final figures requires extraction verification. The concrete author-decision sheet records draft authorship, affiliations, funding, interests and contributions and proposed cover-letter assertions. Author approval, originality/exclusivity and the exact public research-release identifier remain unresolved. No publication, external message or journal submission is performed.

**3 October 2026 — user-requested authors, thesis notation and explanatory visuals.** Imported Tieu-Long Phan, Peter F. Stadler and Daniel Merkle from the located Syndoku manuscript, with source emails and seven affiliation blocks. Read thesis graph/LLG/canonicalization notation and shared style; inspected rendered thesis pages 20 and 71. Added a notation table, graph-indexed labels and a graph/encoding type distinction. Corrected the prose implication from canonical-form axioms to the equality test, without altering any of the 33 labelled statement/proof blocks.

Added Figure 4 (partial stereo input with achiral/chiral completions) and Figure 6 (equal count/degree invariants for nonisomorphic graphs), and harmonized explanatory graphics with the thesis palette and badges. All eleven final renders were inspected, and extracted editable sources reproduce all eleven renderings exactly. Diagram validation checks the actual drawn Fischer arms, all 18 strict profile/order verdicts and 2,160 independently enumerated illustrative graph serializations. Those serializations are separate from the benchmark populations.

The rebuilt journal manuscript and SI are each 56 pages, supplied by 38 editable dependencies; figures have 29 editable dependencies. The combined authoring PDF is 80 pages. Extracted journal sources compile without unresolved references or overfull boxes; all fonts are embedded. All 531 executed scientific Python files, 269 claims from 37 reports and 35-stage results remain bound unchanged. The prior nine-figure research archive `00110d0` verifies 2,040 files; the new additions are frozen and checked separately. Study-specific funding, interests, contribution roles, author approval and exact public release identity remain unconfirmed. No public upload or journal submission occurred.

**Updated three-author/thesis archive verified.** Source `3c10948` exports 2,063 exact tracked files to a 125,667,346-byte archive with SHA-256 `7210c66808c40ed68efafddb9c5dfb0c0ca4aed4e0fb0a0683e0e9f1c856d8b9`. All source/archive/extracted bytes and Git trees agree. From extraction, all 35-stage/269-claim selection contracts, eleven figure bindings, 18 chemical diagram verdicts, 2,160 illustrative serializations and 60 focused tests pass. The 80-page combined manuscript and one-page cover letter rebuild with identical text. Both journal ZIPs match their independently rebuilt source-reader artifacts by exact hashes. All 234 frozen requirement-evidence links and the frozen plan digest verify. Post-freeze receipts and corrected status documentation are separate from the frozen source archive; no approval or publication is implied.

**3 October 2026 — user-directed funding, contribution roles and review-only completion.** Copied the entire Syndoku funding subsection verbatim, including TACsy, MATOMIC, DAAD/SECAI, ScaDS.AI, DFG and the EU disclaimer. Added Peter and Daniel's roles as manuscript revision, supervision and funding acquisition, as explicitly instructed. The user clarified “Finish the review package; no publication or submission.” The manuscript now labels competing interests pending and distinguishes the local exact review archive from an unassigned public DOI. No approval, preprint or publication facts are invented.

The final journal-style manuscript and SI remain 56 pages each, supplied by 38 editable dependencies; the combined authoring PDF remains 80 pages. Funding identifiers, contribution wording and the pending-interest sentence are verified in rendered PDF text. Extracted editable journal sources compile without unresolved references or overflow. All eleven graphic inputs/captions/order match; unchanged figure-reader results retain 29 dependencies and identical renderings. All 35 selected research stages, 269 claims/37 reports, 90 raw files, 33 labelled mathematical blocks and 531 scientific Python files remain verified. Final local archive checks are recorded separately. Future public release and submission are explicitly outside the current goal.

**Review-only final verification completed.** Immutable source `68fd19d91eba11633dbe3a62ed966579346c3fa6` provides `2078` exact tracked files in the local archive, SHA-256 `0540e8ab2ccc092ba260fc73a15f0357ba5efaf11d258eb87a91dae49d24c417`. All source/archive/extracted bytes and Git trees agree. Extracted verification confirms all 35-stage/269-claim selection contracts, 90 raw files, 531 unchanged scientific Python files and 33 reviewed mathematical blocks. All 60 focused tests pass, eleven figure bindings pass, and the 80-page combined manuscript and one-page draft letter rebuild with identical text. Current 38-file journal and 29-file figure source-reader results transfer through exact ZIP/PDF hashes. All 68 frozen requirements and 255 evidence links are byte-verified. User-scoped review completion is established; no public publication or submission is performed.
