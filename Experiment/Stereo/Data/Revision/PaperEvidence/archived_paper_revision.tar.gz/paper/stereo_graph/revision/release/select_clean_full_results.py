"""Validate a complete clean-run candidate before updating primary paper numbers."""

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repository", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    root = args.repository.resolve()
    sys.path.insert(0, str(root))
    from Experiment.Stereo.manuscript_tables import build_ledger
    manifest = json.loads((root / "paper/stereo_graph/revision/result_manifest.json").read_text())
    base = "Experiment/Stereo/Data/Revision/CleanReleaseFull/"
    raw = base + "execution/"
    execution = json.loads((root / (raw + "stage_manifest.json")).read_text())
    if not execution["complete"] or len(execution["records"]) != 35:
        raise RuntimeError("The complete required execution sequence is missing.")
    cost = json.loads((root / (base + "controlled_costs.json")).read_text())
    for mode, bins in cost["archive_relocation"]["derived_outcome_counts"].items():
        measured = Counter(row["status"] for row in cost["records"] if row["mode"] == mode)
        if any(value != measured[status] for status, value in bins.items()) or set(measured) - set(bins):
            raise RuntimeError("The cost display bins do not count every retained trial.")
    for specification in manifest["reports"]:
        old = specification["path"]
        name = Path(old).stem
        target = None
        if old.endswith("/Protocols/topology_completion.json"):
            continue  # Preserve the separate historical pinned-comparator protocol.
        if name in {"cip_smiles", "cip_coordinates", "source_identity", "exact_plus_global"}:
            target = raw + name + ".json"
        elif name == "topology_completion_current_smg":
            target = raw + "topology_completion.json"
        elif name == "corpus_overlap":
            target = raw + "overlap.json"
        elif old == "Experiment/Stereo/Data/Canonicalization/Independent/full_report.json":
            target = raw + "independent.json"
        elif name == "independent_full_verification":
            target = "paper/stereo_graph/revision/release/full_independent_archive_verification.json"
        elif name.startswith("local_") and "/DirectFull/" in old:
            target = raw + name + ".json"
        elif name.startswith("local_") and name.endswith("_direct_verification"):
            task = name.removeprefix("local_").removesuffix("_direct_verification")
            target = raw + "replay_local_" + task + ".json"
        elif name in {"formal_A", "formal_B", "formal_C"}:
            target = raw + name + ".json"
        elif name == "controlled_full":
            target = base + "controlled_costs.json"
            for claim in specification["claims"]:
                parts = claim["pointer"].split("/")
                if len(parts) == 5 and parts[1] == "summary" and parts[3] == "outcomes":
                    claim["pointer"] = "/archive_relocation/derived_outcome_counts/" + parts[2] + "/" + parts[4]
        elif name == "controlled_full_inputs":
            target = raw + "controlled_costs_inputs.json"
        elif name == "registration_full":
            target = raw + "registration.json"
        elif name == "rdkit_representation_report":
            target = raw + "rdkit_representation.json"
        elif name == "retained_detection":
            target = raw + "retained_detection.json"
        elif "/Chemical/" in old:
            renamed = {"independent_annotation": "chemical_annotation", "production_validation": "chemical_validation",
                       "rota_structural_annotation": "rota_annotation", "rota_production_validation": "rota_validation",
                       "manuscript_summary": "chemical_results"}
            target = (base if name == "manuscript_summary" else raw) + renamed[name] + ".json"
        elif "/ProtocolReconciled/" in old:
            target = raw + name + ".json"
        if target:
            path = root / target
            specification["path"] = target
            specification["sha256"] = sha256(path)
            if name == "independent_full_verification":
                specification["expected"]["/input_sha256"] = sha256(root / (raw + "independent.json"))
            if name == "elements":
                report = json.loads(path.read_text())
                if report["dataset"]["source"]["license"] != "CC BY-NC 4.0":
                    raise RuntimeError("Publisher input licence binding is missing.")
                specification["expected"]["/dataset/structures_vendored"] = True
    manifest["status"] = "Clean-run candidate: all scientific contracts checked; final manuscript reconciliation pending."
    manifest["selection_boundary"] = (
        "Complete clean e2526b9 execution retains every case, refusal and resource censor. Historical pinned comparator "
        "and representation fixtures remain separate. Portable projections retain raw reports, relocate linked input "
        "paths and derive complete cost display bins from all retained trials, including zero counts.")
    ledger = build_ledger(manifest, root)
    if len(ledger) != 269:
        raise RuntimeError("The complete numerical claim catalogue changed.")
    prior = json.loads((root / "paper/stereo_graph/revision/generated/numerical_ledger.json").read_text())
    lookup = {row["claim_id"]: row for row in prior}
    changes = []
    for row in ledger:
        old = lookup[row["claim_id"]]
        if (old["value"], old["denominator"]) != (row["value"], row["denominator"]):
            changes.append({"claim_id": row["claim_id"], "previous_value": old["value"], "fresh_value": row["value"],
                            "previous_denominator": old["denominator"], "fresh_denominator": row["denominator"]})
    args.output_dir.mkdir(parents=True, exist_ok=True)
    outputs = {"clean_full_result_manifest_candidate.json": manifest, "clean_full_ledger_candidate.json": ledger,
               "clean_full_ledger_candidate_verification.json": {
                   "schema": "synkit.stereo-clean-full-candidate-ledger/1", "claims": len(ledger),
                   "reports": len(manifest["reports"]), "all_artifact_and_scientific_contract_checks_passed": True,
                   "portable_linked_input_paths_validated": True, "cost_outcome_bins_recounted": True,
                   "selection_driver_sha256": sha256(Path(__file__)), "changed_claim_count": len(changes),
                   "changed_claims": changes, "selection_promoted_to_manuscript": False,
                   "remaining": "Reconcile changed censor/resource prose, promote selection, rebuild documents and figures, refresh current registers."}}
    for name, value in outputs.items():
        (args.output_dir / name).write_text(json.dumps(value, indent=2) + "\n")
    print(json.dumps({"claims": len(ledger), "reports": len(manifest["reports"]), "changed_claims": len(changes),
                      "all_checks_passed": True}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
