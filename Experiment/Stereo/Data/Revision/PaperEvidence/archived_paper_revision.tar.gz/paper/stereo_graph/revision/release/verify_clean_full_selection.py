"""Verify retained execution bytes, portable projections and the selected ledger."""

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import sys


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repository", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = args.repository.resolve()
    sys.path.insert(0, str(root))
    from Experiment.Stereo.manuscript_tables import build_ledger
    paper = root / "paper/stereo_graph"
    release = paper / "revision/release"
    archive = root / "Experiment/Stereo/Data/Revision/CleanReleaseFull"
    retained = json.loads((archive / "archive_manifest.json").read_text())
    for name, entry in retained["raw_inventory"].items():
        require(sha256(archive / "execution" / name) == entry["sha256"], "Raw bytes changed: " + name)
    execution = json.loads((archive / "execution/stage_manifest.json").read_text())
    require(execution["complete"] and len(execution["records"]) == 35 and
            [r["stage"] for r in execution["records"]] == execution["selected_stage_names"] and
            all(r["status"] == "complete" and r["returncode"] == 0 for r in execution["records"]),
            "A required execution stage is incomplete.")
    provenance = execution["provenance"]
    require(provenance["source_unchanged_during_run"] and provenance["inputs_unchanged_during_run"],
            "Executed source or input changed.")
    for name, value in provenance["source_sha256"].items():
        require(sha256(root / name) == value, "Scientific source differs from execution: " + name)
    for name, entry in retained["portable_projections"].items():
        path = root / entry["path"]
        require(sha256(path) == entry["sha256"], "Projection bytes changed: " + name)
        projected = json.loads(path.read_text())
        relocation = projected.pop("archive_relocation")
        original = json.loads((root / relocation["execution_report_path"]).read_text())
        require(sha256(root / relocation["execution_report_path"]) == relocation["execution_report_sha256"],
                "Projection original binding changed: " + name)
        for change in relocation["changes"]:
            require(sha256(root / change["archive_relative_path"]) == change["input_sha256_unchanged"],
                    "Linked input changed: " + name)
            linked = projected["inputs"] if name == "controlled_costs" else projected["inputs"][change["role"]]
            linked["path"] = change["original_path"]
        require(projected == original, "A scientific field changed in projection: " + name)
        if name == "controlled_costs":
            for mode, bins in relocation["derived_outcome_counts"].items():
                counted = Counter(r["status"] for r in original["records"] if r["mode"] == mode)
                require(not set(counted) - set(bins) and all(bins[k] == counted[k] for k in bins),
                        "Display bins omit or miscount a retained trial.")
    manifest_path = paper / "revision/result_manifest.json"
    manifest = json.loads(manifest_path.read_text())
    ledger = build_ledger(manifest, root)
    require(len(ledger) == 269 and len(manifest["reports"]) == 37, "Selected claim scope changed.")
    require(ledger == json.loads((paper / "revision/generated/numerical_ledger.json").read_text()),
            "The generated ledger differs from the selected reports.")
    require(ledger == json.loads((release / "clean_full_ledger_candidate.json").read_text()),
            "The checked candidate was not selected exactly.")
    previous = json.loads((release / "pre_clean_full_selection/revision/generated/numerical_ledger.json").read_text())
    previous_by_id = {r["claim_id"]: r for r in previous}
    changes = [r["claim_id"] for r in ledger if (r["value"], r["denominator"]) !=
               (previous_by_id[r["claim_id"]]["value"], previous_by_id[r["claim_id"]]["denominator"])]
    candidate = json.loads((release / "clean_full_ledger_candidate_verification.json").read_text())
    require(changes == [r["claim_id"] for r in candidate["changed_claims"]], "Changed-claim reconciliation differs.")
    values = (paper / "revision/generated/numerical_values.tex").read_text()
    for row in ledger:
        require("\\newcommand{\\" + row["claim_id"] + "}{" + str(row["value"]) + "}" in values,
                "A numerical macro is stale: " + row["claim_id"])
    main_source = (paper / "main.tex").read_text()
    required_prose = ["VS126, VS127 and VS208 time out", "times out on VS126, VS127 and VS208",
                     "full-group output reaches the memory limit in all repetitions",
                     "1,100.87 seconds", "134.08 MiB", "\\code{e2526b9}"]
    require(all(value in main_source for value in required_prose), "A changed resource observation is absent.")
    require("254/256" not in main_source and "520.06" not in main_source and "109.23" not in main_source,
            "An older primary resource observation remains in current prose.")
    binding_path = release / "structured_proof_release_binding.json"
    binding = json.loads(binding_path.read_text())
    pattern = re.compile(r"\\begin\{(definition|lemma|theorem|corollary|proposition)\}.*?\\end\{\1\}"
                         r"(?:\s*\\begin\{proof\}.*?\\end\{proof\})?", re.S)
    for name, entry in binding["source_documents"].items():
        require(sha256(root / name) == entry["sha256"], "Proof document binding is stale: " + name)
        blocks = [match.group(0) for match in pattern.finditer((root / name).read_text())]
        for label, statement in binding["labelled_statements_and_immediate_proofs"].items():
            if statement["file"] != name:
                continue
            block = next((b for b in blocks if "\\label{" + label + "}" in b), None)
            require(block is not None and hashlib.sha256(block.encode()).hexdigest() ==
                    statement["statement_and_proof_sha256"], "Reviewed statement/proof differs: " + label)
    figure_manifest = json.loads((archive / "execution/figures/cost_figure_manifest.json").read_text())
    for entry in figure_manifest["outputs"]:
        require(sha256(paper / "revision/generated/performance" / Path(entry["path"]).name) == entry["sha256"],
                "A selected performance figure differs from clean execution.")
    report = {"schema": "synkit.stereo-clean-full-selection-verification/1",
              "verification_driver_sha256": sha256(Path(__file__)),
              "execution_source_commit": provenance["source_commit"],
              "scientific_python_files_unchanged": len(provenance["source_sha256"]),
              "required_stages_complete": 35, "raw_files_byte_verified": len(retained["raw_inventory"]),
              "portable_projections_reversed_exactly": 2, "all_cost_trials_recounted": 540,
              "claims": len(ledger), "reports": len(manifest["reports"]), "changed_claims": changes,
              "primary_manifest_sha256": sha256(manifest_path),
              "generated_ledger_sha256": sha256(paper / "revision/generated/numerical_ledger.json"),
              "source_main_sha256": sha256(paper / "main.tex"),
              "proof_binding_sha256": sha256(binding_path),
              "statement_and_immediate_proof_blocks_checked": len(binding["labelled_statements_and_immediate_proofs"]),
              "selected_performance_figures_byte_verified": len(figure_manifest["outputs"]),
              "selection_promoted": True, "passed": True,
              "boundary": "Checks scientific execution, report contracts and selected document values. Final PDF/source-archive validation, author facts and exact repository DOI remain separate gates."}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: report[k] for k in ("required_stages_complete", "claims", "reports", "raw_files_byte_verified", "passed")}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
