**Alignment with Syndoku and the PhD thesis**

The user requested Tieu-Long Phan, Peter F. Stadler and Daniel Merkle, in that order. Names, email addresses and the seven affiliation blocks follow `/home/lolo/Documents/TACsy/paper/SYNDOKU/syndoku.tex`. Long remains corresponding author. The [source audit](author_thesis_source_audit.json) records exact source hashes. The user subsequently explicitly directed importing all Syndoku funding and specified Peter/Daniel roles in revision, supervision and funding acquisition. Author submission approval is not inferred.

The notation review used thesis Chapters 2 (graph foundations), 3 (LLG) and 6 (canonicalization), plus `misc/custom_defs.tex`. The manuscript now gives `G=(V(G), E(G), a_G, b_G)`, graph maps `φ:G→H`, ordinary right-to-left function composition and a notation table. Existing `f` and `g` denote the same kind of map. Labels `a_G` and `b_G` are constitution/resources, while the configured registry retains stereochemical state; displayed vertex numbers are identifiers rather than chemical colors.

| Symbol | Type and interpretation |
| --- | --- |
| `Can(K)` | Canonical representative graph; it is isomorphic to its input |
| `can(K)` | Lossless serialized encoding of that representative in canonical order |
| `C(X)` | Configured stereograph certificate under the selected identity profile |
| `Aut(G)` | Label-preserving graph automorphism group |
| `Φ` | Faithful colored-graph encoding |
| `μ` | Mirror action on the configured input |

The thesis uses lower-case `can` for a canonical encoding. Retaining upper-case `Can` for the graph-valued object avoids a type error in the representative-graph axioms. Those axioms imply the equality test; the equality test alone does not establish that an output graph represents the input. That prose implication has been corrected. All 33 labelled statement/immediate-proof blocks remain unchanged.

The local vector style copies the thesis's shared palette and figure style into self-contained manuscript dependencies: navy badges, blue/teal/gold/vermilion accents, light dividers and restrained panels. Actual thesis PDF pages 20 and 71 were inspected. Existing figure layouts and experimental denominators are preserved.

Two new diagrams add specific explanations. Figure 4 shows one partial input with both achiral and chiral completions, explaining the strict refusal. Figure 6 shows a renumbered cycle and two triangles: count/degree invariants collide, while exact canonical encodings separate the nonisomorphic graphs. The [example validation](explanatory_figure_validation.json) checks drawn Fischer arms, 18 strict profile/order verdicts and 2,160 independently enumerated adjacency serializations. These serializations are a separate illustrative population, not additional assignments in the formal benchmark.

All eleven figures have been inspected by the assistant and independently rebuilt from their 29-file editable archive with identical raster output. This does not establish independent human review or author approval.
