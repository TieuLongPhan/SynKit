"""Replay every archived full-orbit witness and check stored partitions/mirrors.

This verifies positive witnesses and archived consistency. Exhaustion of negative
queries and production full-code comparisons belong to the generating audit.
"""

import argparse
from itertools import product
import json
from pathlib import Path
import sys


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--cip-path", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = args.source.resolve()
    sys.path.insert(0, str(root))
    from Experiment.Stereo.provenance import capture_source, finish_source, sha256
    from Experiment.Stereo.Canonicalization.independent_fixtures import fixtures
    from Experiment.Stereo.Canonicalization.independent_runner import public_fixtures
    from Experiment.Stereo.Canonicalization.independent_model import formal_states
    from Experiment.Stereo.Canonicalization.independent_replay import _validate_map
    from Experiment.Stereo.Canonicalization.independent_orbits import (
        ATOM_KEYS, BOND_KEYS, _selector, _states_and_lookup, _action_table,
        _mirror_table, _mirror_classes, apply_table, color_signature,
    )

    source = capture_source([args.cip_path])
    report = json.loads(args.report.read_text())
    require(report["schema"] == "synkit.independent-stereograph-audit/1" and report["passed"],
            "Expected a successful independent full audit.")
    require(report["sources_unchanged_during_run"], "Generating sources changed.")
    for name, value in report["provenance"]["source_sha256"].items():
        require(sha256(root / name) == value, "Generating source no longer matches: " + name)
    selected = {fixture.name: (fixture, True) for fixture in fixtures()}
    public, unused_integrity = public_fixtures(args.cip_path)
    selected.update({fixture.name: (fixture, False) for fixture in public})
    rows = report["records"]
    require(len(rows) == len(selected) and {row["case_id"] for row in rows} == set(selected),
            "Report does not cover the complete declared catalogue exactly once.")
    verified = []
    total = 0
    for row in rows:
        name = row["case_id"]
        fixture, internal = selected[name]
        graph = fixture.graph
        choices = tuple(formal_states(seed) for seed in fixture.seeds)
        states, lookup, unused_inventory = _states_and_lookup(choices)
        reference = row["reference"]
        require(reference["status"] == "complete" and row["passed"], "Incomplete case: " + name)
        assignments = tuple(product(*(range(len(local)) for local in choices)))
        require(reference["assignments"] == [list(value) for value in assignments],
                "Formal assignment inventory differs: " + name)
        partition = tuple(tuple(tuple(member) for member in group) for group in reference["partition"])
        members = [member for group in partition for member in group]
        require(len(members) == len(assignments) and set(members) == set(assignments),
                "Partition is not disjoint and complete: " + name)
        require(row["production_partition"] == reference["partition"], "Stored production partition differs: " + name)
        require(row["full_partition_agreement"] and row["production_mirror_agreement"]
                and row["renumbering_failures"] == 0
                and row["renumbering_checks"] == len(assignments), "Production checks incomplete: " + name)
        class_of = {member: index for index, group in enumerate(partition) for member in group}
        node_color = _selector("color" if internal else ATOM_KEYS)
        edge_color = _selector("color" if internal else BOND_KEYS)
        node_tokens = {node: color_signature(node_color(data)) for node, data in graph.nodes(data=True)}
        edge_tokens = {frozenset((a, b)): color_signature(edge_color(data)) for a, b, data in graph.edges(data=True)}
        cache = {}
        targets = []
        for witness in reference["merge_witnesses"]:
            original, target = tuple(witness["source_assignment"]), tuple(witness["target_assignment"])
            mapping = dict(witness["atom_mapping"])
            key = tuple(sorted(mapping.items()))
            if key not in cache:
                _validate_map(graph, mapping, node_tokens, edge_tokens)
                cache[key] = _action_table(states, lookup, mapping)
            table = cache[key]
            require(apply_table(original, table) == target and class_of[original] == class_of[target],
                    "Witness does not transport the full assignment: " + name)
            require(list(local[0][0] for local in table) == witness["carrier_permutation"],
                    "Stored carrier permutation differs: " + name)
            targets.append(target)
        require(len(targets) == len(assignments) and set(targets) == set(assignments),
                "Assignment lacks exactly one merge witness: " + name)
        mirror_table = _mirror_table(states, lookup)
        require(json.loads(json.dumps(_mirror_classes(partition, mirror_table))) == reference["mirror_classes"],
                "Mirror class relation differs: " + name)
        require([list(apply_table(value, mirror_table)) for value in assignments] == reference["mirror_assignment_images"],
                "Mirror assignment images differ: " + name)
        total += len(targets)
        verified.append({"case_id": name, "witnesses_replayed": len(targets),
                         "partition_mirror_and_renumbering_verified": True})
    result = {"schema": "synkit.independent-archive-verification/1", "input_report": str(args.report),
              "input_sha256": sha256(args.report), "cases_verified": len(verified), "witnesses_replayed": total,
              "source_hashes_match": True, "all_required_checks_passed": True, "records": verified,
              "verification_driver_sha256": sha256(Path(__file__)),
              "scope": "Positive map replay and stored complete partition/mirror consistency; generating audit supplies negative exhaustion and production full-code computations.",
              "provenance": finish_source(source)}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"cases_verified": len(verified), "witnesses_replayed": total, "passed": True}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
